import { type NextRequest, NextResponse } from "next/server"
import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"
import { createServerClient } from "@/lib/supabase/server"

export async function POST(req: NextRequest) {
  try {
    const { message, userId, userName } = await req.json()

    // Verify user authentication
    const supabase = await createServerClient()
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()

    if (authError || !user || user.id !== userId) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Get user's recent mood entries for context
    const { data: recentMoods } = await supabase
      .from("mood_entries")
      .select("mood_score, note, created_at")
      .eq("user_id", userId)
      .order("created_at", { ascending: false })
      .limit(5)

    // Get recent chat history for context
    const { data: recentMessages } = await supabase
      .from("chat_messages")
      .select("content, sender")
      .eq("user_id", userId)
      .order("created_at", { ascending: false })
      .limit(10)

    // Build context for AI
    let contextPrompt = `Você é o MindWave.AI, um assistente empático especializado em saúde mental. 
    
    Características importantes:
    - Sempre responda com empatia e compreensão
    - Use linguagem acolhedora e não julgadora
    - Ofereça suporte prático quando apropriado
    - Identifique sinais de risco e oriente para ajuda profissional quando necessário
    - Mantenha conversas focadas no bem-estar emocional
    - Use emojis ocasionalmente para tornar a conversa mais calorosa
    - Seja conciso mas significativo nas respostas
    - Personalize com base no histórico do usuário
    
    Usuário: ${userName || "Usuário"}`

    if (recentMoods && recentMoods.length > 0) {
      const avgMood = recentMoods.reduce((sum, mood) => sum + mood.mood_score, 0) / recentMoods.length
      contextPrompt += `\n\nHistórico de humor recente (1-10): Média ${avgMood.toFixed(1)}`

      const latestMood = recentMoods[0]
      if (latestMood.note) {
        contextPrompt += `\nÚltima anotação: "${latestMood.note}"`
      }
    }

    if (recentMessages && recentMessages.length > 0) {
      contextPrompt += `\n\nContexto da conversa recente:`
      recentMessages.reverse().forEach((msg, index) => {
        if (index < 4) {
          // Only include last 4 messages for context
          contextPrompt += `\n${msg.sender === "user" ? "Usuário" : "IA"}: ${msg.content}`
        }
      })
    }

    const { text } = await generateText({
      model: openai("gpt-4o"),
      system: contextPrompt,
      prompt: message,
      maxTokens: 500,
    })

    return NextResponse.json({
      response: text,
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("Error in chat API:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}
