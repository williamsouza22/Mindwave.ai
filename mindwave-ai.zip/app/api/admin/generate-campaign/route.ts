import { type NextRequest, NextResponse } from "next/server"
import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"
import { createServerClient } from "@/lib/supabase/server"

export async function POST(req: NextRequest) {
  try {
    const { type, target, prompt } = await req.json()

    const supabase = await createServerClient()
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()

    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Check if user is admin
    const { data: profile } = await supabase.from("users").select("plan").eq("id", user.id).single()

    if (profile?.plan !== "admin") {
      return NextResponse.json({ error: "Admin access required" }, { status: 403 })
    }

    // Campaign type specific prompts
    const typePrompts = {
      email: "Crie um email marketing profissional e envolvente",
      whatsapp: "Crie uma mensagem para WhatsApp casual mas profissional",
      social: "Crie um post para redes sociais engajante e viral",
      blog: "Crie um artigo de blog informativo e otimizado para SEO",
    }

    // Target audience context
    const audienceContext = {
      new_users: "usuários que acabaram de se cadastrar e estão conhecendo a plataforma",
      free_users: "usuários do plano gratuito que podem se interessar por recursos premium",
      premium_users: "usuários premium que já valorizam os recursos avançados",
      churned_users: "usuários que cancelaram a assinatura e podem retornar",
      high_engagement: "usuários muito ativos e engajados com a plataforma",
      low_engagement: "usuários com baixo engajamento que precisam ser reativados",
    }

    const systemPrompt = `Você é um especialista em marketing digital para o MindWave.AI, uma plataforma de saúde mental com IA empática.

    Contexto da empresa:
    - MindWave.AI oferece suporte emocional através de IA conversacional
    - Recursos incluem: check-ins de humor, meditação guiada, fitoterapia, detox digital
    - Público-alvo: pessoas buscando cuidar da saúde mental de forma acessível
    - Tom da marca: empático, acolhedor, profissional mas humano
    - Valores: privacidade, bem-estar, tecnologia humanizada

    Sua tarefa: ${typePrompts[type as keyof typeof typePrompts]} para ${audienceContext[target as keyof typeof audienceContext]}.

    Diretrizes:
    - Use linguagem empática e acolhedora
    - Foque nos benefícios emocionais, não apenas técnicos
    - Inclua call-to-action claro
    - Mantenha o tom profissional mas caloroso
    - Use dados e estatísticas quando relevante
    - Evite linguagem médica ou terapêutica (não somos substitutos para terapia)
    
    ${type === "email" ? "Inclua: assunto, corpo do email, e call-to-action" : ""}
    ${type === "whatsapp" ? "Mantenha conciso (máximo 160 caracteres) e inclua emojis apropriados" : ""}
    ${type === "social" ? "Inclua hashtags relevantes e call-to-action engajante" : ""}
    ${type === "blog" ? "Inclua título SEO-friendly, introdução, desenvolvimento e conclusão" : ""}
    `

    const { text } = await generateText({
      model: openai("gpt-4o"),
      system: systemPrompt,
      prompt: prompt,
      maxTokens: 1000,
    })

    // Save campaign to analytics
    await supabase.from("analytics_events").insert({
      user_id: user.id,
      event_name: "campaign_generated",
      properties: {
        type,
        target,
        prompt,
        generated_length: text.length,
      },
    })

    return NextResponse.json({
      content: text,
      type,
      target,
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("Error generating campaign:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
