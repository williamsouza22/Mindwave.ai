import { type NextRequest, NextResponse } from "next/server"

const WHATSAPP_ACCESS_TOKEN = process.env.WHATSAPP_ACCESS_TOKEN
const WHATSAPP_PHONE_NUMBER_ID = process.env.WHATSAPP_PHONE_NUMBER_ID
const WHATSAPP_API_URL = `https://graph.facebook.com/v18.0/${WHATSAPP_PHONE_NUMBER_ID}/messages`

export async function POST(req: NextRequest) {
  try {
    const { action, variant, timestamp } = await req.json()

    // Log the interaction for analytics
    console.log("WhatsApp interaction:", { action, variant, timestamp })

    // If we have WhatsApp API configured, send automated welcome message
    if (WHATSAPP_ACCESS_TOKEN && WHATSAPP_PHONE_NUMBER_ID) {
      // This would typically be triggered by a webhook when user messages us
      // For now, we'll just log the interaction

      const welcomeTemplate = {
        messaging_product: "whatsapp",
        to: "USER_PHONE_NUMBER", // This would come from webhook
        type: "template",
        template: {
          name: "welcome_mindwave",
          language: {
            code: "pt_BR",
          },
          components: [
            {
              type: "body",
              parameters: [
                {
                  type: "text",
                  text: "MindWave.AI",
                },
              ],
            },
          ],
        },
      }

      // Uncomment when ready to send actual messages
      /*
      const response = await fetch(WHATSAPP_API_URL, {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${WHATSAPP_ACCESS_TOKEN}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify(welcomeTemplate)
      })

      if (!response.ok) {
        throw new Error("Failed to send WhatsApp message")
      }
      */
    }

    return NextResponse.json({
      success: true,
      message: "WhatsApp interaction logged successfully",
    })
  } catch (error) {
    console.error("WhatsApp API error:", error)
    return NextResponse.json({ error: "Failed to process WhatsApp interaction" }, { status: 500 })
  }
}

// Webhook endpoint for receiving WhatsApp messages
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const mode = searchParams.get("hub.mode")
  const token = searchParams.get("hub.verify_token")
  const challenge = searchParams.get("hub.challenge")

  // Verify webhook (required by WhatsApp)
  if (mode === "subscribe" && token === process.env.WHATSAPP_VERIFY_TOKEN) {
    return new Response(challenge, { status: 200 })
  }

  return new Response("Forbidden", { status: 403 })
}
