import { type NextRequest, NextResponse } from "next/server"

// Mock database - in production, use Supabase
const moodData: Array<{
  id: string
  userId: string
  mood: number
  note: string
  date: string
}> = []

export async function POST(req: NextRequest) {
  try {
    const { userId, mood, note } = await req.json()

    const newEntry = {
      id: Date.now().toString(),
      userId,
      mood,
      note,
      date: new Date().toISOString(),
    }

    moodData.push(newEntry)

    return NextResponse.json({
      success: true,
      entry: newEntry,
    })
  } catch (error) {
    console.error("Error saving mood:", error)
    return NextResponse.json({ error: "Erro ao salvar humor" }, { status: 500 })
  }
}

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const userId = searchParams.get("userId")

    if (!userId) {
      return NextResponse.json({ error: "userId é obrigatório" }, { status: 400 })
    }

    const userMoodData = moodData
      .filter((entry) => entry.userId === userId)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
      .slice(0, 30) // Last 30 entries

    return NextResponse.json({
      data: userMoodData,
    })
  } catch (error) {
    console.error("Error fetching mood data:", error)
    return NextResponse.json({ error: "Erro ao buscar dados de humor" }, { status: 500 })
  }
}
