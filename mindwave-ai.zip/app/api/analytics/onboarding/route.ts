import { type NextRequest, NextResponse } from "next/server"
import { createServerClient } from "@/lib/supabase/server"

export async function POST(req: NextRequest) {
  try {
    const { painPoints, goals, notifications } = await req.json()

    const supabase = await createServerClient()
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()

    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Save onboarding analytics
    const { error } = await supabase.from("analytics_events").insert({
      user_id: user.id,
      event_name: "onboarding_completed",
      properties: {
        pain_points: painPoints,
        goals: goals,
        notification_settings: notifications,
        completed_at: new Date().toISOString(),
      },
    })

    if (error) throw error

    // Send welcome notification
    await supabase.from("notifications").insert({
      user_id: user.id,
      type: "success",
      title: "Bem-vindo ao MindWave.AI! 🎉",
      message: "Sua jornada de bem-estar mental começa agora. Explore todas as funcionalidades disponíveis.",
      action_url: "/dashboard",
      action_label: "Ver Dashboard",
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error saving onboarding data:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
