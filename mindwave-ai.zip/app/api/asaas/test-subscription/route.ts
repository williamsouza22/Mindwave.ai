import { type NextRequest, NextResponse } from "next/server"
import { getAsaasConfig, generateValidCpf, generateValidMobilePhone } from "@/lib/asaas/config"

export async function POST(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const environment = (searchParams.get("env") as "sandbox" | "production") || "sandbox"

    const { baseUrl, apiKey } = getAsaasConfig(environment)

    console.log("📋 Testando criação de assinatura...")

    if (!apiKey) {
      return NextResponse.json(
        {
          success: false,
          error: "API Key não configurada",
        },
        { status: 500 },
      )
    }

    const body = await request.json()
    const validCpf = generateValidCpf()
    const validMobilePhone = generateValidMobilePhone()
    const timestamp = Date.now()

    // Primeiro, cria um cliente
    const customerData = {
      name: `Cliente Assinatura ${timestamp}`,
      email: `assinatura-${timestamp}@mindwave.ai`,
      cpfCnpj: validCpf,
      mobilePhone: validMobilePhone,
      address: "Rua Teste, 123",
      addressNumber: "123",
      province: "Centro",
      city: "São Paulo",
      state: "SP",
      postalCode: "01000000",
    }

    console.log("👤 Criando cliente para assinatura...")

    const customerResponse = await fetch(`${baseUrl}/customers`, {
      method: "POST",
      headers: {
        access_token: apiKey,
        "Content-Type": "application/json",
        "User-Agent": "MindWave-Test/1.0",
      },
      body: JSON.stringify(customerData),
    })

    if (!customerResponse.ok) {
      const errorText = await customerResponse.text()
      console.error("❌ Erro ao criar cliente:", errorText)

      let errorData
      try {
        errorData = JSON.parse(errorText)
      } catch {
        errorData = { error: errorText }
      }

      return NextResponse.json(
        {
          success: false,
          error: "Falha ao criar cliente para assinatura",
          details: errorData,
        },
        { status: 500 },
      )
    }

    const customer = await customerResponse.json()
    console.log("✅ Cliente criado:", customer.id)

    // Agora cria a assinatura
    const subscriptionData = {
      customer: customer.id,
      billingType: body.billingType || "PIX",
      value: 29.9,
      nextDueDate: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString().split("T")[0],
      cycle: "MONTHLY",
      description: "Assinatura Premium MindWave.AI",
      externalReference: `subscription-${timestamp}`,
    }

    console.log("📋 Criando assinatura:", subscriptionData)

    const subscriptionResponse = await fetch(`${baseUrl}/subscriptions`, {
      method: "POST",
      headers: {
        access_token: apiKey,
        "Content-Type": "application/json",
        "User-Agent": "MindWave-Test/1.0",
      },
      body: JSON.stringify(subscriptionData),
    })

    console.log("📡 Status da assinatura:", subscriptionResponse.status)

    if (!subscriptionResponse.ok) {
      const errorText = await subscriptionResponse.text()
      console.error("❌ Erro ao criar assinatura:", errorText)

      let errorData
      try {
        errorData = JSON.parse(errorText)
      } catch {
        errorData = { error: errorText }
      }

      return NextResponse.json(
        {
          success: false,
          error: "Falha ao criar assinatura",
          details: errorData,
          customer: customer,
        },
        { status: 500 },
      )
    }

    const subscription = await subscriptionResponse.json()
    console.log("✅ Assinatura criada:", subscription.id)

    return NextResponse.json({
      success: true,
      message: "Assinatura criada com sucesso",
      environment,
      subscriptionId: subscription.id,
      customerId: customer.id,
      subscriptionData: {
        id: subscription.id,
        customer: subscription.customer,
        billingType: subscription.billingType,
        value: subscription.value,
        cycle: subscription.cycle,
        nextDueDate: subscription.nextDueDate,
        status: subscription.status,
        dateCreated: subscription.dateCreated,
      },
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("💥 Erro geral:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Erro interno na criação da assinatura",
        details: error instanceof Error ? error.message : String(error),
      },
      { status: 500 },
    )
  }
}
