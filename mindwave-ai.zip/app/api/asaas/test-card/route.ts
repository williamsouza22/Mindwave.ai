import { type NextRequest, NextResponse } from "next/server"
import { getAsaasConfig, generateValidCpf, generateValidMobilePhone } from "@/lib/asaas/config"

export async function POST(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const environment = (searchParams.get("env") as "sandbox" | "production") || "sandbox"

    const { baseUrl, apiKey } = getAsaasConfig(environment)

    console.log("💳 Testando cartão...")

    if (!apiKey) {
      return NextResponse.json(
        {
          success: false,
          error: "API Key não configurada",
        },
        { status: 500 },
      )
    }

    const body = await request.json()
    const validCpf = generateValidCpf()
    const validMobilePhone = generateValidMobilePhone()
    const timestamp = Date.now()

    // Primeiro, cria um cliente
    const customerData = {
      name: `Cliente Cartão ${timestamp}`,
      email: `cartao-${timestamp}@mindwave.ai`,
      cpfCnpj: validCpf,
      mobilePhone: validMobilePhone,
      address: "Rua Teste, 123",
      addressNumber: "123",
      province: "Centro",
      city: "São Paulo",
      state: "SP",
      postalCode: "01310000", // CEP válido da Av. Paulista, SP
    }

    console.log("👤 Criando cliente...")

    const customerResponse = await fetch(`${baseUrl}/customers`, {
      method: "POST",
      headers: {
        access_token: apiKey,
        "Content-Type": "application/json",
        "User-Agent": "MindWave-Test/1.0",
      },
      body: JSON.stringify(customerData),
    })

    if (!customerResponse.ok) {
      const errorText = await customerResponse.text()
      console.error("❌ Erro ao criar cliente:", errorText)

      let errorData
      try {
        errorData = JSON.parse(errorText)
      } catch {
        errorData = { error: errorText }
      }

      return NextResponse.json(
        {
          success: false,
          error: "Falha ao criar cliente",
          details: errorData,
        },
        { status: 500 },
      )
    }

    const customer = await customerResponse.json()
    console.log("✅ Cliente criado:", customer.id)

    // Agora cria o pagamento com cartão
    const paymentData = {
      customer: customer.id,
      billingType: "CREDIT_CARD",
      value: body.value || 29.9,
      dueDate: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString().split("T")[0],
      description: "Teste Cartão MindWave.AI",
      externalReference: `card-${timestamp}`,
      creditCard: {
        holderName: body.card?.holderName || "TESTE CARTAO",
        number: body.card?.number || "5162306219378829", // Cartão de teste válido
        expiryMonth: body.card?.expiryMonth || "05",
        expiryYear: body.card?.expiryYear || "2030",
        ccv: body.card?.ccv || "318",
      },
      creditCardHolderInfo: {
        name: "TESTE CARTAO",
        email: `cartao-${timestamp}@mindwave.ai`,
        cpfCnpj: validCpf,
        postalCode: "01310000", // CEP válido (8 dígitos, sem hífen)
        address: "Av. Paulista",
        addressNumber: "1000",
        district: "Bela Vista",
        city: "São Paulo",
        state: "SP",
        country: "BRA",
        phone: validMobilePhone,
      },
    }

    console.log("💳 Criando pagamento com cartão...")

    const paymentResponse = await fetch(`${baseUrl}/payments`, {
      method: "POST",
      headers: {
        access_token: apiKey,
        "Content-Type": "application/json",
        "User-Agent": "MindWave-Test/1.0",
      },
      body: JSON.stringify(paymentData),
    })

    if (!paymentResponse.ok) {
      const errorText = await paymentResponse.text()
      console.error("❌ Erro ao processar cartão:", errorText)

      let errorData
      try {
        errorData = JSON.parse(errorText)
      } catch {
        errorData = { error: errorText }
      }

      return NextResponse.json(
        {
          success: false,
          error: "Falha ao processar cartão",
          details: errorData,
        },
        { status: 500 },
      )
    }

    const payment = await paymentResponse.json()
    console.log("✅ Cartão processado:", payment.id)

    return NextResponse.json({
      success: true,
      message: "Cartão processado com sucesso",
      environment,
      paymentId: payment.id,
      customerId: customer.id,
      paymentData: {
        id: payment.id,
        customer: payment.customer,
        billingType: payment.billingType,
        value: payment.value,
        dueDate: payment.dueDate,
        status: payment.status,
        dateCreated: payment.dateCreated,
      },
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("💥 Erro geral:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Erro interno no pagamento com cartão",
        details: error instanceof Error ? error.message : String(error),
      },
      { status: 500 },
    )
  }
}
