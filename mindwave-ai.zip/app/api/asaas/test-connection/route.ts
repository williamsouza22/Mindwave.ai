import { type NextRequest, NextResponse } from "next/server"
import { getAsaasConfig } from "@/lib/asaas/config"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const environment = (searchParams.get("env") as "sandbox" | "production") || "sandbox"

    console.log("🔧 Testando conexão com Asaas...")
    console.log("Environment solicitado:", environment)
    console.log("ASAAS_SANDBOX_API_KEY exists:", !!process.env.ASAAS_SANDBOX_API_KEY)
    console.log("ASAAS_API_KEY exists:", !!process.env.ASAAS_API_KEY)

    const { baseUrl, apiKey, environment: finalEnv } = getAsaasConfig(environment)

    console.log("Environment final:", finalEnv)
    console.log("Base URL:", baseUrl)
    console.log("API Key length:", apiKey?.length || 0)
    console.log("API Key prefix:", apiKey?.substring(0, 20) + "...")

    if (!apiKey) {
      return NextResponse.json(
        {
          success: false,
          error: "API Key não configurada",
          details: {
            message: "Verifique as variáveis de ambiente ASAAS_SANDBOX_API_KEY ou ASAAS_API_KEY",
            environment: environment,
            hasAsaasSandboxKey: !!process.env.ASAAS_SANDBOX_API_KEY,
            hasAsaasKey: !!process.env.ASAAS_API_KEY,
          },
        },
        { status: 500 },
      )
    }

    // Testa a conexão fazendo uma requisição simples
    const response = await fetch(`${baseUrl}/customers?limit=1`, {
      method: "GET",
      headers: {
        access_token: apiKey,
        "Content-Type": "application/json",
        "User-Agent": "MindWave-Test/1.0",
      },
    })

    console.log("📡 Status da resposta:", response.status)
    console.log("📡 Headers da resposta:", Object.fromEntries(response.headers.entries()))

    if (!response.ok) {
      const errorText = await response.text()
      console.error("❌ Erro na conexão:", errorText)

      let errorData
      try {
        errorData = JSON.parse(errorText)
      } catch {
        errorData = { error: errorText }
      }

      return NextResponse.json(
        {
          success: false,
          error: "Falha na conexão com Asaas",
          details: {
            ...errorData,
            status: response.status,
            baseUrl: baseUrl,
            environment: finalEnv,
            apiKeyPrefix: apiKey.substring(0, 20) + "...",
          },
        },
        { status: 500 },
      )
    }

    const data = await response.json()
    console.log("✅ Conexão estabelecida com sucesso")
    console.log("📊 Dados recebidos:", data)

    return NextResponse.json({
      success: true,
      message: "Conexão com Asaas estabelecida com sucesso",
      environment: finalEnv,
      baseUrl,
      data: {
        totalCount: data.totalCount || 0,
        hasMore: data.hasMore || false,
        limit: data.limit || 1,
      },
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("💥 Erro geral na conexão:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Erro interno na conexão",
        details: {
          message: error instanceof Error ? error.message : String(error),
          stack: error instanceof Error ? error.stack : undefined,
        },
      },
      { status: 500 },
    )
  }
}
