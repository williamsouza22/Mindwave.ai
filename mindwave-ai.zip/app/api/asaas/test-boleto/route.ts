import { type NextRequest, NextResponse } from "next/server"
import { getAsaasConfig, generateValidCpf, generateValidMobilePhone } from "@/lib/asaas/config"

export async function POST(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const environment = (searchParams.get("env") as "sandbox" | "production") || "sandbox"

    const { baseUrl, apiKey } = getAsaasConfig(environment)

    console.log("🧾 Testando pagamento com boleto...")

    if (!apiKey) {
      return NextResponse.json(
        {
          success: false,
          error: "API Key não configurada",
        },
        { status: 500 },
      )
    }

    const body = await request.json()
    const validCpf = generateValidCpf()
    const validMobilePhone = generateValidMobilePhone()
    const timestamp = Date.now()

    // Primeiro, cria um cliente
    const customerData = {
      name: `Cliente Boleto ${timestamp}`,
      email: `boleto-${timestamp}@mindwave.ai`,
      cpfCnpj: validCpf,
      mobilePhone: validMobilePhone,
      address: "Rua Teste, 123",
      addressNumber: "123",
      province: "Centro",
      city: "São Paulo",
      state: "SP",
      postalCode: "01000000",
    }

    console.log("👤 Criando cliente para boleto...")

    const customerResponse = await fetch(`${baseUrl}/customers`, {
      method: "POST",
      headers: {
        access_token: apiKey,
        "Content-Type": "application/json",
        "User-Agent": "MindWave-Test/1.0",
      },
      body: JSON.stringify(customerData),
    })

    if (!customerResponse.ok) {
      const errorText = await customerResponse.text()
      console.error("❌ Erro ao criar cliente:", errorText)

      let errorData
      try {
        errorData = JSON.parse(errorText)
      } catch {
        errorData = { error: errorText }
      }

      return NextResponse.json(
        {
          success: false,
          error: "Falha ao criar cliente para boleto",
          details: errorData,
        },
        { status: 500 },
      )
    }

    const customer = await customerResponse.json()
    console.log("✅ Cliente criado:", customer.id)

    // Agora cria o pagamento com boleto
    const paymentData = {
      customer: customer.id,
      billingType: "BOLETO",
      value: body.value || 29.9,
      dueDate: body.dueDate || new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
      description: "Teste Boleto MindWave.AI",
      externalReference: `boleto-${timestamp}`,
    }

    console.log("🧾 Criando pagamento com boleto:", paymentData)

    const paymentResponse = await fetch(`${baseUrl}/payments`, {
      method: "POST",
      headers: {
        access_token: apiKey,
        "Content-Type": "application/json",
        "User-Agent": "MindWave-Test/1.0",
      },
      body: JSON.stringify(paymentData),
    })

    console.log("📡 Status do boleto:", paymentResponse.status)

    if (!paymentResponse.ok) {
      const errorText = await paymentResponse.text()
      console.error("❌ Erro ao criar boleto:", errorText)

      let errorData
      try {
        errorData = JSON.parse(errorText)
      } catch {
        errorData = { error: errorText }
      }

      return NextResponse.json(
        {
          success: false,
          error: "Falha ao criar pagamento com boleto",
          details: errorData,
          customer: customer,
        },
        { status: 500 },
      )
    }

    const payment = await paymentResponse.json()
    console.log("✅ Boleto criado:", payment.id)

    return NextResponse.json({
      success: true,
      message: "Boleto gerado com sucesso",
      environment,
      paymentId: payment.id,
      customerId: customer.id,
      boletoUrl: payment.bankSlipUrl || payment.invoiceUrl,
      paymentData: {
        id: payment.id,
        customer: payment.customer,
        billingType: payment.billingType,
        value: payment.value,
        dueDate: payment.dueDate,
        status: payment.status,
        bankSlipUrl: payment.bankSlipUrl,
        invoiceUrl: payment.invoiceUrl,
        dateCreated: payment.dateCreated,
      },
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("💥 Erro geral:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Erro interno no pagamento com boleto",
        details: error instanceof Error ? error.message : String(error),
      },
      { status: 500 },
    )
  }
}
