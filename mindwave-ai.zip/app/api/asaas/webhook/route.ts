import { type NextRequest, NextResponse } from "next/server"
import { createServerClient } from "@/lib/supabase/server"

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { event, payment, subscription } = body

    const supabase = await createServerClient()

    switch (event) {
      case "PAYMENT_CONFIRMED":
        // Payment was confirmed
        if (subscription?.id) {
          // Update subscription status
          await supabase
            .from("subscriptions")
            .update({
              status: "active",
              last_payment_date: new Date().toISOString(),
            })
            .eq("asaas_subscription_id", subscription.id)

          // Update user plan
          const { data: subscriptionData } = await supabase
            .from("subscriptions")
            .select("user_id, plan_id")
            .eq("asaas_subscription_id", subscription.id)
            .single()

          if (subscriptionData) {
            await supabase.from("users").update({ plan: subscriptionData.plan_id }).eq("id", subscriptionData.user_id)

            // Send welcome notification
            await supabase.from("notifications").insert({
              user_id: subscriptionData.user_id,
              type: "success",
              title: "Pagamento confirmado! 🎉",
              message: "Seu plano foi ativado com sucesso. Aproveite todos os recursos premium!",
              action_url: "/dashboard",
              action_label: "Ver Dashboard",
            })
          }
        }
        break

      case "PAYMENT_OVERDUE":
        // Payment is overdue
        if (subscription?.id) {
          await supabase
            .from("subscriptions")
            .update({ status: "overdue" })
            .eq("asaas_subscription_id", subscription.id)

          // Send overdue notification
          const { data: subscriptionData } = await supabase
            .from("subscriptions")
            .select("user_id")
            .eq("asaas_subscription_id", subscription.id)
            .single()

          if (subscriptionData) {
            await supabase.from("notifications").insert({
              user_id: subscriptionData.user_id,
              type: "warning",
              title: "Pagamento em atraso ⚠️",
              message: "Seu pagamento está em atraso. Regularize para continuar usando os recursos premium.",
              action_url: "/settings/billing",
              action_label: "Ver Cobrança",
            })
          }
        }
        break

      case "PAYMENT_DELETED":
      case "SUBSCRIPTION_DELETED":
        // Subscription was cancelled
        if (subscription?.id) {
          await supabase
            .from("subscriptions")
            .update({ status: "cancelled" })
            .eq("asaas_subscription_id", subscription.id)

          // Downgrade user to free plan
          const { data: subscriptionData } = await supabase
            .from("subscriptions")
            .select("user_id")
            .eq("asaas_subscription_id", subscription.id)
            .single()

          if (subscriptionData) {
            await supabase.from("users").update({ plan: "free" }).eq("id", subscriptionData.user_id)

            await supabase.from("notifications").insert({
              user_id: subscriptionData.user_id,
              type: "info",
              title: "Assinatura cancelada",
              message: "Sua assinatura foi cancelada. Você ainda pode usar os recursos gratuitos.",
              action_url: "/pricing",
              action_label: "Ver Planos",
            })
          }
        }
        break
    }

    return NextResponse.json({ received: true })
  } catch (error) {
    console.error("Webhook error:", error)
    return NextResponse.json({ error: "Webhook processing failed" }, { status: 500 })
  }
}
