import { type NextRequest, NextResponse } from "next/server"
import { getAsaasConfig, generateValidCpf, generateValidMobilePhone } from "@/lib/asaas/config"

export async function POST(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const environment = (searchParams.get("env") as "sandbox" | "production") || "sandbox"

    const { baseUrl, apiKey } = getAsaasConfig(environment)

    console.log("👤 Testando criação de cliente...")
    console.log("Environment:", environment)
    console.log("Base URL:", baseUrl)
    console.log("API Key exists:", !!apiKey)

    if (!apiKey) {
      return NextResponse.json(
        {
          success: false,
          error: "API Key não configurada",
          details: "Verifique as variáveis de ambiente",
        },
        { status: 500 },
      )
    }

    const body = await request.json()
    const validCpf = generateValidCpf()
    const validMobilePhone = generateValidMobilePhone()
    const timestamp = Date.now()

    const customerData = {
      name: body.name || `Cliente Teste ${timestamp}`,
      email: body.email || `teste-${timestamp}@mindwave.ai`,
      cpfCnpj: validCpf,
      mobilePhone: validMobilePhone,
      address: "Rua Teste, 123",
      addressNumber: "123",
      province: "Centro",
      city: "São Paulo",
      state: "SP",
      postalCode: "01000000",
    }

    console.log("📝 Dados do cliente:", customerData)

    const response = await fetch(`${baseUrl}/customers`, {
      method: "POST",
      headers: {
        access_token: apiKey,
        "Content-Type": "application/json",
        "User-Agent": "MindWave-Test/1.0",
      },
      body: JSON.stringify(customerData),
    })

    console.log("📡 Status da criação:", response.status)

    if (!response.ok) {
      const errorText = await response.text()
      console.error("❌ Erro ao criar cliente:", errorText)

      let errorData
      try {
        errorData = JSON.parse(errorText)
      } catch {
        errorData = { error: errorText }
      }

      return NextResponse.json(
        {
          success: false,
          error: "Falha ao criar cliente",
          details: {
            ...errorData,
            customerData: customerData,
            baseUrl: baseUrl,
          },
        },
        { status: 500 },
      )
    }

    const customer = await response.json()
    console.log("✅ Cliente criado:", customer.id)

    return NextResponse.json({
      success: true,
      message: "Cliente criado com sucesso",
      environment,
      customerId: customer.id,
      customerData: {
        id: customer.id,
        name: customer.name,
        email: customer.email,
        cpfCnpj: customer.cpfCnpj,
        mobilePhone: customer.mobilePhone,
        dateCreated: customer.dateCreated,
      },
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("💥 Erro geral:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Erro interno na criação do cliente",
        details: error instanceof Error ? error.message : String(error),
      },
      { status: 500 },
    )
  }
}
