import { type NextRequest, NextResponse } from "next/server"
import { createServerClient } from "@/lib/supabase/server"
import { getAsaasConfig } from "@/lib/asaas/config"

interface AsaasCustomer {
  id: string
  name: string
  email: string
}

interface AsaasSubscription {
  id: string
  customer: string
  billingType: string
  value: number
  nextDueDate: string
  cycle: string
  description: string
  status: string
}

export async function POST(req: NextRequest) {
  try {
    const { planId, billingType = "PIX" } = await req.json()
    console.log("Iniciando criação de subscription:", { planId, billingType })

    // Usar configuração do Asaas
    const config = getAsaasConfig("sandbox") // Forçar sandbox por enquanto

    if (!config.apiKey) {
      console.error("❌ API Key não configurada")
      return NextResponse.json(
        {
          error: "API Key do Asaas não configurada",
          details: "Verifique as variáveis ASAAS_API_KEY ou ASAAS_SANDBOX_API_KEY",
        },
        { status: 500 },
      )
    }

    console.log("🔧 Configuração Asaas:")
    console.log("- Environment:", config.environment)
    console.log("- Base URL:", config.baseUrl)
    console.log("- API Key exists:", !!config.apiKey)
    console.log("- API Key prefix:", config.apiKey?.substring(0, 10) + "...")

    const supabase = await createServerClient()
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()

    if (authError || !user) {
      console.error("❌ Erro de autenticação:", authError)
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Get user profile
    const { data: profile } = await supabase.from("users").select("name, email").eq("id", user.id).single()

    if (!profile) {
      console.error("❌ Perfil do usuário não encontrado")
      return NextResponse.json({ error: "User profile not found" }, { status: 404 })
    }

    console.log("Perfil do usuário:", profile)

    // Plan configurations
    const plans = {
      premium: {
        value: 29.9,
        description: "MindWave.AI Premium - Plano Mensal",
        cycle: "MONTHLY",
      },
      family: {
        value: 79.9,
        description: "MindWave.AI Família - Plano Mensal",
        cycle: "MONTHLY",
      },
    }

    const selectedPlan = plans[planId as keyof typeof plans]
    if (!selectedPlan) {
      return NextResponse.json({ error: "Invalid plan" }, { status: 400 })
    }

    // Create or get customer in Asaas
    let customer: AsaasCustomer

    // First, try to find existing customer
    console.log("🔍 Buscando cliente existente...")
    const existingCustomerResponse = await fetch(`${config.baseUrl}/customers?email=${profile.email}`, {
      headers: {
        "Content-Type": "application/json",
        access_token: config.apiKey,
      },
    })

    if (!existingCustomerResponse.ok) {
      const errorText = await existingCustomerResponse.text()
      console.error("Error searching customer:", errorText)
      return NextResponse.json(
        {
          error: "Failed to search customer",
          details: errorText,
        },
        { status: 500 },
      )
    }

    const existingCustomerData = await existingCustomerResponse.json()

    if (existingCustomerData.data && existingCustomerData.data.length > 0) {
      customer = existingCustomerData.data[0]
      console.log("✅ Cliente existente encontrado:", customer.id)
    } else {
      // Create new customer
      console.log("👤 Criando novo cliente...")
      const customerResponse = await fetch(`${config.baseUrl}/customers`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          access_token: config.apiKey,
        },
        body: JSON.stringify({
          name: profile.name || "Usuário MindWave.AI",
          email: profile.email,
          mobilePhone: "",
          cpfCnpj: "",
          postalCode: "",
          address: "",
          addressNumber: "",
          complement: "",
          province: "",
          city: "",
          state: "",
          country: "Brasil",
        }),
      })

      if (!customerResponse.ok) {
        const error = await customerResponse.text()
        console.error("Error creating customer:", error)
        return NextResponse.json(
          {
            error: "Failed to create customer",
            details: error,
          },
          { status: 500 },
        )
      }

      customer = await customerResponse.json()
      console.log("✅ Novo cliente criado:", customer.id)
    }

    // Create subscription
    console.log("📋 Criando subscription...")
    const subscriptionResponse = await fetch(`${config.baseUrl}/subscriptions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        access_token: config.apiKey,
      },
      body: JSON.stringify({
        customer: customer.id,
        billingType: billingType,
        value: selectedPlan.value,
        nextDueDate: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString().split("T")[0], // Tomorrow
        cycle: selectedPlan.cycle,
        description: selectedPlan.description,
        endDate: null, // Indefinite subscription
        maxPayments: null,
        externalReference: user.id,
      }),
    })

    if (!subscriptionResponse.ok) {
      const error = await subscriptionResponse.text()
      console.error("Error creating subscription:", error)
      return NextResponse.json(
        {
          error: "Failed to create subscription",
          details: error,
        },
        { status: 500 },
      )
    }

    const subscription: AsaasSubscription = await subscriptionResponse.json()
    console.log("✅ Subscription criada:", subscription.id)

    // Save subscription to database
    const { error: dbError } = await supabase.from("subscriptions").insert({
      user_id: user.id,
      asaas_subscription_id: subscription.id,
      asaas_customer_id: customer.id,
      plan_id: planId,
      status: subscription.status,
      amount: selectedPlan.value,
      billing_type: billingType,
      next_due_date: subscription.nextDueDate,
      created_at: new Date().toISOString(),
    })

    if (dbError) {
      console.error("Error saving subscription to database:", dbError)
    }

    // Generate payment link for the first payment
    console.log("💰 Gerando primeiro pagamento...")
    const paymentResponse = await fetch(`${config.baseUrl}/payments`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        access_token: config.apiKey,
      },
      body: JSON.stringify({
        customer: customer.id,
        billingType: billingType,
        value: selectedPlan.value,
        dueDate: subscription.nextDueDate,
        description: `${selectedPlan.description} - Primeiro Pagamento`,
        externalReference: `${user.id}_${subscription.id}_first`,
      }),
    })

    const payment = await paymentResponse.json()

    return NextResponse.json({
      subscriptionId: subscription.id,
      paymentId: payment.id,
      paymentUrl: payment.invoiceUrl,
      pixCode: payment.pixTransaction?.qrCode?.payload,
      pixQrCode: payment.pixTransaction?.qrCode?.encodedImage,
    })
  } catch (error) {
    console.error("Error creating subscription:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
