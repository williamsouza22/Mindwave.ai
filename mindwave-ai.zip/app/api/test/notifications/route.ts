import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { type, userId } = body

    console.log("📧 Testando sistema de notificações...")
    console.log("Tipo:", type)
    console.log("User ID:", userId)

    // Simula envio de notificações
    await new Promise((resolve) => setTimeout(resolve, 600))

    const notificationChannels = [
      {
        channel: "email",
        status: "sent",
        recipient: "user@mindwave.ai",
        template: `${type}_email_template`,
        sentAt: new Date().toISOString(),
      },
      {
        channel: "whatsapp",
        status: "sent",
        recipient: "+5511999999999",
        template: `${type}_whatsapp_template`,
        sentAt: new Date().toISOString(),
      },
      {
        channel: "push",
        status: "sent",
        recipient: userId,
        template: `${type}_push_template`,
        sentAt: new Date().toISOString(),
      },
      {
        channel: "in_app",
        status: "sent",
        recipient: userId,
        template: `${type}_in_app_template`,
        sentAt: new Date().toISOString(),
      },
    ]

    console.log("✅ Notificações enviadas:", notificationChannels.length)

    // Simula estatísticas de entrega
    const deliveryStats = {
      total: notificationChannels.length,
      sent: notificationChannels.filter((n) => n.status === "sent").length,
      delivered: Math.floor(notificationChannels.length * 0.95),
      opened: Math.floor(notificationChannels.length * 0.7),
      clicked: Math.floor(notificationChannels.length * 0.3),
    }

    return NextResponse.json({
      success: true,
      message: "Notificação enviada com sucesso",
      details: {
        type: type,
        userId: userId,
        channels: notificationChannels,
        stats: deliveryStats,
        features: {
          emailEnabled: true,
          whatsappEnabled: !!process.env.WHATSAPP_ACCESS_TOKEN,
          pushEnabled: true,
          inAppEnabled: true,
        },
      },
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("💥 Erro nas notificações:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Erro no sistema de notificações",
        details: error instanceof Error ? error.message : String(error),
      },
      { status: 500 },
    )
  }
}
