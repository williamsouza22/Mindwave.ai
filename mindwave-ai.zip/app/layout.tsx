import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { ThemeProvider } from "@/components/theme-provider"
import { Toaster } from "@/components/ui/toaster"
import { AnalyticsProvider } from "@/components/analytics/analytics-provider"
import { AuthProvider } from "@/lib/auth/auth-context"
import { Suspense } from "react"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "MindWave.AI - Bem-estar Emocional com Inteligência Artificial",
  description:
    "Transforme sua saúde mental com IA. Chat 24/7, detox digital, fitoterapia e exercícios personalizados. Comece grátis!",
  keywords:
    "bem-estar emocional, saúde mental, inteligência artificial, chat IA, detox digital, fitoterapia, mindfulness",
  authors: [{ name: "MindWave.AI Team" }],
  creator: "MindWave.AI",
  publisher: "MindWave.AI",
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  metadataBase: new URL("https://mindwave.ai"),
  alternates: {
    canonical: "/",
  },
  openGraph: {
    title: "MindWave.AI - Bem-estar Emocional com IA",
    description:
      "Transforme sua saúde mental com nossa plataforma de IA. Chat 24/7, módulos personalizados e acompanhamento completo.",
    url: "https://mindwave.ai",
    siteName: "MindWave.AI",
    images: [
      {
        url: "/og-image.jpg",
        width: 1200,
        height: 630,
        alt: "MindWave.AI - Plataforma de Bem-estar Emocional",
      },
    ],
    locale: "pt_BR",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "MindWave.AI - Bem-estar Emocional com IA",
    description: "Transforme sua saúde mental com nossa plataforma de IA. Comece grátis!",
    images: ["/twitter-image.jpg"],
    creator: "@mindwaveai",
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  verification: {
    google: "your-google-verification-code",
  },
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="pt-BR" suppressHydrationWarning>
      <head>
        <link rel="icon" href="/favicon.ico" />
        <link rel="apple-touch-icon" href="/apple-touch-icon.png" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="theme-color" content="#7c3aed" />

        {/* Structured Data */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "SoftwareApplication",
              name: "MindWave.AI",
              description: "Plataforma de bem-estar emocional com inteligência artificial",
              url: "https://mindwave.ai",
              applicationCategory: "HealthApplication",
              operatingSystem: "Web",
              offers: {
                "@type": "Offer",
                price: "29.90",
                priceCurrency: "BRL",
                availability: "https://schema.org/InStock",
              },
              aggregateRating: {
                "@type": "AggregateRating",
                ratingValue: "4.8",
                ratingCount: "1250",
              },
            }),
          }}
        />
      </head>
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="dark" enableSystem disableTransitionOnChange>
          <AnalyticsProvider measurementId={process.env.NEXT_PUBLIC_GA_MEASUREMENT_ID || "G-XXXXXXXXXX"}>
            <AuthProvider>
              <Suspense fallback={null}>
                {children}
                <Toaster />
              </Suspense>
            </AuthProvider>
          </AnalyticsProvider>
        </ThemeProvider>
      </body>
    </html>
  )
}
