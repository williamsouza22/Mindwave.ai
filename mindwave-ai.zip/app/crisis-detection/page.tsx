"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import {
  AlertTriangle,
  Phone,
  MessageCircle,
  Heart,
  Shield,
  Clock,
  Users,
  Activity,
  TrendingDown,
  Bell,
} from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Progress } from "@/components/ui/progress"
import { SidebarProvider, SidebarInset } from "@/components/ui/sidebar"
import { UserSidebar } from "@/components/dashboard/user-sidebar"
import { ModernDashboardHeader } from "@/components/dashboard/modern-dashboard-header"

interface CrisisAlert {
  id: string
  level: "low" | "medium" | "high" | "critical"
  message: string
  timestamp: Date
  triggers: string[]
  recommendations: string[]
}

interface RiskFactor {
  name: string
  level: number
  trend: "up" | "down" | "stable"
  description: string
}

export default function CrisisDetectionPage() {
  const [currentRiskLevel, setCurrentRiskLevel] = useState<"low" | "medium" | "high" | "critical">("low")
  const [alerts, setAlerts] = useState<CrisisAlert[]>([])
  const [isMonitoring, setIsMonitoring] = useState(true)

  // Dados simulados
  const riskFactors: RiskFactor[] = [
    {
      name: "Ansiedade",
      level: 35,
      trend: "down",
      description: "Níveis de ansiedade estão diminuindo gradualmente",
    },
    {
      name: "Isolamento Social",
      level: 60,
      trend: "up",
      description: "Redução nas interações sociais detectada",
    },
    {
      name: "Padrões de Sono",
      level: 45,
      trend: "stable",
      description: "Qualidade do sono mantida dentro da normalidade",
    },
    {
      name: "Humor Depressivo",
      level: 25,
      trend: "down",
      description: "Sinais de melhora no humor geral",
    },
  ]

  const emergencyContacts = [
    {
      name: "CVV - Centro de Valorização da Vida",
      phone: "188",
      description: "Apoio emocional e prevenção do suicídio",
      available: "24h",
    },
    {
      name: "CAPS - Centro de Atenção Psicossocial",
      phone: "0800-644-0011",
      description: "Atendimento em saúde mental",
      available: "Seg-Sex 8h-17h",
    },
    {
      name: "SAMU",
      phone: "192",
      description: "Emergências médicas",
      available: "24h",
    },
  ]

  const recentAlerts: CrisisAlert[] = [
    {
      id: "1",
      level: "medium",
      message: "Padrão de isolamento social detectado nos últimos 3 dias",
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
      triggers: ["Cancelamento de compromissos", "Redução em mensagens"],
      recommendations: ["Conversar com um amigo", "Participar de atividade social", "Agendar consulta"],
    },
    {
      id: "2",
      level: "low",
      message: "Melhora detectada nos padrões de humor",
      timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000),
      triggers: ["Exercícios regulares", "Meditação diária"],
      recommendations: ["Manter rotina atual", "Celebrar progresso"],
    },
  ]

  const getRiskLevelColor = (level: string) => {
    switch (level) {
      case "low":
        return "text-green-400 bg-green-500/20 border-green-500/30"
      case "medium":
        return "text-yellow-400 bg-yellow-500/20 border-yellow-500/30"
      case "high":
        return "text-orange-400 bg-orange-500/20 border-orange-500/30"
      case "critical":
        return "text-red-400 bg-red-500/20 border-red-500/30"
      default:
        return "text-gray-400 bg-gray-500/20 border-gray-500/30"
    }
  }

  const getRiskLevelText = (level: string) => {
    switch (level) {
      case "low":
        return "Baixo Risco"
      case "medium":
        return "Risco Moderado"
      case "high":
        return "Alto Risco"
      case "critical":
        return "Risco Crítico"
      default:
        return "Desconhecido"
    }
  }

  const handleEmergencyCall = (phone: string) => {
    window.open(`tel:${phone}`, "_self")
  }

  const handleWhatsAppSupport = () => {
    const message = encodeURIComponent("🚨 Preciso de apoio emocional urgente. Por favor, me ajudem.")
    const whatsappUrl = `https://wa.me/5511999999999?text=${message}`
    window.open(whatsappUrl, "_blank", "noopener,noreferrer")
  }

  return (
    <SidebarProvider>
      <div className="layout">
        <UserSidebar />
        <SidebarInset className="conteudo">
          <ModernDashboardHeader
            title="Detecção de Crise"
            subtitle="Monitoramento inteligente para sua segurança emocional"
            breadcrumbs={[
              { label: "Dashboard", href: "/dashboard" },
              { label: "Detecção de Crise", href: "/crisis-detection" },
            ]}
          />

          <div className="p-6 space-y-6 max-w-full">
            {/* Current Risk Status */}
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
              <Card className={`border-2 ${getRiskLevelColor(currentRiskLevel)}`}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-white flex items-center">
                      <Shield className="mr-2 h-5 w-5" />
                      Status Atual de Risco
                    </CardTitle>
                    <Badge className={getRiskLevelColor(currentRiskLevel)}>{getRiskLevelText(currentRiskLevel)}</Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="text-center">
                      <div className="text-4xl mb-2">
                        {currentRiskLevel === "low"
                          ? "🟢"
                          : currentRiskLevel === "medium"
                            ? "🟡"
                            : currentRiskLevel === "high"
                              ? "🟠"
                              : "🔴"}
                      </div>
                      <p className="text-white font-semibold">{getRiskLevelText(currentRiskLevel)}</p>
                      <p className="text-gray-400 text-sm">Monitoramento ativo</p>
                    </div>

                    <div className="space-y-3">
                      <div className="flex items-center text-gray-300">
                        <Clock className="mr-2 h-4 w-4 text-blue-400" />
                        <span className="text-sm">Última análise: há 5 minutos</span>
                      </div>
                      <div className="flex items-center text-gray-300">
                        <Activity className="mr-2 h-4 w-4 text-green-400" />
                        <span className="text-sm">Sistema: {isMonitoring ? "Ativo" : "Pausado"}</span>
                      </div>
                      <div className="flex items-center text-gray-300">
                        <Bell className="mr-2 h-4 w-4 text-purple-400" />
                        <span className="text-sm">Alertas: {recentAlerts.length} recentes</span>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Button
                        onClick={handleWhatsAppSupport}
                        className="w-full bg-green-600 hover:bg-green-700 text-white"
                      >
                        <MessageCircle className="mr-2 h-4 w-4" />
                        Apoio Imediato
                      </Button>
                      <Button
                        variant="outline"
                        onClick={() => setIsMonitoring(!isMonitoring)}
                        className="w-full border-gray-600 text-gray-300"
                      >
                        {isMonitoring ? "Pausar" : "Ativar"} Monitoramento
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Emergency Contacts */}
            {(currentRiskLevel === "high" || currentRiskLevel === "critical") && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.1 }}
              >
                <Alert className="border-red-500/50 bg-red-500/10">
                  <AlertTriangle className="h-4 w-4 text-red-400" />
                  <AlertTitle className="text-red-400">Contatos de Emergência</AlertTitle>
                  <AlertDescription className="text-gray-300 mt-2">
                    Se você está em crise, não hesite em buscar ajuda profissional imediatamente.
                  </AlertDescription>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
                    {emergencyContacts.map((contact) => (
                      <Card key={contact.name} className="bg-gray-800/50 border-gray-700/50">
                        <CardContent className="p-4">
                          <h4 className="text-white font-medium mb-2">{contact.name}</h4>
                          <p className="text-gray-400 text-sm mb-3">{contact.description}</p>
                          <div className="flex items-center justify-between">
                            <span className="text-xs text-gray-500">{contact.available}</span>
                            <Button
                              size="sm"
                              onClick={() => handleEmergencyCall(contact.phone)}
                              className="bg-red-600 hover:bg-red-700 text-white"
                            >
                              <Phone className="mr-1 h-3 w-3" />
                              {contact.phone}
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </Alert>
              </motion.div>
            )}

            {/* Risk Factors */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <Card className="bg-gray-800/50 border-gray-700/50">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <TrendingDown className="mr-2 h-5 w-5 text-orange-400" />
                    Fatores de Risco
                  </CardTitle>
                  <CardDescription>Monitoramento contínuo dos principais indicadores</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {riskFactors.map((factor) => (
                      <div key={factor.name} className="p-4 bg-gray-700/30 rounded-lg">
                        <div className="flex items-center justify-between mb-3">
                          <h4 className="text-white font-medium">{factor.name}</h4>
                          <Badge
                            className={`${
                              factor.trend === "up"
                                ? "bg-red-500/20 text-red-400"
                                : factor.trend === "down"
                                  ? "bg-green-500/20 text-green-400"
                                  : "bg-yellow-500/20 text-yellow-400"
                            }`}
                          >
                            {factor.trend === "up" ? "↗️" : factor.trend === "down" ? "↘️" : "→"}
                          </Badge>
                        </div>

                        <div className="mb-3">
                          <div className="flex justify-between text-sm text-gray-400 mb-1">
                            <span>Nível de Risco</span>
                            <span>{factor.level}%</span>
                          </div>
                          <Progress
                            value={factor.level}
                            className={`h-2 ${
                              factor.level > 70
                                ? "[&>div]:bg-red-500"
                                : factor.level > 40
                                  ? "[&>div]:bg-yellow-500"
                                  : "[&>div]:bg-green-500"
                            }`}
                          />
                        </div>

                        <p className="text-sm text-gray-400">{factor.description}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Recent Alerts */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
            >
              <Card className="bg-gray-800/50 border-gray-700/50">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <Bell className="mr-2 h-5 w-5 text-purple-400" />
                    Alertas Recentes
                  </CardTitle>
                  <CardDescription>Histórico de detecções e recomendações</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {recentAlerts.map((alert) => (
                      <div key={alert.id} className="p-4 bg-gray-700/30 rounded-lg">
                        <div className="flex items-start justify-between mb-3">
                          <div className="flex-1">
                            <div className="flex items-center mb-2">
                              <Badge className={getRiskLevelColor(alert.level)}>{getRiskLevelText(alert.level)}</Badge>
                              <span className="text-gray-400 text-sm ml-3">
                                {alert.timestamp.toLocaleString("pt-BR")}
                              </span>
                            </div>
                            <p className="text-white">{alert.message}</p>
                          </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <h5 className="text-sm font-medium text-gray-300 mb-2">Gatilhos Detectados:</h5>
                            <div className="flex flex-wrap gap-1">
                              {alert.triggers.map((trigger) => (
                                <Badge key={trigger} variant="outline" className="text-xs">
                                  {trigger}
                                </Badge>
                              ))}
                            </div>
                          </div>

                          <div>
                            <h5 className="text-sm font-medium text-gray-300 mb-2">Recomendações:</h5>
                            <ul className="text-sm text-gray-400 space-y-1">
                              {alert.recommendations.map((rec, index) => (
                                <li key={index} className="flex items-start">
                                  <span className="text-blue-400 mr-2">•</span>
                                  {rec}
                                </li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Support Resources */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
            >
              <Card className="bg-gray-800/50 border-gray-700/50">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <Users className="mr-2 h-5 w-5 text-green-400" />
                    Recursos de Apoio
                  </CardTitle>
                  <CardDescription>Ferramentas e técnicas para momentos difíceis</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <Button
                      variant="outline"
                      className="h-auto p-4 flex flex-col items-center space-y-2 border-blue-500/50 hover:bg-blue-500/10 bg-transparent"
                    >
                      <Heart className="h-6 w-6 text-blue-400" />
                      <span className="text-white">Respiração Guiada</span>
                      <span className="text-xs text-gray-400">Técnica 4-7-8</span>
                    </Button>

                    <Button
                      variant="outline"
                      className="h-auto p-4 flex flex-col items-center space-y-2 border-purple-500/50 hover:bg-purple-500/10 bg-transparent"
                    >
                      <MessageCircle className="h-6 w-6 text-purple-400" />
                      <span className="text-white">Chat de Apoio</span>
                      <span className="text-xs text-gray-400">Disponível 24h</span>
                    </Button>

                    <Button
                      variant="outline"
                      className="h-auto p-4 flex flex-col items-center space-y-2 border-green-500/50 hover:bg-green-500/10 bg-transparent"
                    >
                      <Users className="h-6 w-6 text-green-400" />
                      <span className="text-white">Grupo de Apoio</span>
                      <span className="text-xs text-gray-400">Comunidade</span>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </SidebarInset>
      </div>
    </SidebarProvider>
  )
}
