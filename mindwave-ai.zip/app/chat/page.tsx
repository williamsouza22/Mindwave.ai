"use client"

import { useState, useRef, useEffect } from "react"
import { motion } from "framer-motion"
import { Send, Mic, MicOff, Heart, Brain, Sparkles, MessageCircle, User, Bot } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { SidebarProvider, SidebarInset } from "@/components/ui/sidebar"
import { UserSidebar } from "@/components/dashboard/user-sidebar"
import { ModernDashboardHeader } from "@/components/dashboard/modern-dashboard-header"

interface Message {
  id: string
  content: string
  sender: "user" | "ai"
  timestamp: Date
  mood?: string
  suggestions?: string[]
}

export default function ChatPage() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      content: "Olá! Sou sua assistente de bem-estar da MindWave.AI. Como você está se sentindo hoje? 😊",
      sender: "ai",
      timestamp: new Date(),
      suggestions: ["Estou bem", "Um pouco ansioso", "Preciso de ajuda", "Quero meditar"],
    },
  ])
  const [inputMessage, setInputMessage] = useState("")
  const [isRecording, setIsRecording] = useState(false)
  const [isTyping, setIsTyping] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleSendMessage = async () => {
    if (!inputMessage.trim()) return

    const userMessage: Message = {
      id: Date.now().toString(),
      content: inputMessage,
      sender: "user",
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInputMessage("")
    setIsTyping(true)

    // Simular resposta da IA
    setTimeout(() => {
      const aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        content: generateAIResponse(inputMessage),
        sender: "ai",
        timestamp: new Date(),
        suggestions: generateSuggestions(inputMessage),
      }
      setMessages((prev) => [...prev, aiResponse])
      setIsTyping(false)
    }, 1500)
  }

  const generateAIResponse = (userInput: string): string => {
    const responses = [
      "Entendo como você está se sentindo. Que tal começarmos com uma respiração profunda? Inspire por 4 segundos, segure por 7 e expire por 8.",
      "Obrigada por compartilhar isso comigo. Vamos trabalhar juntas para encontrar estratégias que funcionem para você.",
      "Percebo que você está passando por um momento difícil. Lembre-se: você não está sozinho nessa jornada.",
      "Que bom saber como você está! Vamos continuar construindo hábitos saudáveis para seu bem-estar.",
      "Sua honestidade é muito importante. Que tal explorarmos algumas técnicas de mindfulness que podem ajudar?",
    ]
    return responses[Math.floor(Math.random() * responses.length)]
  }

  const generateSuggestions = (userInput: string): string[] => {
    const suggestions = [
      ["Exercício de respiração", "Meditação guiada", "Música relaxante"],
      ["Diário emocional", "Conversar mais", "Técnicas de grounding"],
      ["Fitoterapia", "Exercícios leves", "Sons da natureza"],
      ["Detox digital", "Caminhada", "Gratidão diária"],
    ]
    return suggestions[Math.floor(Math.random() * suggestions.length)]
  }

  const handleSuggestionClick = (suggestion: string) => {
    setInputMessage(suggestion)
  }

  const toggleRecording = () => {
    setIsRecording(!isRecording)
    // Implementar gravação de áudio aqui
  }

  return (
    <SidebarProvider>
      <div className="layout">
        <UserSidebar />
        <SidebarInset className="conteudo">
          <ModernDashboardHeader
            title="Chat IA"
            subtitle="Converse com sua assistente de bem-estar"
            breadcrumbs={[
              { label: "Dashboard", href: "/dashboard" },
              { label: "Chat IA", href: "/chat" },
            ]}
          />

          <div className="flex-1 flex flex-col h-[calc(100vh-80px)] max-w-full">
            {/* Chat Header */}
            <div className="bg-gray-800/50 border-b border-gray-700/50 p-4">
              <div className="flex items-center space-x-3">
                <Avatar className="h-10 w-10">
                  <AvatarImage src="/ai-avatar.png" alt="MindWave AI" />
                  <AvatarFallback className="bg-gradient-to-r from-purple-500 to-blue-500 text-white">
                    <Brain className="h-5 w-5" />
                  </AvatarFallback>
                </Avatar>
                <div>
                  <h3 className="text-white font-semibold">MindWave AI</h3>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                    <span className="text-sm text-gray-400">Online • Sempre disponível</span>
                  </div>
                </div>
                <div className="ml-auto">
                  <Badge className="bg-purple-500/20 text-purple-300 border-purple-500/30">
                    <Sparkles className="mr-1 h-3 w-3" />
                    IA Empática
                  </Badge>
                </div>
              </div>
            </div>

            {/* Messages Area */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-900/20">
              {messages.map((message) => (
                <motion.div
                  key={message.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3 }}
                  className={`flex ${message.sender === "user" ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`flex items-start space-x-3 max-w-[80%] ${message.sender === "user" ? "flex-row-reverse space-x-reverse" : ""}`}
                  >
                    <Avatar className="h-8 w-8 flex-shrink-0">
                      {message.sender === "user" ? (
                        <AvatarFallback className="bg-blue-600 text-white">
                          <User className="h-4 w-4" />
                        </AvatarFallback>
                      ) : (
                        <AvatarFallback className="bg-gradient-to-r from-purple-500 to-blue-500 text-white">
                          <Bot className="h-4 w-4" />
                        </AvatarFallback>
                      )}
                    </Avatar>

                    <div className={`flex flex-col ${message.sender === "user" ? "items-end" : "items-start"}`}>
                      <Card
                        className={`${
                          message.sender === "user"
                            ? "bg-blue-600 border-blue-500"
                            : "bg-gray-800/50 border-gray-700/50"
                        }`}
                      >
                        <CardContent className="p-3">
                          <p className={`text-sm ${message.sender === "user" ? "text-white" : "text-gray-200"}`}>
                            {message.content}
                          </p>
                        </CardContent>
                      </Card>

                      <span className="text-xs text-gray-500 mt-1">
                        {message.timestamp.toLocaleTimeString("pt-BR", {
                          hour: "2-digit",
                          minute: "2-digit",
                        })}
                      </span>

                      {/* Suggestions */}
                      {message.suggestions && message.sender === "ai" && (
                        <div className="flex flex-wrap gap-2 mt-2">
                          {message.suggestions.map((suggestion, index) => (
                            <Button
                              key={index}
                              variant="outline"
                              size="sm"
                              onClick={() => handleSuggestionClick(suggestion)}
                              className="text-xs bg-gray-700/50 border-gray-600 text-gray-300 hover:bg-gray-600/50"
                            >
                              {suggestion}
                            </Button>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </motion.div>
              ))}

              {/* Typing Indicator */}
              {isTyping && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex justify-start"
                >
                  <div className="flex items-start space-x-3">
                    <Avatar className="h-8 w-8">
                      <AvatarFallback className="bg-gradient-to-r from-purple-500 to-blue-500 text-white">
                        <Bot className="h-4 w-4" />
                      </AvatarFallback>
                    </Avatar>
                    <Card className="bg-gray-800/50 border-gray-700/50">
                      <CardContent className="p-3">
                        <div className="flex space-x-1">
                          <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                          <div
                            className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                            style={{ animationDelay: "0.1s" }}
                          ></div>
                          <div
                            className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                            style={{ animationDelay: "0.2s" }}
                          ></div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </motion.div>
              )}

              <div ref={messagesEndRef} />
            </div>

            {/* Input Area */}
            <div className="border-t border-gray-700/50 p-4 bg-gray-800/30">
              <div className="flex items-center space-x-3">
                <div className="flex-1 relative">
                  <Input
                    value={inputMessage}
                    onChange={(e) => setInputMessage(e.target.value)}
                    placeholder="Digite sua mensagem..."
                    className="pr-12 bg-gray-700/50 border-gray-600 text-white placeholder-gray-400 focus:border-purple-500"
                    onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
                    disabled={isTyping}
                  />
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={toggleRecording}
                    className={`absolute right-2 top-1/2 transform -translate-y-1/2 h-8 w-8 p-0 ${
                      isRecording ? "text-red-400 hover:text-red-300" : "text-gray-400 hover:text-gray-300"
                    }`}
                    aria-label={isRecording ? "Parar gravação" : "Iniciar gravação"}
                  >
                    {isRecording ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
                  </Button>
                </div>

                <Button
                  onClick={handleSendMessage}
                  disabled={!inputMessage.trim() || isTyping}
                  className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white"
                  aria-label="Enviar mensagem"
                >
                  <Send className="h-4 w-4" />
                </Button>
              </div>

              {/* Quick Actions */}
              <div className="flex flex-wrap gap-2 mt-3">
                {[
                  { icon: Heart, label: "Como me sinto", action: "Como estou me sentindo hoje" },
                  { icon: Brain, label: "Exercício mental", action: "Preciso de um exercício mental" },
                  { icon: Sparkles, label: "Motivação", action: "Preciso de motivação" },
                  { icon: MessageCircle, label: "Conversar", action: "Quero apenas conversar" },
                ].map((item, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    size="sm"
                    onClick={() => handleSuggestionClick(item.action)}
                    className="bg-gray-700/30 border-gray-600 text-gray-300 hover:bg-gray-600/50 text-xs"
                  >
                    <item.icon className="mr-1 h-3 w-3" />
                    {item.label}
                  </Button>
                ))}
              </div>
            </div>
          </div>
        </SidebarInset>
      </div>
    </SidebarProvider>
  )
}
