"use client"
import { motion } from "framer-motion"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ModernDashboardHeader } from "@/components/dashboard/modern-dashboard-header"
import { BackupManager } from "@/components/backup/backup-manager"
import { NotificationSettings } from "@/components/settings/notification-settings"
import { PrivacySettings } from "@/components/settings/privacy-settings"
import { AccountSettings } from "@/components/settings/account-settings"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { SettingsIcon, Bell, Shield, User, Database } from "lucide-react"

export default function SettingsPage() {
  return (
    <div className="min-h-screen bg-[#0B1426]">
      <ModernDashboardHeader />

      <main className="container mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="max-w-4xl mx-auto space-y-8"
        >
          {/* Header */}
          <div className="text-center space-y-4">
            <h1 className="text-3xl font-bold text-white">Configurações</h1>
            <p className="text-gray-400">Personalize sua experiência no MindWave.AI</p>
          </div>

          {/* Settings Tabs */}
          <Tabs defaultValue="account" className="space-y-6">
            <TabsList className="grid w-full grid-cols-5 bg-[#1A2332] border border-gray-700">
              <TabsTrigger value="account" className="data-[state=active]:bg-blue-600">
                <User className="h-4 w-4 mr-2" />
                Conta
              </TabsTrigger>
              <TabsTrigger value="notifications" className="data-[state=active]:bg-blue-600">
                <Bell className="h-4 w-4 mr-2" />
                Notificações
              </TabsTrigger>
              <TabsTrigger value="privacy" className="data-[state=active]:bg-blue-600">
                <Shield className="h-4 w-4 mr-2" />
                Privacidade
              </TabsTrigger>
              <TabsTrigger value="backup" className="data-[state=active]:bg-blue-600">
                <Database className="h-4 w-4 mr-2" />
                Backup
              </TabsTrigger>
              <TabsTrigger value="advanced" className="data-[state=active]:bg-blue-600">
                <SettingsIcon className="h-4 w-4 mr-2" />
                Avançado
              </TabsTrigger>
            </TabsList>

            <TabsContent value="account">
              <AccountSettings />
            </TabsContent>

            <TabsContent value="notifications">
              <NotificationSettings />
            </TabsContent>

            <TabsContent value="privacy">
              <PrivacySettings />
            </TabsContent>

            <TabsContent value="backup">
              <BackupManager />
            </TabsContent>

            <TabsContent value="advanced">
              <Card className="bg-[#1A2332] border-gray-800">
                <CardHeader>
                  <CardTitle className="text-white">Configurações Avançadas</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-400">Configurações avançadas em desenvolvimento...</p>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </motion.div>
      </main>
    </div>
  )
}
