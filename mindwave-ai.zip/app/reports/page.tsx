"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import {
  BarChart3,
  TrendingUp,
  Download,
  Calendar,
  Filter,
  Eye,
  FileText,
  PieChartIcon as RechartsPieChart,
  Activity,
} from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { SidebarProvider, SidebarInset } from "@/components/ui/sidebar"
import { UserSidebar } from "@/components/dashboard/user-sidebar"
import { ModernDashboardHeader } from "@/components/dashboard/modern-dashboard-header"
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  Pie,
  Cell,
  AreaChart,
  Area,
} from "recharts"

interface ReportData {
  period: string
  mood: number
  anxiety: number
  stress: number
  activities: number
  sessions: number
}

export default function ReportsPage() {
  const [selectedPeriod, setSelectedPeriod] = useState("month")
  const [selectedMetric, setSelectedMetric] = useState("all")

  // Dados simulados
  const reportData: ReportData[] = [
    { period: "Sem 1", mood: 7.2, anxiety: 4.1, stress: 5.2, activities: 12, sessions: 8 },
    { period: "Sem 2", mood: 6.8, anxiety: 5.3, stress: 6.1, activities: 10, sessions: 6 },
    { period: "Sem 3", mood: 8.1, anxiety: 3.2, stress: 4.0, activities: 15, sessions: 11 },
    { period: "Sem 4", mood: 7.9, anxiety: 3.8, stress: 4.5, activities: 14, sessions: 9 },
  ]

  const activityData = [
    { name: "Meditação", value: 35, color: "#8B5CF6" },
    { name: "Exercícios", value: 25, color: "#10B981" },
    { name: "Respiração", value: 20, color: "#3B82F6" },
    { name: "Journaling", value: 12, color: "#F59E0B" },
    { name: "Música", value: 8, color: "#EF4444" },
  ]

  const progressData = [
    { month: "Jan", progress: 65 },
    { month: "Fev", progress: 72 },
    { month: "Mar", progress: 68 },
    { month: "Abr", progress: 78 },
    { month: "Mai", progress: 85 },
    { month: "Jun", progress: 82 },
  ]

  const insights = [
    {
      title: "Melhora Significativa",
      description: "Seu humor melhorou 23% nas últimas 4 semanas",
      trend: "positive",
      icon: TrendingUp,
      color: "text-green-400",
    },
    {
      title: "Consistência em Atividades",
      description: "Você manteve uma média de 13 atividades por semana",
      trend: "stable",
      icon: Activity,
      color: "text-blue-400",
    },
    {
      title: "Redução do Estresse",
      description: "Níveis de estresse diminuíram 18% no último mês",
      trend: "positive",
      icon: BarChart3,
      color: "text-purple-400",
    },
  ]

  const handleExportReport = () => {
    // Implementar exportação de relatório
    console.log("Exportando relatório...")
  }

  return (
    <SidebarProvider>
      <div className="layout">
        <UserSidebar />
        <SidebarInset className="conteudo">
          <ModernDashboardHeader
            title="Relatórios e Analytics"
            subtitle="Análise detalhada do seu progresso e bem-estar"
            breadcrumbs={[
              { label: "Dashboard", href: "/dashboard" },
              { label: "Relatórios", href: "/reports" },
            ]}
          />

          <div className="p-6 space-y-6 max-w-full">
            {/* Filters and Controls */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between"
            >
              <div className="flex flex-col sm:flex-row gap-3">
                <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
                  <SelectTrigger className="w-[180px] bg-gray-800/50 border-gray-700">
                    <Calendar className="mr-2 h-4 w-4" />
                    <SelectValue placeholder="Período" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="week">Última Semana</SelectItem>
                    <SelectItem value="month">Último Mês</SelectItem>
                    <SelectItem value="quarter">Último Trimestre</SelectItem>
                    <SelectItem value="year">Último Ano</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={selectedMetric} onValueChange={setSelectedMetric}>
                  <SelectTrigger className="w-[180px] bg-gray-800/50 border-gray-700">
                    <Filter className="mr-2 h-4 w-4" />
                    <SelectValue placeholder="Métrica" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todas as Métricas</SelectItem>
                    <SelectItem value="mood">Humor</SelectItem>
                    <SelectItem value="anxiety">Ansiedade</SelectItem>
                    <SelectItem value="stress">Estresse</SelectItem>
                    <SelectItem value="activities">Atividades</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex gap-2">
                <Button variant="outline" className="border-gray-600 bg-transparent">
                  <Eye className="mr-2 h-4 w-4" />
                  Visualizar
                </Button>
                <Button onClick={handleExportReport} className="bg-purple-600 hover:bg-purple-700">
                  <Download className="mr-2 h-4 w-4" />
                  Exportar PDF
                </Button>
              </div>
            </motion.div>

            {/* Key Insights */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {insights.map((insight, index) => (
                  <Card key={index} className="bg-gray-800/50 border-gray-700/50">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center mb-2">
                            <insight.icon className={`h-5 w-5 ${insight.color} mr-2`} />
                            <h4 className="text-white font-medium">{insight.title}</h4>
                          </div>
                          <p className="text-gray-400 text-sm">{insight.description}</p>
                        </div>
                        <Badge
                          className={`${
                            insight.trend === "positive"
                              ? "bg-green-500/20 text-green-400"
                              : insight.trend === "negative"
                                ? "bg-red-500/20 text-red-400"
                                : "bg-blue-500/20 text-blue-400"
                          }`}
                        >
                          {insight.trend === "positive" ? "↗️" : insight.trend === "negative" ? "↘️" : "→"}
                        </Badge>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </motion.div>

            {/* Main Charts */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Mood Trends */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.2 }}
              >
                <Card className="bg-gray-800/50 border-gray-700/50">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center">
                      <TrendingUp className="mr-2 h-5 w-5 text-blue-400" />
                      Tendências de Humor
                    </CardTitle>
                    <CardDescription>Evolução do seu bem-estar ao longo do tempo</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <AreaChart data={reportData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                        <XAxis dataKey="period" stroke="#9CA3AF" />
                        <YAxis stroke="#9CA3AF" domain={[0, 10]} />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: "#1F2937",
                            border: "1px solid #374151",
                            borderRadius: "8px",
                            color: "#F3F4F6",
                          }}
                        />
                        <Area
                          type="monotone"
                          dataKey="mood"
                          stroke="#8B5CF6"
                          fill="#8B5CF6"
                          fillOpacity={0.3}
                          strokeWidth={2}
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </motion.div>

              {/* Activity Distribution */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.3 }}
              >
                <Card className="bg-gray-800/50 border-gray-700/50">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center">
                      <RechartsPieChart className="mr-2 h-5 w-5 text-purple-400" />
                      Distribuição de Atividades
                    </CardTitle>
                    <CardDescription>Como você tem investido seu tempo em bem-estar</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <RechartsPieChart>
                        <Pie
                          data={activityData}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={100}
                          paddingAngle={5}
                          dataKey="value"
                        >
                          {activityData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip
                          contentStyle={{
                            backgroundColor: "#1F2937",
                            border: "1px solid #374151",
                            borderRadius: "8px",
                            color: "#F3F4F6",
                          }}
                        />
                      </RechartsPieChart>
                    </ResponsiveContainer>
                    <div className="grid grid-cols-2 gap-2 mt-4">
                      {activityData.map((item) => (
                        <div key={item.name} className="flex items-center">
                          <div className="w-3 h-3 rounded-full mr-2" style={{ backgroundColor: item.color }} />
                          <span className="text-sm text-gray-300">{item.name}</span>
                          <span className="text-sm text-gray-400 ml-auto">{item.value}%</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </div>

            {/* Detailed Metrics */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
            >
              <Card className="bg-gray-800/50 border-gray-700/50">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <BarChart3 className="mr-2 h-5 w-5 text-green-400" />
                    Métricas Detalhadas
                  </CardTitle>
                  <CardDescription>Comparação de todas as métricas de bem-estar</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={400}>
                    <BarChart data={reportData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                      <XAxis dataKey="period" stroke="#9CA3AF" />
                      <YAxis stroke="#9CA3AF" />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "#1F2937",
                          border: "1px solid #374151",
                          borderRadius: "8px",
                          color: "#F3F4F6",
                        }}
                      />
                      <Bar dataKey="mood" fill="#8B5CF6" name="Humor" />
                      <Bar dataKey="anxiety" fill="#EF4444" name="Ansiedade" />
                      <Bar dataKey="stress" fill="#F59E0B" name="Estresse" />
                      <Bar dataKey="activities" fill="#10B981" name="Atividades" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </motion.div>

            {/* Progress Overview */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.5 }}
            >
              <Card className="bg-gray-800/50 border-gray-700/50">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <Activity className="mr-2 h-5 w-5 text-orange-400" />
                    Progresso Geral
                  </CardTitle>
                  <CardDescription>Sua jornada de bem-estar ao longo dos meses</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={progressData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                      <XAxis dataKey="month" stroke="#9CA3AF" />
                      <YAxis stroke="#9CA3AF" domain={[0, 100]} />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "#1F2937",
                          border: "1px solid #374151",
                          borderRadius: "8px",
                          color: "#F3F4F6",
                        }}
                      />
                      <Line
                        type="monotone"
                        dataKey="progress"
                        stroke="#10B981"
                        strokeWidth={3}
                        dot={{ fill: "#10B981", strokeWidth: 2, r: 6 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </motion.div>

            {/* Summary Report */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.6 }}
            >
              <Card className="bg-gray-800/50 border-gray-700/50">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <FileText className="mr-2 h-5 w-5 text-blue-400" />
                    Resumo do Período
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    <div className="text-center">
                      <div className="text-3xl font-bold text-green-400 mb-2">85%</div>
                      <p className="text-gray-300 font-medium">Progresso Geral</p>
                      <p className="text-gray-500 text-sm">+12% vs mês anterior</p>
                    </div>

                    <div className="text-center">
                      <div className="text-3xl font-bold text-blue-400 mb-2">42</div>
                      <p className="text-gray-300 font-medium">Sessões Completas</p>
                      <p className="text-gray-500 text-sm">Média de 1.4/dia</p>
                    </div>

                    <div className="text-center">
                      <div className="text-3xl font-bold text-purple-400 mb-2">7.8</div>
                      <p className="text-gray-300 font-medium">Humor Médio</p>
                      <p className="text-gray-500 text-sm">Escala de 1-10</p>
                    </div>

                    <div className="text-center">
                      <div className="text-3xl font-bold text-orange-400 mb-2">23</div>
                      <p className="text-gray-300 font-medium">Dias Consecutivos</p>
                      <p className="text-gray-500 text-sm">Maior sequência</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </SidebarInset>
      </div>
    </SidebarProvider>
  )
}
