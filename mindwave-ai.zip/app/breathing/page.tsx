"use client"

import { useState, useEffect, useRef } from "react"
import { motion } from "framer-motion"
import { Play, Pause, RotateCcw, Settings, Heart, Wind, Waves, Mountain } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Slider } from "@/components/ui/slider"
import { SidebarProvider, SidebarInset } from "@/components/ui/sidebar"
import { UserSidebar } from "@/components/dashboard/user-sidebar"
import { ModernDashboardHeader } from "@/components/dashboard/modern-dashboard-header"

interface BreathingTechnique {
  id: string
  name: string
  description: string
  pattern: number[]
  duration: number
  icon: any
  color: string
  benefits: string[]
}

export default function BreathingPage() {
  const [isActive, setIsActive] = useState(false)
  const [currentPhase, setCurrentPhase] = useState(0) // 0: inhale, 1: hold, 2: exhale, 3: hold
  const [timeLeft, setTimeLeft] = useState(0)
  const [currentCycle, setCurrentCycle] = useState(0)
  const [selectedTechnique, setSelectedTechnique] = useState<BreathingTechnique | null>(null)
  const [totalCycles, setTotalCycles] = useState(5)
  const intervalRef = useRef<NodeJS.Timeout | null>(null)

  const techniques: BreathingTechnique[] = [
    {
      id: "4-7-8",
      name: "Respiração 4-7-8",
      description: "Técnica calmante para reduzir ansiedade e promover relaxamento",
      pattern: [4, 7, 8, 0], // inhale, hold, exhale, hold
      duration: 19,
      icon: Heart,
      color: "from-pink-500 to-rose-500",
      benefits: ["Reduz ansiedade", "Melhora o sono", "Diminui estresse"],
    },
    {
      id: "box",
      name: "Respiração Quadrada",
      description: "Respiração equilibrada para foco e concentração",
      pattern: [4, 4, 4, 4],
      duration: 16,
      icon: Wind,
      color: "from-blue-500 to-cyan-500",
      benefits: ["Aumenta foco", "Equilibra sistema nervoso", "Melhora concentração"],
    },
    {
      id: "coherent",
      name: "Respiração Coerente",
      description: "Respiração rítmica para harmonia cardíaca",
      pattern: [5, 0, 5, 0],
      duration: 10,
      icon: Waves,
      color: "from-green-500 to-emerald-500",
      benefits: ["Harmonia cardíaca", "Reduz pressão arterial", "Melhora variabilidade cardíaca"],
    },
    {
      id: "energizing",
      name: "Respiração Energizante",
      description: "Técnica revigorante para aumentar energia",
      pattern: [2, 0, 4, 0],
      duration: 6,
      icon: Mountain,
      color: "from-orange-500 to-red-500",
      benefits: ["Aumenta energia", "Melhora alerta mental", "Revigora o corpo"],
    },
  ]

  const phaseNames = ["Inspire", "Segure", "Expire", "Segure"]
  const phaseInstructions = [
    "Inspire lentamente pelo nariz",
    "Segure a respiração",
    "Expire lentamente pela boca",
    "Segure com os pulmões vazios",
  ]

  useEffect(() => {
    if (isActive && selectedTechnique) {
      intervalRef.current = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            // Move to next phase
            setCurrentPhase((phase) => {
              const nextPhase = (phase + 1) % 4
              if (nextPhase === 0) {
                setCurrentCycle((cycle) => cycle + 1)
              }
              return nextPhase
            })
            return selectedTechnique.pattern[currentPhase === 3 ? 0 : currentPhase + 1]
          }
          return prev - 1
        })
      }, 1000)
    } else {
      if (intervalRef.current) {
        clearInterval(intervalRef.current)
      }
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current)
      }
    }
  }, [isActive, selectedTechnique, currentPhase])

  useEffect(() => {
    if (currentCycle >= totalCycles && isActive) {
      handleStop()
    }
  }, [currentCycle, totalCycles, isActive])

  const handleStart = (technique: BreathingTechnique) => {
    setSelectedTechnique(technique)
    setCurrentPhase(0)
    setTimeLeft(technique.pattern[0])
    setCurrentCycle(0)
    setIsActive(true)
  }

  const handlePause = () => {
    setIsActive(!isActive)
  }

  const handleStop = () => {
    setIsActive(false)
    setCurrentPhase(0)
    setCurrentCycle(0)
    setTimeLeft(0)
    setSelectedTechnique(null)
  }

  const getCircleScale = () => {
    if (!selectedTechnique) return 1

    const maxTime = Math.max(...selectedTechnique.pattern)
    const progress =
      selectedTechnique.pattern[currentPhase] > 0
        ? (selectedTechnique.pattern[currentPhase] - timeLeft) / selectedTechnique.pattern[currentPhase]
        : 0

    if (currentPhase === 0) {
      // Inhale
      return 1 + progress * 0.5
    } else if (currentPhase === 2) {
      // Exhale
      return 1.5 - progress * 0.5
    }
    return currentPhase === 1 ? 1.5 : 1 // Hold states
  }

  return (
    <SidebarProvider>
      <div className="layout">
        <UserSidebar />
        <SidebarInset className="conteudo">
          <ModernDashboardHeader
            title="Exercícios de Respiração"
            subtitle="Técnicas guiadas para relaxamento e bem-estar"
            breadcrumbs={[
              { label: "Dashboard", href: "/dashboard" },
              { label: "Respiração", href: "/breathing" },
            ]}
          />

          <div className="p-6 space-y-6 max-w-full">
            {!selectedTechnique ? (
              // Technique Selection
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="grid grid-cols-1 md:grid-cols-2 gap-6"
              >
                {techniques.map((technique, index) => (
                  <motion.div
                    key={technique.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                  >
                    <Card className="bg-gray-800/50 border-gray-700/50 hover:border-purple-500/50 transition-all cursor-pointer group">
                      <CardHeader>
                        <div className="flex items-center justify-between">
                          <div
                            className={`w-12 h-12 rounded-lg bg-gradient-to-r ${technique.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}
                          >
                            <technique.icon className="h-6 w-6 text-white" />
                          </div>
                          <Badge className="bg-purple-500/20 text-purple-300">{technique.duration}s por ciclo</Badge>
                        </div>
                        <CardTitle className="text-white">{technique.name}</CardTitle>
                        <CardDescription className="text-gray-400">{technique.description}</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          <div>
                            <p className="text-sm text-gray-400 mb-2">Padrão:</p>
                            <div className="flex items-center space-x-2 text-sm text-gray-300">
                              <span>Inspire {technique.pattern[0]}s</span>
                              {technique.pattern[1] > 0 && <span>• Segure {technique.pattern[1]}s</span>}
                              <span>• Expire {technique.pattern[2]}s</span>
                              {technique.pattern[3] > 0 && <span>• Segure {technique.pattern[3]}s</span>}
                            </div>
                          </div>

                          <div>
                            <p className="text-sm text-gray-400 mb-2">Benefícios:</p>
                            <div className="flex flex-wrap gap-1">
                              {technique.benefits.map((benefit) => (
                                <Badge key={benefit} variant="outline" className="text-xs">
                                  {benefit}
                                </Badge>
                              ))}
                            </div>
                          </div>

                          <Button
                            onClick={() => handleStart(technique)}
                            className={`w-full bg-gradient-to-r ${technique.color} hover:opacity-90 text-white`}
                          >
                            <Play className="mr-2 h-4 w-4" />
                            Começar Exercício
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </motion.div>
            ) : (
              // Active Session
              <div className="space-y-6">
                {/* Session Header */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5 }}
                >
                  <Card className="bg-gray-800/50 border-gray-700/50">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4">
                          <div
                            className={`w-12 h-12 rounded-lg bg-gradient-to-r ${selectedTechnique.color} flex items-center justify-center`}
                          >
                            <selectedTechnique.icon className="h-6 w-6 text-white" />
                          </div>
                          <div>
                            <h3 className="text-xl font-semibold text-white">{selectedTechnique.name}</h3>
                            <p className="text-gray-400">
                              Ciclo {currentCycle + 1} de {totalCycles}
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center space-x-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={handlePause}
                            className="border-gray-600 bg-transparent"
                          >
                            {isActive ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={handleStop}
                            className="border-gray-600 bg-transparent"
                          >
                            <RotateCcw className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>

                {/* Breathing Circle */}
                <motion.div
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.5, delay: 0.2 }}
                  className="flex justify-center"
                >
                  <Card className="bg-gray-800/30 border-gray-700/50 p-8">
                    <CardContent className="flex flex-col items-center space-y-8">
                      {/* Breathing Circle */}
                      <div className="relative">
                        <motion.div
                          animate={{
                            scale: getCircleScale(),
                            opacity: isActive ? [0.6, 1, 0.6] : 0.8,
                          }}
                          transition={{
                            duration: isActive ? 2 : 0.5,
                            repeat: isActive ? Number.POSITIVE_INFINITY : 0,
                            ease: "easeInOut",
                          }}
                          className={`w-64 h-64 rounded-full bg-gradient-to-r ${selectedTechnique.color} opacity-30 flex items-center justify-center`}
                        >
                          <div className="w-48 h-48 rounded-full bg-gray-900/50 flex items-center justify-center">
                            <div className="text-center">
                              <div className="text-6xl font-bold text-white mb-2">{timeLeft}</div>
                              <div className="text-lg text-gray-300">
                                {selectedTechnique.pattern[currentPhase] > 0 ? phaseNames[currentPhase] : ""}
                              </div>
                            </div>
                          </div>
                        </motion.div>
                      </div>

                      {/* Instructions */}
                      <div className="text-center">
                        <h3 className="text-2xl font-semibold text-white mb-2">
                          {selectedTechnique.pattern[currentPhase] > 0 ? phaseNames[currentPhase] : "Preparando..."}
                        </h3>
                        <p className="text-gray-400">
                          {selectedTechnique.pattern[currentPhase] > 0
                            ? phaseInstructions[currentPhase]
                            : "Prepare-se para começar"}
                        </p>
                      </div>

                      {/* Progress */}
                      <div className="w-full max-w-md">
                        <div className="flex justify-between text-sm text-gray-400 mb-2">
                          <span>Progresso do Ciclo</span>
                          <span>{Math.round((currentCycle / totalCycles) * 100)}%</span>
                        </div>
                        <div className="w-full bg-gray-700 rounded-full h-2">
                          <motion.div
                            className={`h-2 rounded-full bg-gradient-to-r ${selectedTechnique.color}`}
                            initial={{ width: 0 }}
                            animate={{ width: `${(currentCycle / totalCycles) * 100}%` }}
                            transition={{ duration: 0.5 }}
                          />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>

                {/* Settings */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.4 }}
                >
                  <Card className="bg-gray-800/50 border-gray-700/50">
                    <CardHeader>
                      <CardTitle className="text-white flex items-center">
                        <Settings className="mr-2 h-5 w-5" />
                        Configurações da Sessão
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div>
                          <label className="text-sm text-gray-400 mb-2 block">Número de Ciclos: {totalCycles}</label>
                          <Slider
                            value={[totalCycles]}
                            onValueChange={(value) => setTotalCycles(value[0])}
                            max={20}
                            min={3}
                            step={1}
                            className="w-full"
                            disabled={isActive}
                          />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              </div>
            )}
          </div>
        </SidebarInset>
      </div>
    </SidebarProvider>
  )
}
