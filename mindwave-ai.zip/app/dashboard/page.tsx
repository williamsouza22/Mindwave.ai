"use client"

import { Suspense } from "react"
import { SidebarProvider, SidebarInset, SidebarTrigger } from "@/components/ui/sidebar"
import { UserSidebar } from "@/components/dashboard/user-sidebar"
import { ModernDashboardHeader } from "@/components/dashboard/modern-dashboard-header"
import { CrisisDetection } from "@/components/dashboard/crisis-detection"
import { EmotionalMap } from "@/components/dashboard/emotional-map"
import { CozyMindfulness } from "@/components/dashboard/cozy-mindfulness"
import { DigitalDetox } from "@/components/dashboard/digital-detox"
import { AIChat } from "@/components/dashboard/ai-chat"
import { Fitotherapy } from "@/components/dashboard/fitotherapy"
import { WelcomeCard } from "@/components/dashboard/welcome-card"
import { QuickActions } from "@/components/dashboard/quick-actions"
import { Skeleton } from "@/components/ui/skeleton"
import { Separator } from "@/components/ui/separator"
import { useAuth } from "@/lib/auth/auth-context"
import { DashboardLoading } from "@/components/dashboard/dashboard-loading"
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb"

export default function ModernDashboardPage() {
  const { loading, user, profile } = useAuth()

  if (loading) {
    return <DashboardLoading />
  }

  return (
    <SidebarProvider>
      <UserSidebar />
      <SidebarInset>
        <header className="flex h-16 shrink-0 items-center gap-2 border-b border-gray-800 bg-[#1A2332] px-4">
          <SidebarTrigger className="-ml-1 text-gray-300 hover:text-white" />
          <Separator orientation="vertical" className="mr-2 h-4 bg-gray-700" />
          <Breadcrumb>
            <BreadcrumbList>
              <BreadcrumbItem className="hidden md:block">
                <BreadcrumbLink href="/dashboard" className="text-gray-400 hover:text-white">
                  Dashboard
                </BreadcrumbLink>
              </BreadcrumbItem>
              <BreadcrumbSeparator className="hidden md:block text-gray-600" />
              <BreadcrumbItem>
                <BreadcrumbPage className="text-white">Visão Geral</BreadcrumbPage>
              </BreadcrumbItem>
            </BreadcrumbList>
          </Breadcrumb>
          <div className="ml-auto">
            <ModernDashboardHeader />
          </div>
        </header>

        <main className="flex-1 bg-[#0B1426] p-4">
          {/* Welcome Section */}
          <div className="mb-8">
            <WelcomeCard />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
            {/* Main Content */}
            <div className="lg:col-span-3 space-y-8">
              <Suspense fallback={<Skeleton className="h-[200px] w-full bg-gray-800" />}>
                <CrisisDetection />
              </Suspense>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <Suspense fallback={<Skeleton className="h-[400px] w-full bg-gray-800" />}>
                  <AIChat />
                </Suspense>

                <Suspense fallback={<Skeleton className="h-[400px] w-full bg-gray-800" />}>
                  <CozyMindfulness />
                </Suspense>
              </div>

              <Suspense fallback={<Skeleton className="h-[300px] w-full bg-gray-800" />}>
                <EmotionalMap />
              </Suspense>
            </div>

            {/* Sidebar */}
            <div className="space-y-8">
              <Suspense fallback={<Skeleton className="h-[200px] w-full bg-gray-800" />}>
                <QuickActions />
              </Suspense>

              <Suspense fallback={<Skeleton className="h-[250px] w-full bg-gray-800" />}>
                <DigitalDetox />
              </Suspense>

              <Suspense fallback={<Skeleton className="h-[300px] w-full bg-gray-800" />}>
                <Fitotherapy />
              </Suspense>
            </div>
          </div>
        </main>
      </SidebarInset>
    </SidebarProvider>
  )
}
