"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { Plus, Search, Calendar, Heart, Brain, Sparkles, Edit, Trash2, BookOpen, TrendingUp } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { SidebarProvider, SidebarInset } from "@/components/ui/sidebar"
import { UserSidebar } from "@/components/dashboard/user-sidebar"
import { ModernDashboardHeader } from "@/components/dashboard/modern-dashboard-header"

interface JournalEntry {
  id: string
  title: string
  content: string
  mood: number
  emotions: string[]
  date: Date
  aiInsights?: string
  gratitude?: string[]
  goals?: string[]
}

export default function JournalPage() {
  const [entries, setEntries] = useState<JournalEntry[]>([])
  const [isNewEntryOpen, setIsNewEntryOpen] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedMood, setSelectedMood] = useState<number | null>(null)
  const [newEntry, setNewEntry] = useState({
    title: "",
    content: "",
    mood: 5,
    emotions: [] as string[],
    gratitude: ["", "", ""],
    goals: [""],
  })

  // Dados simulados
  useEffect(() => {
    const mockEntries: JournalEntry[] = [
      {
        id: "1",
        title: "Um dia produtivo",
        content:
          "Hoje consegui completar todas as tarefas que havia planejado. Me senti muito bem com minha produtividade e organização.",
        mood: 8,
        emotions: ["Feliz", "Produtivo", "Satisfeito"],
        date: new Date(2024, 0, 20),
        aiInsights:
          "Você demonstra um padrão positivo quando consegue completar suas tarefas planejadas. Continue mantendo essa organização!",
        gratitude: ["Minha saúde", "Oportunidades de trabalho", "Apoio da família"],
        goals: ["Manter rotina de exercícios", "Ler 30 minutos por dia"],
      },
      {
        id: "2",
        title: "Reflexões sobre ansiedade",
        content:
          "Hoje senti um pouco de ansiedade antes da reunião importante. Pratiquei respiração profunda e consegui me acalmar.",
        mood: 6,
        emotions: ["Ansioso", "Determinado", "Aliviado"],
        date: new Date(2024, 0, 19),
        aiInsights:
          "Ótimo trabalho usando técnicas de respiração para gerenciar a ansiedade. Isso mostra seu crescimento emocional.",
        gratitude: ["Técnicas de respiração", "Apoio dos colegas", "Minha resiliência"],
        goals: ["Praticar meditação diária", "Preparar-me melhor para reuniões"],
      },
    ]
    setEntries(mockEntries)
  }, [])

  const emotionOptions = [
    "Feliz",
    "Triste",
    "Ansioso",
    "Calmo",
    "Irritado",
    "Grato",
    "Motivado",
    "Cansado",
    "Esperançoso",
    "Frustrado",
    "Orgulhoso",
    "Preocupado",
  ]

  const filteredEntries = entries.filter((entry) => {
    const matchesSearch =
      entry.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      entry.content.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesMood = selectedMood === null || entry.mood === selectedMood
    return matchesSearch && matchesMood
  })

  const handleSaveEntry = () => {
    if (!newEntry.title || !newEntry.content) return

    const entry: JournalEntry = {
      id: Date.now().toString(),
      title: newEntry.title,
      content: newEntry.content,
      mood: newEntry.mood,
      emotions: newEntry.emotions,
      date: new Date(),
      gratitude: newEntry.gratitude.filter((g) => g.trim() !== ""),
      goals: newEntry.goals.filter((g) => g.trim() !== ""),
      aiInsights: generateAIInsight(newEntry.content, newEntry.mood),
    }

    setEntries([entry, ...entries])
    setNewEntry({
      title: "",
      content: "",
      mood: 5,
      emotions: [],
      gratitude: ["", "", ""],
      goals: [""],
    })
    setIsNewEntryOpen(false)
  }

  const generateAIInsight = (content: string, mood: number): string => {
    const insights = [
      "Sua capacidade de reflexão é admirável. Continue explorando seus sentimentos.",
      "Percebo um padrão de crescimento em suas reflexões. Você está evoluindo!",
      "Suas palavras mostram autoconhecimento. Isso é fundamental para o bem-estar.",
      "Continue registrando seus pensamentos. Isso fortalece sua inteligência emocional.",
      "Vejo sinais de resiliência em sua escrita. Você tem força interior.",
    ]
    return insights[Math.floor(Math.random() * insights.length)]
  }

  const getMoodEmoji = (mood: number) => {
    if (mood >= 8) return "😊"
    if (mood >= 6) return "😐"
    if (mood >= 4) return "😔"
    return "😢"
  }

  const getMoodColor = (mood: number) => {
    if (mood >= 8) return "text-green-400"
    if (mood >= 6) return "text-yellow-400"
    if (mood >= 4) return "text-orange-400"
    return "text-red-400"
  }

  const addEmotion = (emotion: string) => {
    if (!newEntry.emotions.includes(emotion)) {
      setNewEntry({
        ...newEntry,
        emotions: [...newEntry.emotions, emotion],
      })
    }
  }

  const removeEmotion = (emotion: string) => {
    setNewEntry({
      ...newEntry,
      emotions: newEntry.emotions.filter((e) => e !== emotion),
    })
  }

  return (
    <SidebarProvider>
      <div className="layout">
        <UserSidebar />
        <SidebarInset className="conteudo">
          <ModernDashboardHeader
            title="Diário Emocional"
            subtitle="Registre seus pensamentos e acompanhe sua jornada"
            breadcrumbs={[
              { label: "Dashboard", href: "/dashboard" },
              { label: "Diário", href: "/journal" },
            ]}
          />

          <div className="p-6 space-y-6 max-w-full">
            {/* Header Actions */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between"
            >
              <div className="flex flex-col sm:flex-row gap-3 flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Buscar entradas..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 bg-gray-800/50 border-gray-700 text-white"
                  />
                </div>

                <Select
                  value={selectedMood?.toString() || "all"}
                  onValueChange={(value) => setSelectedMood(value === "all" ? null : Number.parseInt(value))}
                >
                  <SelectTrigger className="w-[180px] bg-gray-800/50 border-gray-700">
                    <SelectValue placeholder="Filtrar por humor" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos os humores</SelectItem>
                    <SelectItem value="8">😊 Muito bem (8-10)</SelectItem>
                    <SelectItem value="6">😐 Bem (6-7)</SelectItem>
                    <SelectItem value="4">😔 Baixo (4-5)</SelectItem>
                    <SelectItem value="2">😢 Muito baixo (1-3)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Dialog open={isNewEntryOpen} onOpenChange={setIsNewEntryOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-purple-600 hover:bg-purple-700">
                    <Plus className="mr-2 h-4 w-4" />
                    Nova Entrada
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto bg-gray-900 border-gray-700">
                  <DialogHeader>
                    <DialogTitle className="text-white">Nova Entrada do Diário</DialogTitle>
                    <DialogDescription className="text-gray-400">
                      Registre seus pensamentos e sentimentos do dia
                    </DialogDescription>
                  </DialogHeader>

                  <div className="space-y-6">
                    <div>
                      <label className="text-sm font-medium text-gray-300 mb-2 block">Título</label>
                      <Input
                        value={newEntry.title}
                        onChange={(e) => setNewEntry({ ...newEntry, title: e.target.value })}
                        placeholder="Como foi seu dia?"
                        className="bg-gray-800/50 border-gray-700 text-white"
                      />
                    </div>

                    <div>
                      <label className="text-sm font-medium text-gray-300 mb-2 block">
                        Como você se sente? ({newEntry.mood}/10)
                      </label>
                      <div className="flex items-center space-x-4">
                        <span className="text-2xl">{getMoodEmoji(newEntry.mood)}</span>
                        <input
                          type="range"
                          min="1"
                          max="10"
                          value={newEntry.mood}
                          onChange={(e) => setNewEntry({ ...newEntry, mood: Number.parseInt(e.target.value) })}
                          className="flex-1 h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
                        />
                        <span className={`font-semibold ${getMoodColor(newEntry.mood)}`}>{newEntry.mood}</span>
                      </div>
                    </div>

                    <div>
                      <label className="text-sm font-medium text-gray-300 mb-2 block">Emoções</label>
                      <div className="flex flex-wrap gap-2 mb-3">
                        {emotionOptions.map((emotion) => (
                          <Button
                            key={emotion}
                            variant={newEntry.emotions.includes(emotion) ? "default" : "outline"}
                            size="sm"
                            onClick={() =>
                              newEntry.emotions.includes(emotion) ? removeEmotion(emotion) : addEmotion(emotion)
                            }
                            className={
                              newEntry.emotions.includes(emotion)
                                ? "bg-purple-600 hover:bg-purple-700"
                                : "border-gray-600"
                            }
                          >
                            {emotion}
                          </Button>
                        ))}
                      </div>
                    </div>

                    <div>
                      <label className="text-sm font-medium text-gray-300 mb-2 block">Conte sobre seu dia</label>
                      <Textarea
                        value={newEntry.content}
                        onChange={(e) => setNewEntry({ ...newEntry, content: e.target.value })}
                        placeholder="Descreva seus pensamentos, sentimentos e experiências..."
                        className="min-h-[120px] bg-gray-800/50 border-gray-700 text-white"
                      />
                    </div>

                    <div>
                      <label className="text-sm font-medium text-gray-300 mb-2 block">Gratidão (3 coisas)</label>
                      {newEntry.gratitude.map((item, index) => (
                        <Input
                          key={index}
                          value={item}
                          onChange={(e) => {
                            const newGratitude = [...newEntry.gratitude]
                            newGratitude[index] = e.target.value
                            setNewEntry({ ...newEntry, gratitude: newGratitude })
                          }}
                          placeholder={`Gratidão ${index + 1}...`}
                          className="mb-2 bg-gray-800/50 border-gray-700 text-white"
                        />
                      ))}
                    </div>

                    <div>
                      <label className="text-sm font-medium text-gray-300 mb-2 block">Metas para amanhã</label>
                      {newEntry.goals.map((goal, index) => (
                        <div key={index} className="flex gap-2 mb-2">
                          <Input
                            value={goal}
                            onChange={(e) => {
                              const newGoals = [...newEntry.goals]
                              newGoals[index] = e.target.value
                              setNewEntry({ ...newEntry, goals: newGoals })
                            }}
                            placeholder={`Meta ${index + 1}...`}
                            className="bg-gray-800/50 border-gray-700 text-white"
                          />
                          {index === newEntry.goals.length - 1 && (
                            <Button
                              type="button"
                              variant="outline"
                              onClick={() => setNewEntry({ ...newEntry, goals: [...newEntry.goals, ""] })}
                              className="border-gray-600"
                            >
                              <Plus className="h-4 w-4" />
                            </Button>
                          )}
                        </div>
                      ))}
                    </div>

                    <div className="flex justify-end space-x-3">
                      <Button variant="outline" onClick={() => setIsNewEntryOpen(false)} className="border-gray-600">
                        Cancelar
                      </Button>
                      <Button onClick={handleSaveEntry} className="bg-purple-600 hover:bg-purple-700">
                        Salvar Entrada
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </motion.div>

            {/* Stats Cards */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="grid grid-cols-1 md:grid-cols-4 gap-4"
            >
              <Card className="bg-gray-800/50 border-gray-700/50">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-gray-400 text-sm">Total de Entradas</p>
                      <p className="text-2xl font-bold text-white">{entries.length}</p>
                    </div>
                    <BookOpen className="h-8 w-8 text-purple-400" />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-800/50 border-gray-700/50">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-gray-400 text-sm">Humor Médio</p>
                      <p className="text-2xl font-bold text-white">
                        {entries.length > 0
                          ? (entries.reduce((acc, entry) => acc + entry.mood, 0) / entries.length).toFixed(1)
                          : "0"}
                      </p>
                    </div>
                    <Heart className="h-8 w-8 text-pink-400" />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-800/50 border-gray-700/50">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-gray-400 text-sm">Sequência</p>
                      <p className="text-2xl font-bold text-white">7 dias</p>
                    </div>
                    <TrendingUp className="h-8 w-8 text-green-400" />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-800/50 border-gray-700/50">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-gray-400 text-sm">Insights IA</p>
                      <p className="text-2xl font-bold text-white">{entries.filter((e) => e.aiInsights).length}</p>
                    </div>
                    <Sparkles className="h-8 w-8 text-blue-400" />
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Journal Entries */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="space-y-4"
            >
              {filteredEntries.length === 0 ? (
                <Card className="bg-gray-800/50 border-gray-700/50">
                  <CardContent className="p-8 text-center">
                    <BookOpen className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-white mb-2">Nenhuma entrada encontrada</h3>
                    <p className="text-gray-400 mb-4">
                      {searchTerm || selectedMood
                        ? "Tente ajustar os filtros"
                        : "Comece escrevendo sua primeira entrada"}
                    </p>
                    {!searchTerm && !selectedMood && (
                      <Button onClick={() => setIsNewEntryOpen(true)} className="bg-purple-600 hover:bg-purple-700">
                        <Plus className="mr-2 h-4 w-4" />
                        Criar Primeira Entrada
                      </Button>
                    )}
                  </CardContent>
                </Card>
              ) : (
                filteredEntries.map((entry, index) => (
                  <motion.div
                    key={entry.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                  >
                    <Card className="bg-gray-800/50 border-gray-700/50 hover:border-purple-500/50 transition-all">
                      <CardHeader>
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center space-x-3 mb-2">
                              <span className="text-2xl">{getMoodEmoji(entry.mood)}</span>
                              <CardTitle className="text-white">{entry.title}</CardTitle>
                              <Badge className={`${getMoodColor(entry.mood)} bg-transparent border-current`}>
                                {entry.mood}/10
                              </Badge>
                            </div>
                            <div className="flex items-center space-x-4 text-sm text-gray-400">
                              <div className="flex items-center">
                                <Calendar className="mr-1 h-3 w-3" />
                                {entry.date.toLocaleDateString("pt-BR")}
                              </div>
                              <div className="flex flex-wrap gap-1">
                                {entry.emotions.map((emotion) => (
                                  <Badge key={emotion} variant="outline" className="text-xs">
                                    {emotion}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                          </div>
                          <div className="flex space-x-2">
                            <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white">
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="sm" className="text-gray-400 hover:text-red-400">
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <p className="text-gray-300 mb-4">{entry.content}</p>

                        {entry.gratitude && entry.gratitude.length > 0 && (
                          <div className="mb-4">
                            <h4 className="text-sm font-medium text-gray-400 mb-2">Gratidão:</h4>
                            <ul className="text-sm text-gray-300 space-y-1">
                              {entry.gratitude.map((item, index) => (
                                <li key={index} className="flex items-start">
                                  <span className="text-yellow-400 mr-2">•</span>
                                  {item}
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}

                        {entry.goals && entry.goals.length > 0 && (
                          <div className="mb-4">
                            <h4 className="text-sm font-medium text-gray-400 mb-2">Metas:</h4>
                            <ul className="text-sm text-gray-300 space-y-1">
                              {entry.goals.map((goal, index) => (
                                <li key={index} className="flex items-start">
                                  <span className="text-blue-400 mr-2">•</span>
                                  {goal}
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}

                        {entry.aiInsights && (
                          <div className="bg-purple-500/10 border border-purple-500/20 rounded-lg p-3">
                            <div className="flex items-start space-x-2">
                              <Brain className="h-4 w-4 text-purple-400 mt-0.5 flex-shrink-0" />
                              <div>
                                <h4 className="text-sm font-medium text-purple-300 mb-1">Insight da IA</h4>
                                <p className="text-sm text-gray-300">{entry.aiInsights}</p>
                              </div>
                            </div>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  </motion.div>
                ))
              )}
            </motion.div>
          </div>
        </SidebarInset>
      </div>
    </SidebarProvider>
  )
}
