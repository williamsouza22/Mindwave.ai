"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { TrendingUp, Heart, Brain, Zap, AlertTriangle } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { SidebarProvider, SidebarInset } from "@/components/ui/sidebar"
import { UserSidebar } from "@/components/dashboard/user-sidebar"
import { ModernDashboardHeader } from "@/components/dashboard/modern-dashboard-header"
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
} from "recharts"

interface EmotionalData {
  date: string
  happiness: number
  anxiety: number
  stress: number
  energy: number
  focus: number
  overall: number
}

interface EmotionalPattern {
  emotion: string
  frequency: number
  trend: "up" | "down" | "stable"
  triggers: string[]
}

export default function EmotionalMapPage() {
  const [selectedPeriod, setSelectedPeriod] = useState<"week" | "month" | "year">("week")
  const [currentMood, setCurrentMood] = useState(7)

  // Dados simulados
  const emotionalData: EmotionalData[] = [
    { date: "2024-01-15", happiness: 8, anxiety: 3, stress: 4, energy: 7, focus: 6, overall: 7 },
    { date: "2024-01-16", happiness: 6, anxiety: 5, stress: 6, energy: 5, focus: 5, overall: 5 },
    { date: "2024-01-17", happiness: 9, anxiety: 2, stress: 3, energy: 8, focus: 8, overall: 8 },
    { date: "2024-01-18", happiness: 7, anxiety: 4, stress: 5, energy: 6, focus: 7, overall: 6 },
    { date: "2024-01-19", happiness: 8, anxiety: 3, stress: 4, energy: 7, focus: 7, overall: 7 },
    { date: "2024-01-20", happiness: 5, anxiety: 7, stress: 8, energy: 4, focus: 4, overall: 4 },
    { date: "2024-01-21", happiness: 9, anxiety: 2, stress: 2, energy: 9, focus: 8, overall: 9 },
  ]

  const radarData = [
    { emotion: "Felicidade", value: 7.5, fullMark: 10 },
    { emotion: "Ansiedade", value: 3.8, fullMark: 10 },
    { emotion: "Estresse", value: 4.2, fullMark: 10 },
    { emotion: "Energia", value: 6.8, fullMark: 10 },
    { emotion: "Foco", value: 6.5, fullMark: 10 },
    { emotion: "Motivação", value: 7.2, fullMark: 10 },
  ]

  const patterns: EmotionalPattern[] = [
    {
      emotion: "Ansiedade",
      frequency: 35,
      trend: "down",
      triggers: ["Trabalho", "Redes sociais", "Notícias"],
    },
    {
      emotion: "Felicidade",
      frequency: 68,
      trend: "up",
      triggers: ["Exercícios", "Música", "Amigos"],
    },
    {
      emotion: "Estresse",
      frequency: 42,
      trend: "stable",
      triggers: ["Prazos", "Trânsito", "Multitarefas"],
    },
  ]

  const getMoodEmoji = (mood: number) => {
    if (mood >= 8) return { emoji: "😊", color: "text-green-400", label: "Excelente" }
    if (mood >= 6) return { emoji: "😐", color: "text-yellow-400", label: "Bem" }
    if (mood >= 4) return { emoji: "😔", color: "text-orange-400", label: "Baixo" }
    return { emoji: "😢", color: "text-red-400", label: "Muito baixo" }
  }

  const currentMoodData = getMoodEmoji(currentMood)

  return (
    <SidebarProvider>
      <div className="layout">
        <UserSidebar />
        <SidebarInset className="conteudo">
          <ModernDashboardHeader
            title="Mapa Emocional"
            subtitle="Análise detalhada dos seus padrões emocionais"
            breadcrumbs={[
              { label: "Dashboard", href: "/dashboard" },
              { label: "Mapa Emocional", href: "/emotional-map" },
            ]}
          />

          <div className="p-6 space-y-6 max-w-full">
            {/* Current Mood */}
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
              <Card className="bg-gradient-to-r from-purple-900/20 to-blue-900/20 border-purple-500/30">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <Heart className="mr-2 h-5 w-5 text-purple-400" />
                    Como você está se sentindo agora?
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between mb-6">
                    <div className="text-center">
                      <div className="text-6xl mb-2">{currentMoodData.emoji}</div>
                      <p className={`text-lg font-semibold ${currentMoodData.color}`}>{currentMoodData.label}</p>
                      <p className="text-gray-400">Nível: {currentMood}/10</p>
                    </div>

                    <div className="flex-1 ml-8">
                      <input
                        type="range"
                        min="1"
                        max="10"
                        value={currentMood}
                        onChange={(e) => setCurrentMood(Number.parseInt(e.target.value))}
                        className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
                        aria-label="Selecione seu humor atual"
                      />
                      <div className="flex justify-between text-sm text-gray-500 mt-2">
                        <span>Muito mal</span>
                        <span>Excelente</span>
                      </div>
                    </div>
                  </div>

                  <Button className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700">
                    Registrar Estado Atual
                  </Button>
                </CardContent>
              </Card>
            </motion.div>

            {/* Period Selector */}
            <div className="flex space-x-2">
              {(["week", "month", "year"] as const).map((period) => (
                <Button
                  key={period}
                  variant={selectedPeriod === period ? "default" : "outline"}
                  onClick={() => setSelectedPeriod(period)}
                  className={selectedPeriod === period ? "bg-purple-600 hover:bg-purple-700" : ""}
                >
                  {period === "week" ? "Semana" : period === "month" ? "Mês" : "Ano"}
                </Button>
              ))}
            </div>

            {/* Charts Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Emotional Timeline */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.1 }}
              >
                <Card className="bg-gray-800/50 border-gray-700/50">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center">
                      <TrendingUp className="mr-2 h-5 w-5 text-blue-400" />
                      Evolução Emocional
                    </CardTitle>
                    <CardDescription>Acompanhe suas emoções ao longo do tempo</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <LineChart data={emotionalData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                        <XAxis
                          dataKey="date"
                          stroke="#9CA3AF"
                          tickFormatter={(value) =>
                            new Date(value).toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit" })
                          }
                        />
                        <YAxis stroke="#9CA3AF" domain={[0, 10]} />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: "#1F2937",
                            border: "1px solid #374151",
                            borderRadius: "8px",
                            color: "#F3F4F6",
                          }}
                        />
                        <Line type="monotone" dataKey="happiness" stroke="#10B981" strokeWidth={2} name="Felicidade" />
                        <Line type="monotone" dataKey="anxiety" stroke="#EF4444" strokeWidth={2} name="Ansiedade" />
                        <Line type="monotone" dataKey="stress" stroke="#F59E0B" strokeWidth={2} name="Estresse" />
                        <Line type="monotone" dataKey="overall" stroke="#8B5CF6" strokeWidth={3} name="Geral" />
                      </LineChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </motion.div>

              {/* Emotional Radar */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.2 }}
              >
                <Card className="bg-gray-800/50 border-gray-700/50">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center">
                      <Brain className="mr-2 h-5 w-5 text-purple-400" />
                      Perfil Emocional
                    </CardTitle>
                    <CardDescription>Visão geral do seu estado emocional atual</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <RadarChart data={radarData}>
                        <PolarGrid stroke="#374151" />
                        <PolarAngleAxis dataKey="emotion" tick={{ fill: "#9CA3AF", fontSize: 12 }} />
                        <PolarRadiusAxis angle={90} domain={[0, 10]} tick={{ fill: "#9CA3AF", fontSize: 10 }} />
                        <Radar
                          name="Nível"
                          dataKey="value"
                          stroke="#8B5CF6"
                          fill="#8B5CF6"
                          fillOpacity={0.3}
                          strokeWidth={2}
                        />
                      </RadarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </motion.div>
            </div>

            {/* Emotional Patterns */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
            >
              <Card className="bg-gray-800/50 border-gray-700/50">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <Zap className="mr-2 h-5 w-5 text-yellow-400" />
                    Padrões Emocionais
                  </CardTitle>
                  <CardDescription>Identifique gatilhos e tendências em suas emoções</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {patterns.map((pattern, index) => (
                      <div key={pattern.emotion} className="p-4 bg-gray-700/30 rounded-lg">
                        <div className="flex items-center justify-between mb-3">
                          <h4 className="text-white font-medium">{pattern.emotion}</h4>
                          <Badge
                            className={`${
                              pattern.trend === "up"
                                ? "bg-green-500/20 text-green-400"
                                : pattern.trend === "down"
                                  ? "bg-red-500/20 text-red-400"
                                  : "bg-yellow-500/20 text-yellow-400"
                            }`}
                          >
                            {pattern.trend === "up" ? "↗️" : pattern.trend === "down" ? "↘️" : "→"}
                            {pattern.trend === "up"
                              ? "Melhorando"
                              : pattern.trend === "down"
                                ? "Diminuindo"
                                : "Estável"}
                          </Badge>
                        </div>

                        <div className="mb-3">
                          <div className="flex justify-between text-sm text-gray-400 mb-1">
                            <span>Frequência</span>
                            <span>{pattern.frequency}%</span>
                          </div>
                          <Progress value={pattern.frequency} className="h-2" />
                        </div>

                        <div>
                          <p className="text-sm text-gray-400 mb-2">Principais gatilhos:</p>
                          <div className="flex flex-wrap gap-1">
                            {pattern.triggers.map((trigger) => (
                              <Badge key={trigger} variant="outline" className="text-xs">
                                {trigger}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Insights and Recommendations */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
            >
              <Card className="bg-gray-800/50 border-gray-700/50">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <AlertTriangle className="mr-2 h-5 w-5 text-orange-400" />
                    Insights e Recomendações
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h4 className="text-white font-medium mb-3">📈 Pontos Positivos</h4>
                      <ul className="space-y-2 text-gray-300">
                        <li className="flex items-start">
                          <span className="text-green-400 mr-2">•</span>
                          Sua felicidade aumentou 15% esta semana
                        </li>
                        <li className="flex items-start">
                          <span className="text-green-400 mr-2">•</span>
                          Níveis de ansiedade estão diminuindo consistentemente
                        </li>
                        <li className="flex items-start">
                          <span className="text-green-400 mr-2">•</span>
                          Exercícios têm impacto positivo no seu humor
                        </li>
                      </ul>
                    </div>

                    <div>
                      <h4 className="text-white font-medium mb-3">💡 Recomendações</h4>
                      <ul className="space-y-2 text-gray-300">
                        <li className="flex items-start">
                          <span className="text-blue-400 mr-2">•</span>
                          Considere limitar o tempo em redes sociais
                        </li>
                        <li className="flex items-start">
                          <span className="text-blue-400 mr-2">•</span>
                          Pratique respiração profunda antes de reuniões
                        </li>
                        <li className="flex items-start">
                          <span className="text-blue-400 mr-2">•</span>
                          Mantenha a rotina de exercícios às 18h
                        </li>
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </SidebarInset>
      </div>
    </SidebarProvider>
  )
}
