"use client"

import type React from "react"

import { useState } from "react"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { useToast } from "@/hooks/use-toast"
import { Heart, Mail, ArrowLeft, CheckCircle, AlertCircle } from "lucide-react"
import Link from "next/link"
import { useAuth } from "@/lib/auth/auth-context"

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)
  const [error, setError] = useState("")

  const { resetPassword } = useAuth()
  const { toast } = useToast()

  const validateEmail = (email: string) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    return emailRegex.test(email)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")

    if (!validateEmail(email)) {
      setError("Por favor, insira um e-mail válido.")
      return
    }

    setIsLoading(true)

    try {
      const { error } = await resetPassword(email)

      if (error) {
        setError("Não foi possível enviar o e-mail. Verifique se o endereço está correto.")
        toast({
          title: "Erro ao enviar e-mail",
          description: "Verifique se o e-mail está correto e tente novamente.",
          variant: "destructive",
        })
      } else {
        setIsSuccess(true)
        toast({
          title: "E-mail enviado! 📧",
          description: "Verifique sua caixa de entrada para redefinir sua senha.",
        })
      }
    } catch (error) {
      setError("Ocorreu um erro inesperado. Tente novamente.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-indigo-100 flex items-center justify-center p-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="w-full max-w-md"
      >
        <Card className="bg-white/80 backdrop-blur-sm shadow-2xl border-0">
          <CardContent className="p-8">
            <div className="text-center mb-8">
              <Link href="/auth" className="inline-flex items-center space-x-2 mb-6">
                <div className="h-10 w-10 rounded-xl bg-gradient-to-r from-blue-600 to-purple-600 flex items-center justify-center">
                  <Heart className="h-6 w-6 text-white" />
                </div>
                <span className="font-bold text-2xl bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                  MindWave.AI
                </span>
              </Link>

              {!isSuccess ? (
                <>
                  <h1 className="text-2xl font-bold text-gray-800 mb-2">Recuperar Senha</h1>
                  <p className="text-gray-600">Digite seu e-mail e enviaremos um link para redefinir sua senha</p>
                </>
              ) : (
                <>
                  <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <CheckCircle className="h-8 w-8 text-green-600" />
                  </div>
                  <h1 className="text-2xl font-bold text-gray-800 mb-2">E-mail Enviado!</h1>
                  <p className="text-gray-600">
                    Verifique sua caixa de entrada e siga as instruções para redefinir sua senha
                  </p>
                </>
              )}
            </div>

            {!isSuccess ? (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700">E-mail</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                    <Input
                      type="email"
                      placeholder="seu@email.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className={`pl-10 h-12 border-gray-200 focus:border-blue-400 focus:ring-blue-400 ${
                        error ? "border-red-400" : ""
                      }`}
                      required
                    />
                  </div>
                  {error && (
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="flex items-center space-x-1 text-red-500 text-xs"
                    >
                      <AlertCircle className="h-3 w-3" />
                      <span>{error}</span>
                    </motion.div>
                  )}
                </div>

                <Button
                  type="submit"
                  disabled={isLoading || !email}
                  className="w-full h-12 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-medium"
                >
                  {isLoading ? (
                    <div className="flex items-center space-x-2">
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      <span>Enviando...</span>
                    </div>
                  ) : (
                    "Enviar Link de Recuperação"
                  )}
                </Button>
              </form>
            ) : (
              <div className="space-y-4">
                <Button
                  onClick={() => {
                    setIsSuccess(false)
                    setEmail("")
                    setError("")
                  }}
                  variant="outline"
                  className="w-full h-12 border-gray-200 hover:bg-gray-50"
                >
                  Enviar Novamente
                </Button>
              </div>
            )}

            <div className="mt-8 text-center">
              <Link href="/auth" className="inline-flex items-center text-sm text-blue-600 hover:text-blue-700">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Voltar para o login
              </Link>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  )
}
