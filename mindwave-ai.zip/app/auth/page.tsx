"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { useRouter } from "next/navigation"
import { AuthForm } from "@/components/auth/auth-form"
import { BrainIllustration } from "@/components/auth/brain-illustration"
import { useAuth } from "@/lib/auth/auth-context"

export default function AuthPage() {
  const [isLogin, setIsLogin] = useState(true)
  const { user } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (user) {
      router.push("/dashboard")
    }
  }, [user, router])

  if (user) {
    return null // Prevent flash while redirecting
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0B1426] via-[#1e293b] to-[#0B1426] flex">
      {/* Left Side - Illustration */}
      <div className="hidden lg:flex lg:w-1/2 items-center justify-center p-12">
        <motion.div
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-md text-center"
        >
          <BrainIllustration />
          <h2 className="text-3xl font-bold text-white mb-4">
            Bem-vindo ao{" "}
            <span className="bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
              MindWave.AI
            </span>
          </h2>
          <p className="text-gray-300 text-lg leading-relaxed">
            Sua jornada de bem-estar mental começa aqui. Nossa IA empática está pronta para te apoiar 24/7.
          </p>
          <div className="mt-8 space-y-4">
            <div className="flex items-center text-gray-300">
              <div className="w-2 h-2 bg-green-400 rounded-full mr-3"></div>
              <span>Apoio emocional 24/7 via WhatsApp</span>
            </div>
            <div className="flex items-center text-gray-300">
              <div className="w-2 h-2 bg-blue-400 rounded-full mr-3"></div>
              <span>IA especializada em ansiedade e burnout</span>
            </div>
            <div className="flex items-center text-gray-300">
              <div className="w-2 h-2 bg-purple-400 rounded-full mr-3"></div>
              <span>Técnicas validadas cientificamente</span>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Right Side - Auth Form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-8">
        <motion.div
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8 }}
          className="w-full max-w-md"
        >
          <div className="text-center mb-8 lg:hidden">
            <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-blue-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" />
              </svg>
            </div>
            <h1 className="text-2xl font-bold text-white">MindWave.AI</h1>
          </div>

          <AuthForm isLogin={isLogin} onToggleMode={() => setIsLogin(!isLogin)} />

          <div className="mt-6 text-center">
            <button
              onClick={() => setIsLogin(!isLogin)}
              className="text-purple-400 hover:text-purple-300 transition-colors"
            >
              {isLogin ? "Não tem uma conta? Cadastre-se" : "Já tem uma conta? Faça login"}
            </button>
          </div>
        </motion.div>
      </div>
    </div>
  )
}
