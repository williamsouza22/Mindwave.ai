"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { CheckCircle, Loader2 } from "lucide-react"
import { useAuth } from "@/lib/auth/auth-context"

export default function ConfirmedPage() {
  const [countdown, setCountdown] = useState(5)
  const router = useRouter()
  const { user, loading } = useAuth()

  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(timer)
          if (user) {
            router.push("/onboarding")
          } else {
            router.push("/auth")
          }
          return 0
        }
        return prev - 1
      })
    }, 1000)

    return () => clearInterval(timer)
  }, [router, user])

  const handleContinue = () => {
    if (user) {
      router.push("/onboarding")
    } else {
      router.push("/auth")
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 p-4">
      <Card className="w-full max-w-md bg-white/10 backdrop-blur-lg border-white/20">
        <CardHeader className="text-center">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-green-100">
            <CheckCircle className="h-8 w-8 text-green-600" />
          </div>
          <CardTitle className="text-2xl font-bold text-white">Email Confirmado!</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 text-center">
          <p className="text-gray-300">
            Sua conta foi confirmada com sucesso. Você será redirecionado automaticamente em {countdown} segundos.
          </p>

          {loading && (
            <div className="flex items-center justify-center space-x-2 text-gray-300">
              <Loader2 className="h-4 w-4 animate-spin" />
              <span>Carregando...</span>
            </div>
          )}

          <Button
            onClick={handleContinue}
            className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
          >
            Continuar para o Dashboard
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
