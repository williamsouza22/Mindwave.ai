import { Loader2 } from "lucide-react"

export default function Loading() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
      <div className="flex items-center space-x-2 text-white">
        <Loader2 className="h-6 w-6 animate-spin" />
        <span>Confirmando email...</span>
      </div>
    </div>
  )
}
