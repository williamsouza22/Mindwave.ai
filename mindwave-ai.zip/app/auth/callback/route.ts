import { createRouteHandlerClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"
import { NextResponse } from "next/server"
import type { Database } from "@/lib/supabase/types"

export async function GET(request: Request) {
  const requestUrl = new URL(request.url)
  const code = requestUrl.searchParams.get("code")
  const error = requestUrl.searchParams.get("error")
  const errorDescription = requestUrl.searchParams.get("error_description")

  console.log("Callback received:", { code: !!code, error, errorDescription })

  // Handle OAuth errors
  if (error) {
    console.error("OAuth error:", error, errorDescription)
    let errorMessage = "Erro na autenticação"

    switch (error) {
      case "access_denied":
        errorMessage = "Acesso negado pelo usuário"
        break
      case "invalid_client":
        errorMessage = "Configuração OAuth inválida"
        break
      case "server_error":
        errorMessage = "Erro no servidor de autenticação"
        break
      case "invalid_request":
        errorMessage = "Requisição OAuth inválida"
        break
      default:
        errorMessage = errorDescription || "Erro desconhecido na autenticação"
    }

    return NextResponse.redirect(`${requestUrl.origin}/auth?error=${encodeURIComponent(errorMessage)}`)
  }

  if (code) {
    const cookieStore = cookies()
    const supabase = createRouteHandlerClient<Database>({
      cookies: () => cookieStore,
    })

    try {
      console.log("Exchanging code for session...")
      const { data, error: exchangeError } = await supabase.auth.exchangeCodeForSession(code)

      if (exchangeError) {
        console.error("Error exchanging code for session:", exchangeError)
        return NextResponse.redirect(
          `${requestUrl.origin}/auth?error=${encodeURIComponent("Erro no callback de autenticação: " + exchangeError.message)}`,
        )
      }

      if (data.user) {
        console.log("User authenticated:", data.user.email)

        // Check if user profile exists
        const { data: profile, error: profileError } = await supabase
          .from("users")
          .select("*")
          .eq("id", data.user.id)
          .single()

        console.log("Profile check:", { exists: !!profile, error: profileError?.code })

        // Create profile if it doesn't exist (for OAuth users)
        if (profileError && profileError.code === "PGRST116") {
          const userName =
            data.user.user_metadata?.full_name ||
            data.user.user_metadata?.name ||
            data.user.email?.split("@")[0] ||
            "Usuário"

          console.log("Creating new user profile:", { userName, email: data.user.email })

          const { error: insertError } = await supabase.from("users").insert({
            id: data.user.id,
            email: data.user.email!,
            name: userName,
            avatar_url: data.user.user_metadata?.avatar_url || null,
            plan: "free",
            onboarding_completed: false,
          })

          if (insertError) {
            console.error("Error creating user profile:", insertError)
            return NextResponse.redirect(
              `${requestUrl.origin}/auth?error=${encodeURIComponent("Erro ao criar perfil do usuário: " + insertError.message)}`,
            )
          }

          console.log("User profile created successfully")
        }

        // Update last login and avatar
        const { error: updateError } = await supabase
          .from("users")
          .update({
            last_login: new Date().toISOString(),
            avatar_url: data.user.user_metadata?.avatar_url || profile?.avatar_url,
          })
          .eq("id", data.user.id)

        if (updateError) {
          console.error("Error updating user login:", updateError)
        }

        // Redirect based on onboarding status
        const redirectTo = profile?.onboarding_completed ? "/dashboard" : "/onboarding"
        console.log("Redirecting to:", redirectTo)

        return NextResponse.redirect(`${requestUrl.origin}${redirectTo}`)
      }
    } catch (error) {
      console.error("Callback error:", error)
      return NextResponse.redirect(
        `${requestUrl.origin}/auth?error=${encodeURIComponent("Erro interno no callback: " + (error as Error).message)}`,
      )
    }
  }

  // Redirect to auth page if no code
  console.log("No code provided, redirecting to auth")
  return NextResponse.redirect(`${requestUrl.origin}/auth`)
}
