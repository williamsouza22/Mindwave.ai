"use client"

import { useState, useRef, useEffect } from "react"
import { motion } from "framer-motion"
import { Play, Pause, Volume2, VolumeX, RotateCcw, Timer, Shuffle, Heart } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Slider } from "@/components/ui/slider"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { SidebarProvider, SidebarInset } from "@/components/ui/sidebar"
import { UserSidebar } from "@/components/dashboard/user-sidebar"
import { ModernDashboardHeader } from "@/components/dashboard/modern-dashboard-header"

interface Sound {
  id: string
  name: string
  description: string
  category: string
  duration: string
  image: string
  audioUrl: string
  benefits: string[]
  color: string
}

interface Playlist {
  id: string
  name: string
  description: string
  sounds: string[]
  duration: string
}

export default function NatureSoundsPage() {
  const [currentSound, setCurrentSound] = useState<Sound | null>(null)
  const [isPlaying, setIsPlaying] = useState(false)
  const [volume, setVolume] = useState([70])
  const [currentTime, setCurrentTime] = useState(0)
  const [duration, setDuration] = useState(0)
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [timer, setTimer] = useState<number | null>(null)
  const [timeLeft, setTimeLeft] = useState<number | null>(null)
  const audioRef = useRef<HTMLAudioElement | null>(null)
  const timerRef = useRef<NodeJS.Timeout | null>(null)

  const sounds: Sound[] = [
    {
      id: "rain",
      name: "Chuva Suave",
      description: "Som relaxante de chuva leve caindo",
      category: "weather",
      duration: "60:00",
      image: "/placeholder.svg?height=200&width=300",
      audioUrl: "/sounds/rain.mp3",
      benefits: ["Relaxamento", "Foco", "Sono"],
      color: "from-blue-500 to-cyan-500",
    },
    {
      id: "ocean",
      name: "Ondas do Oceano",
      description: "Ondas suaves quebrando na praia",
      category: "water",
      duration: "45:00",
      image: "/placeholder.svg?height=200&width=300",
      audioUrl: "/sounds/ocean.mp3",
      benefits: ["Meditação", "Calma", "Concentração"],
      color: "from-teal-500 to-blue-500",
    },
    {
      id: "forest",
      name: "Floresta Tropical",
      description: "Sons da natureza com pássaros cantando",
      category: "nature",
      duration: "90:00",
      image: "/placeholder.svg?height=200&width=300",
      audioUrl: "/sounds/forest.mp3",
      benefits: ["Energia", "Vitalidade", "Conexão"],
      color: "from-green-500 to-emerald-500",
    },
    {
      id: "thunder",
      name: "Tempestade Distante",
      description: "Trovões suaves com chuva",
      category: "weather",
      duration: "30:00",
      image: "/placeholder.svg?height=200&width=300",
      audioUrl: "/sounds/thunder.mp3",
      benefits: ["Sono Profundo", "Relaxamento"],
      color: "from-gray-500 to-slate-600",
    },
    {
      id: "birds",
      name: "Canto dos Pássaros",
      description: "Melodia matinal dos pássaros",
      category: "nature",
      duration: "40:00",
      image: "/placeholder.svg?height=200&width=300",
      audioUrl: "/sounds/birds.mp3",
      benefits: ["Despertar", "Alegria", "Energia"],
      color: "from-yellow-500 to-orange-500",
    },
    {
      id: "waterfall",
      name: "Cachoeira",
      description: "Água corrente de uma cachoeira",
      category: "water",
      duration: "55:00",
      image: "/placeholder.svg?height=200&width=300",
      audioUrl: "/sounds/waterfall.mp3",
      benefits: ["Purificação", "Renovação", "Foco"],
      color: "from-cyan-500 to-teal-500",
    },
  ]

  const playlists: Playlist[] = [
    {
      id: "sleep",
      name: "Para Dormir",
      description: "Sons suaves para uma noite tranquila",
      sounds: ["rain", "ocean", "thunder"],
      duration: "3h 15min",
    },
    {
      id: "focus",
      name: "Foco e Concentração",
      description: "Ambiente sonoro para produtividade",
      sounds: ["forest", "waterfall", "rain"],
      duration: "2h 45min",
    },
    {
      id: "meditation",
      name: "Meditação",
      description: "Sons para prática meditativa",
      sounds: ["ocean", "forest", "birds"],
      duration: "2h 55min",
    },
  ]

  const categories = [
    { value: "all", label: "Todos" },
    { value: "nature", label: "Natureza" },
    { value: "water", label: "Água" },
    { value: "weather", label: "Clima" },
  ]

  const timerOptions = [
    { value: null, label: "Sem timer" },
    { value: 15, label: "15 minutos" },
    { value: 30, label: "30 minutos" },
    { value: 60, label: "1 hora" },
    { value: 120, label: "2 horas" },
  ]

  const filteredSounds =
    selectedCategory === "all" ? sounds : sounds.filter((sound) => sound.category === selectedCategory)

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = volume[0] / 100
    }
  }, [volume])

  useEffect(() => {
    if (timer && isPlaying) {
      setTimeLeft(timer * 60) // Convert minutes to seconds
      timerRef.current = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev && prev <= 1) {
            handleStop()
            return null
          }
          return prev ? prev - 1 : null
        })
      }, 1000)
    } else {
      if (timerRef.current) {
        clearInterval(timerRef.current)
      }
      setTimeLeft(null)
    }

    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current)
      }
    }
  }, [timer, isPlaying])

  const handlePlay = (sound: Sound) => {
    if (currentSound?.id === sound.id && isPlaying) {
      setIsPlaying(false)
      if (audioRef.current) {
        audioRef.current.pause()
      }
    } else {
      setCurrentSound(sound)
      setIsPlaying(true)
      // In a real app, you would load and play the actual audio file
      // For demo purposes, we'll simulate audio playback
    }
  }

  const handleStop = () => {
    setIsPlaying(false)
    setCurrentSound(null)
    setCurrentTime(0)
    setTimeLeft(null)
    if (audioRef.current) {
      audioRef.current.pause()
      audioRef.current.currentTime = 0
    }
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  return (
    <SidebarProvider>
      <div className="layout">
        <UserSidebar />
        <SidebarInset className="conteudo">
          <ModernDashboardHeader
            title="Sons da Natureza"
            subtitle="Ambiente sonoro para relaxamento e concentração"
            breadcrumbs={[
              { label: "Dashboard", href: "/dashboard" },
              { label: "Sons da Natureza", href: "/nature-sounds" },
            ]}
          />

          <div className="p-6 space-y-6 max-w-full">
            {/* Player Controls */}
            {currentSound && (
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
                <Card className="bg-gray-800/50 border-gray-700/50">
                  <CardContent className="p-6">
                    <div className="flex items-center space-x-6">
                      <div
                        className={`w-20 h-20 rounded-lg bg-gradient-to-r ${currentSound.color} flex items-center justify-center flex-shrink-0`}
                      >
                        <div className="text-2xl">🎵</div>
                      </div>

                      <div className="flex-1">
                        <h3 className="text-xl font-semibold text-white mb-1">{currentSound.name}</h3>
                        <p className="text-gray-400 mb-3">{currentSound.description}</p>

                        <div className="flex items-center space-x-4">
                          <Button
                            onClick={() => handlePlay(currentSound)}
                            className="bg-purple-600 hover:bg-purple-700"
                          >
                            {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                          </Button>

                          <Button variant="outline" onClick={handleStop} className="border-gray-600 bg-transparent">
                            <RotateCcw className="h-4 w-4" />
                          </Button>

                          <div className="flex items-center space-x-2">
                            <VolumeX className="h-4 w-4 text-gray-400" />
                            <Slider value={volume} onValueChange={setVolume} max={100} step={1} className="w-24" />
                            <Volume2 className="h-4 w-4 text-gray-400" />
                          </div>

                          {timeLeft && (
                            <div className="flex items-center space-x-2 text-sm text-gray-400">
                              <Timer className="h-4 w-4" />
                              <span>{formatTime(timeLeft)}</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )}

            {/* Filters and Timer */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between"
            >
              <div className="flex flex-col sm:flex-row gap-3">
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger className="w-[180px] bg-gray-800/50 border-gray-700">
                    <SelectValue placeholder="Categoria" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((category) => (
                      <SelectItem key={category.value} value={category.value}>
                        {category.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select
                  value={timer?.toString() || "null"}
                  onValueChange={(value) => setTimer(value === "null" ? null : Number.parseInt(value))}
                >
                  <SelectTrigger className="w-[180px] bg-gray-800/50 border-gray-700">
                    <Timer className="mr-2 h-4 w-4" />
                    <SelectValue placeholder="Timer" />
                  </SelectTrigger>
                  <SelectContent>
                    {timerOptions.map((option) => (
                      <SelectItem key={option.value?.toString() || "null"} value={option.value?.toString() || "null"}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <Button variant="outline" className="border-gray-600 bg-transparent">
                <Shuffle className="mr-2 h-4 w-4" />
                Modo Aleatório
              </Button>
            </motion.div>

            {/* Playlists */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <h2 className="text-2xl font-bold text-white mb-4">Playlists Recomendadas</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {playlists.map((playlist) => (
                  <Card
                    key={playlist.id}
                    className="bg-gray-800/50 border-gray-700/50 hover:border-purple-500/50 transition-all cursor-pointer"
                  >
                    <CardHeader>
                      <CardTitle className="text-white flex items-center">
                        <Heart className="mr-2 h-5 w-5 text-purple-400" />
                        {playlist.name}
                      </CardTitle>
                      <CardDescription>{playlist.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-400">{playlist.duration}</span>
                        <Button size="sm" className="bg-purple-600 hover:bg-purple-700">
                          <Play className="h-3 w-3" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </motion.div>

            {/* Sound Library */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
            >
              <h2 className="text-2xl font-bold text-white mb-4">Biblioteca de Sons</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredSounds.map((sound, index) => (
                  <motion.div
                    key={sound.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: 0.1 * index }}
                  >
                    <Card
                      className={`bg-gray-800/50 border-gray-700/50 hover:border-purple-500/50 transition-all cursor-pointer group ${
                        currentSound?.id === sound.id ? "border-purple-500/70" : ""
                      }`}
                    >
                      <div className="relative">
                        <div
                          className={`h-48 bg-gradient-to-r ${sound.color} rounded-t-lg flex items-center justify-center`}
                        >
                          <div className="text-6xl opacity-80">
                            {sound.category === "water"
                              ? "🌊"
                              : sound.category === "weather"
                                ? "🌧️"
                                : sound.category === "nature"
                                  ? "🌲"
                                  : "🎵"}
                          </div>
                        </div>
                        <div className="absolute inset-0 bg-black/20 rounded-t-lg flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                          <Button
                            onClick={() => handlePlay(sound)}
                            className="bg-white/20 backdrop-blur-sm hover:bg-white/30"
                          >
                            {currentSound?.id === sound.id && isPlaying ? (
                              <Pause className="h-6 w-6" />
                            ) : (
                              <Play className="h-6 w-6" />
                            )}
                          </Button>
                        </div>
                      </div>

                      <CardHeader>
                        <div className="flex items-center justify-between">
                          <CardTitle className="text-white">{sound.name}</CardTitle>
                          <Badge variant="outline" className="text-xs">
                            {sound.duration}
                          </Badge>
                        </div>
                        <CardDescription>{sound.description}</CardDescription>
                      </CardHeader>

                      <CardContent>
                        <div className="flex flex-wrap gap-1">
                          {sound.benefits.map((benefit) => (
                            <Badge key={benefit} className="bg-purple-500/20 text-purple-300 text-xs">
                              {benefit}
                            </Badge>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </SidebarInset>
      </div>
    </SidebarProvider>
  )
}
