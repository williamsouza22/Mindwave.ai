"use client"

import { useState } from "react"
import { SidebarProvider, SidebarInset, SidebarTrigger } from "@/components/ui/sidebar"
import { UserSidebar } from "@/components/dashboard/user-sidebar"
import { ModernDashboardHeader } from "@/components/dashboard/modern-dashboard-header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { CalendarIcon, Plus, Clock, Video, Heart, Brain, ChevronLeft, ChevronRight } from "lucide-react"
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb"

/* -------------------------------------------------------------------------- */
/*                                Mocked Data                                */
/* -------------------------------------------------------------------------- */

interface Appointment {
  id: number
  title: string
  date: string // yyyy-mm-dd
  time: string // hh:mm
  duration: number
  type: "therapy" | "checkin" | "meditation"
  therapist: string
  status: "confirmed" | "scheduled"
  color: string // tailwind gradient from-{color}-500 to-{color}-500
}

const APPOINTMENTS: Appointment[] = [
  {
    id: 1,
    title: "Sessão de Terapia",
    date: "2025-07-18",
    time: "14:00",
    duration: 60,
    type: "therapy",
    therapist: "Dra. Ana Silva",
    status: "confirmed",
    color: "from-blue-500 to-cyan-500",
  },
  {
    id: 2,
    title: "Check-in Semanal",
    date: "2025-07-20",
    time: "10:00",
    duration: 30,
    type: "checkin",
    therapist: "IA MindWave",
    status: "scheduled",
    color: "from-green-500 to-emerald-500",
  },
  {
    id: 3,
    title: "Meditação Guiada",
    date: "2025-07-21",
    time: "08:00",
    duration: 20,
    type: "meditation",
    therapist: "Sessão Automática",
    status: "scheduled",
    color: "from-purple-500 to-pink-500",
  },
]

/* -------------------------------------------------------------------------- */
/*                              Helper Functions                              */
/* -------------------------------------------------------------------------- */

const today = new Date()

function getDaysInMonth(month: number, year: number) {
  return new Date(year, month + 1, 0).getDate()
}

function getFirstWeekDay(month: number, year: number) {
  return new Date(year, month, 1).getDay()
}

const monthNames = [
  "Janeiro",
  "Fevereiro",
  "Março",
  "Abril",
  "Maio",
  "Junho",
  "Julho",
  "Agosto",
  "Setembro",
  "Outubro",
  "Novembro",
  "Dezembro",
]

/* -------------------------------------------------------------------------- */
/*                                  Component                                 */
/* -------------------------------------------------------------------------- */

export default function CalendarPage() {
  const [viewDate, setViewDate] = useState(new Date())
  const [selectedDate, setSelectedDate] = useState<Date | null>(null)

  const month = viewDate.getMonth()
  const year = viewDate.getFullYear()
  const daysInMonth = getDaysInMonth(month, year)
  const firstWeekDay = getFirstWeekDay(month, year)

  const handlePrevMonth = () => {
    const prev = new Date(year, month - 1, 1)
    setViewDate(prev)
  }

  const handleNextMonth = () => {
    const next = new Date(year, month + 1, 1)
    setViewDate(next)
  }

  const appointmentsForDate = (d: number) => {
    const dateStr = `${year}-${String(month + 1).padStart(2, "0")}-${String(d).padStart(2, "0")}`
    return APPOINTMENTS.filter((apt) => apt.date === dateStr)
  }

  const isToday = (d: number) => d === today.getDate() && month === today.getMonth() && year === today.getFullYear()

  return (
    <SidebarProvider>
      <UserSidebar />
      <SidebarInset className="flex min-h-screen flex-col">
        {/* ------------------------------- Header ------------------------------ */}
        <header className="flex h-16 shrink-0 items-center gap-2 border-b border-gray-800 bg-[#1A2332] px-4">
          <SidebarTrigger className="-ml-1 text-gray-300 hover:text-white" />
          <Separator orientation="vertical" className="mr-2 h-4 bg-gray-700" />
          <Breadcrumb>
            <BreadcrumbList>
              <BreadcrumbItem className="hidden md:block">
                <BreadcrumbLink href="/dashboard" className="text-gray-400 hover:text-white">
                  Dashboard
                </BreadcrumbLink>
              </BreadcrumbItem>
              <BreadcrumbSeparator className="hidden md:block text-gray-600" />
              <BreadcrumbItem>
                <BreadcrumbPage className="text-white">Agenda</BreadcrumbPage>
              </BreadcrumbItem>
            </BreadcrumbList>
          </Breadcrumb>
          <div className="ml-auto">
            <ModernDashboardHeader />
          </div>
        </header>

        {/* ------------------------------- Main -------------------------------- */}
        <main className="flex-1 bg-[#0B1426] p-6">
          <div className="mx-auto w-full max-w-7xl">
            {/* Top bar */}
            <div className="mb-6 flex flex-col items-start justify-between gap-4 sm:flex-row sm:items-center">
              <div>
                <h1 className="mb-1 text-3xl font-bold text-white">Agenda</h1>
                <p className="text-gray-400">Gerencie suas sessões e compromissos de bem-estar</p>
              </div>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handlePrevMonth}
                  className="bg-transparent text-gray-300 hover:bg-gray-800 hover:text-white"
                >
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleNextMonth}
                  className="bg-transparent text-gray-300 hover:bg-gray-800 hover:text-white"
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
                <Button className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
                  <Plus className="h-4 w-4 mr-2" />
                  Nova Sessão
                </Button>
              </div>
            </div>

            {/* Grid */}
            <div className="grid gap-6 xl:grid-cols-4">
              {/* Calendar */}
              <div className="xl:col-span-3">
                <Card className="border-gray-800 bg-[#1A2332]">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-white">
                      <CalendarIcon className="h-5 w-5 text-blue-400" />
                      {monthNames[month]} {year}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {/* Weekday labels */}
                    <div className="mb-2 grid grid-cols-7 gap-1">
                      {["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"].map((d) => (
                        <div key={d} className="p-2 text-center text-sm font-medium text-gray-400">
                          {d}
                        </div>
                      ))}
                    </div>

                    {/* Dates */}
                    <div className="grid grid-cols-7 gap-1">
                      {/* Empty slots */}
                      {Array.from({ length: firstWeekDay }).map((_, i) => (
                        <div key={`empty-${i}`} className="aspect-square p-1" />
                      ))}

                      {/* Days */}
                      {Array.from({ length: daysInMonth }).map((_, i) => {
                        const day = i + 1
                        const dayApts = appointmentsForDate(day)

                        return (
                          <div
                            key={day}
                            onClick={() => setSelectedDate(new Date(year, month, day))}
                            className={`aspect-square cursor-pointer rounded border border-gray-700 p-1 transition-colors hover:bg-gray-800 ${
                              isToday(day) ? "border-blue-600 bg-blue-900/40" : ""
                            }`}
                          >
                            <div className="flex h-full flex-col">
                              <span className={`text-sm ${isToday(day) ? "font-bold text-blue-300" : "text-white"}`}>
                                {day}
                              </span>
                              {/* Appointment bullets */}
                              <div className="mt-1 flex-1 space-y-1">
                                {dayApts.slice(0, 2).map((apt) => (
                                  <div
                                    key={apt.id}
                                    className={`truncate rounded bg-gradient-to-r ${apt.color} p-1 text-xs text-white`}
                                  >
                                    {apt.time}
                                  </div>
                                ))}
                                {dayApts.length > 2 && (
                                  <div className="text-xs text-gray-400">+{dayApts.length - 2} mais</div>
                                )}
                              </div>
                            </div>
                          </div>
                        )
                      })}
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Sidebar with today/upcoming */}
              <div className="space-y-6">
                {/* Today */}
                <ScheduleCard
                  title="Hoje"
                  emptyMessage="Nenhum compromisso hoje"
                  items={APPOINTMENTS.filter((a) => a.date === today.toISOString().split("T")[0])}
                />

                {/* Próximos */}
                <ScheduleCard
                  title="Próximos"
                  emptyMessage="Sem próximos compromissos"
                  items={APPOINTMENTS.filter((a) => new Date(a.date) > today).slice(0, 3)}
                />
              </div>
            </div>
          </div>
        </main>
      </SidebarInset>
    </SidebarProvider>
  )
}

/* -------------------------------------------------------------------------- */
/*                                  Helpers                                   */
/* -------------------------------------------------------------------------- */

interface ScheduleCardProps {
  title: string
  emptyMessage: string
  items: Appointment[]
}

function ScheduleCard({ title, emptyMessage, items }: ScheduleCardProps) {
  return (
    <Card className="border-gray-800 bg-[#1A2332]">
      <CardHeader>
        <CardTitle className="text-lg text-white">{title}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {items.length === 0 && <p className="py-4 text-center text-sm text-gray-400">{emptyMessage}</p>}

        {items.map((apt) => (
          <div key={apt.id} className="rounded-lg border border-gray-700 bg-[#0F1B2A] p-3">
            {/* Header */}
            <div className="mb-2 flex items-center justify-between">
              <div className="flex items-center gap-2">
                {apt.type === "therapy" && <Video className="h-4 w-4 text-blue-400" />}
                {apt.type === "checkin" && <Heart className="h-4 w-4 text-green-400" />}
                {apt.type === "meditation" && <Brain className="h-4 w-4 text-purple-400" />}
                <span className="text-sm font-medium text-white">{apt.title}</span>
              </div>
              <Badge
                variant="secondary"
                className={`border ${
                  apt.status === "confirmed"
                    ? "border-green-800 bg-green-900/50 text-green-300"
                    : "border-yellow-800 bg-yellow-900/50 text-yellow-300"
                } text-xs`}
              >
                {apt.status === "confirmed" ? "Confirmado" : "Agendado"}
              </Badge>
            </div>

            {/* Meta */}
            <div className="flex items-center gap-4 text-xs text-gray-400">
              <div className="flex items-center gap-1">
                <Clock className="h-3 w-3" />
                <span>{apt.time}</span>
              </div>
              <span>{apt.duration} min</span>
            </div>

            <p className="mt-1 text-xs text-gray-500">{apt.therapist}</p>
          </div>
        ))}
      </CardContent>
    </Card>
  )
}
