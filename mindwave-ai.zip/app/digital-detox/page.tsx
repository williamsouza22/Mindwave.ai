"use client"

import { SidebarProvider, SidebarInset, SidebarTrigger } from "@/components/ui/sidebar"
import { UserSidebar } from "@/components/dashboard/user-sidebar"
import { ModernDashboardHeader } from "@/components/dashboard/modern-dashboard-header"
import { DigitalDetox } from "@/components/dashboard/digital-detox"
import { Separator } from "@/components/ui/separator"
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb"

export default function DigitalDetoxPage() {
  return (
    <SidebarProvider>
      <UserSidebar />
      <SidebarInset className="flex flex-col min-h-screen">
        <header className="flex h-16 shrink-0 items-center gap-2 border-b border-gray-800 bg-[#1A2332] px-4">
          <SidebarTrigger className="-ml-1 text-gray-300 hover:text-white" />
          <Separator orientation="vertical" className="mr-2 h-4 bg-gray-700" />
          <Breadcrumb>
            <BreadcrumbList>
              <BreadcrumbItem className="hidden md:block">
                <BreadcrumbLink href="/dashboard" className="text-gray-400 hover:text-white">
                  Dashboard
                </BreadcrumbLink>
              </BreadcrumbItem>
              <BreadcrumbSeparator className="hidden md:block text-gray-600" />
              <BreadcrumbItem>
                <BreadcrumbPage className="text-white">Detox Digital</BreadcrumbPage>
              </BreadcrumbItem>
            </BreadcrumbList>
          </Breadcrumb>
          <div className="ml-auto">
            <ModernDashboardHeader />
          </div>
        </header>

        <main className="flex-1 bg-[#0B1426] p-6">
          <div className="max-w-full mx-auto">
            <div className="mb-6">
              <h1 className="text-3xl font-bold text-white mb-2">Detox Digital</h1>
              <p className="text-gray-400">Monitore e controle seu uso de dispositivos para melhor bem-estar</p>
            </div>

            <div className="w-full">
              <DigitalDetox />
            </div>
          </div>
        </main>
      </SidebarInset>
    </SidebarProvider>
  )
}
