"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import {
  MessageCircle,
  Heart,
  Brain,
  Leaf,
  Smartphone,
  Activity,
  Headphones,
  BarChart3,
  Star,
  ArrowRight,
  Play,
  CheckCircle,
  Users,
  Shield,
  Zap,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import Link from "next/link"

// Componente do Header
function Header() {
  return (
    <header className="sticky top-0 z-50 bg-[#0B1426]/95 backdrop-blur-sm border-b border-purple-500/20">
      <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 rounded-full bg-gradient-to-r from-purple-500 to-blue-500 flex items-center justify-center">
              <Heart className="h-4 w-4 text-white" />
            </div>
            <span className="text-xl font-bold text-white">MindWave.AI</span>
          </div>

          <nav className="hidden md:flex items-center space-x-6">
            <a href="#recursos" className="text-gray-300 hover:text-white transition-colors">
              Recursos
            </a>
            <a href="#como-funciona" className="text-gray-300 hover:text-white transition-colors">
              Como Funciona
            </a>
            <a href="#depoimentos" className="text-gray-300 hover:text-white transition-colors">
              Depoimentos
            </a>
            <a href="#precos" className="text-gray-300 hover:text-white transition-colors">
              Preços
            </a>
          </nav>

          <div className="flex items-center space-x-4">
            <Link href="/auth">
              <Button variant="ghost" className="text-gray-300 hover:text-white">
                Entrar
              </Button>
            </Link>
            <Link href="/signup">
              <Button className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700">
                Começar Grátis
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </header>
  )
}

// Componente principal da página
export default function LandingPage() {
  const [currentMood, setCurrentMood] = useState(7)

  // WhatsApp API integration
  const handleWhatsAppClick = () => {
    const message = encodeURIComponent("Olá! Gostaria de começar minha jornada de bem-estar com a MindWave.AI 🌟")
    const whatsappUrl = `https://wa.me/5511999999999?text=${message}`
    window.open(whatsappUrl, "_blank", "noopener,noreferrer")
  }

  const modules = [
    {
      title: "Cozy Mindfulness",
      description: "Meditações guiadas e exercícios de respiração para momentos de paz",
      icon: Heart,
      color: "from-pink-500 to-rose-500",
      href: "/breathing",
      features: ["Respiração 4-7-8", "Meditação guiada", "Sons da natureza"],
    },
    {
      title: "Detox Digital",
      description: "Monitore e reduza o tempo de tela para melhor qualidade de vida",
      icon: Smartphone,
      color: "from-green-500 to-emerald-500",
      href: "/digital-detox",
      features: ["Monitoramento de uso", "Lembretes inteligentes", "Metas personalizadas"],
    },
    {
      title: "Fitoterapia Inteligente",
      description: "Recomendações personalizadas de plantas medicinais",
      icon: Leaf,
      color: "from-green-400 to-teal-500",
      href: "/fitotherapy",
      features: ["Plantas medicinais", "Receitas naturais", "Guia de preparo"],
    },
    {
      title: "Análise Emocional",
      description: "IA avançada para mapear e entender seus padrões emocionais",
      icon: Brain,
      color: "from-purple-500 to-indigo-500",
      href: "/emotional-map",
      features: ["Mapa emocional", "Detecção de padrões", "Insights personalizados"],
    },
    {
      title: "Exercícios Terapêuticos",
      description: "Atividades físicas adaptadas para seu bem-estar mental",
      icon: Activity,
      color: "from-orange-500 to-red-500",
      href: "/exercises",
      features: ["Yoga terapêutica", "Exercícios de baixo impacto", "Rotinas personalizadas"],
    },
    {
      title: "Áudio Terapia",
      description: "Sons curativos e frequências para relaxamento profundo",
      icon: Headphones,
      color: "from-blue-500 to-cyan-500",
      href: "/nature-sounds",
      features: ["Frequências binaurais", "Sons da natureza", "Música terapêutica"],
    },
  ]

  const testimonials = [
    {
      name: "Ana Silva",
      role: "Executiva de Marketing",
      avatar: "/placeholder-user.jpg",
      rating: 5,
      text: "A MindWave.AI me ajudou a superar a ansiedade do trabalho. O apoio via WhatsApp é incrível, sempre disponível quando preciso.",
    },
    {
      name: "Carlos Mendes",
      role: "Desenvolvedor",
      avatar: "/placeholder-user.jpg",
      rating: 5,
      text: "O detox digital mudou minha vida. Consegui reduzir 4 horas de tela por dia e me sinto muito mais produtivo.",
    },
    {
      name: "Maria Santos",
      role: "Professora",
      avatar: "/placeholder-user.jpg",
      rating: 5,
      text: "As meditações guiadas são perfeitas para minha rotina. 10 minutos por dia fizeram toda a diferença no meu bem-estar.",
    },
  ]

  return (
    <div className="min-h-screen bg-[#0B1426]">
      <Header />

      <main>
        {/* Hero Section */}
        <section className="relative min-h-screen flex items-center justify-center px-4 py-20 bg-gradient-to-br from-[#0B1426] via-[#1e293b] to-[#0B1426]">
          <div className="container mx-auto max-w-7xl text-center">
            <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }}>
              <Badge className="mb-6 bg-purple-500/20 text-purple-300 border-purple-500/30">
                <Zap className="mr-2 h-3 w-3" />🤖 Apoio Emocional Inteligente
              </Badge>

              <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6 bg-gradient-to-r from-white via-purple-200 to-blue-200 bg-clip-text text-transparent leading-tight">
                Um abraço digital nos seus{" "}
                <span className="bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                  dias difíceis
                </span>
              </h1>

              <p className="text-xl md:text-2xl text-gray-300 mb-8 max-w-4xl mx-auto leading-relaxed">
                Plataforma empática com IA especializada em ansiedade, burnout, nomofobia e ecoansiedade. Apoio 24/7 via
                WhatsApp com técnicas validadas e comunidade acolhedora.
              </p>

              <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
                <Button
                  size="lg"
                  onClick={handleWhatsAppClick}
                  className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-lg px-8 py-4"
                  aria-label="Começar conversa no WhatsApp"
                >
                  <MessageCircle className="mr-2 h-5 w-5" />
                  Testar no WhatsApp
                </Button>

                <Link href="/dashboard">
                  <Button
                    variant="outline"
                    size="lg"
                    className="text-lg px-8 py-4 border-purple-500/50 text-purple-300 hover:bg-purple-500/10 bg-transparent"
                  >
                    <Play className="mr-2 h-5 w-5" />
                    Ver Demo Gratuita
                  </Button>
                </Link>
              </div>

              <div className="flex items-center justify-center space-x-8 text-sm text-gray-400">
                <div className="flex items-center">
                  <CheckCircle className="mr-2 h-4 w-4 text-green-400" />
                  Gratuito por 7 dias
                </div>
                <div className="flex items-center">
                  <Shield className="mr-2 h-4 w-4 text-blue-400" />
                  100% Privado e Seguro
                </div>
                <div className="flex items-center">
                  <Users className="mr-2 h-4 w-4 text-purple-400" />
                  +10.000 usuários ativos
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Mood Check Section */}
        <section className="py-16 px-4 bg-gray-900/20">
          <div className="container mx-auto max-w-7xl">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
              className="text-center mb-12"
            >
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Como você está se sentindo hoje?</h2>
              <p className="text-gray-400 text-lg max-w-2xl mx-auto">
                Nosso sistema de IA analisa seu estado emocional e oferece suporte personalizado
              </p>
            </motion.div>

            <div className="max-w-2xl mx-auto">
              <Card className="bg-gray-800/50 border-purple-500/20 backdrop-blur-sm">
                <CardContent className="p-8">
                  <div className="text-center mb-6">
                    <div className="text-6xl mb-4">
                      {currentMood >= 8 ? "😊" : currentMood >= 6 ? "😐" : currentMood >= 4 ? "😔" : "😢"}
                    </div>
                    <p className="text-2xl font-semibold text-white mb-2">Nível: {currentMood}/10</p>
                    <p className="text-gray-400">
                      {currentMood >= 8
                        ? "Ótimo!"
                        : currentMood >= 6
                          ? "Bem"
                          : currentMood >= 4
                            ? "Poderia estar melhor"
                            : "Precisa de apoio"}
                    </p>
                  </div>

                  <div className="space-y-4">
                    <input
                      type="range"
                      min="1"
                      max="10"
                      value={currentMood}
                      onChange={(e) => setCurrentMood(Number.parseInt(e.target.value))}
                      className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
                      style={{
                        background: `linear-gradient(to right, #8b5cf6 0%, #8b5cf6 ${(currentMood - 1) * 11.11}%, #374151 ${(currentMood - 1) * 11.11}%, #374151 100%)`,
                      }}
                      aria-label="Selecione seu nível de humor de 1 a 10"
                    />

                    <div className="flex justify-between text-sm text-gray-500">
                      <span>Muito mal</span>
                      <span>Excelente</span>
                    </div>
                  </div>

                  <Button
                    onClick={handleWhatsAppClick}
                    className="w-full mt-6 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                    aria-label="Receber apoio personalizado via WhatsApp"
                  >
                    Receber Apoio Personalizado
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Modules Section */}
        <section id="recursos" className="py-16 px-4">
          <div className="container mx-auto max-w-7xl">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
              className="text-center mb-12"
            >
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Módulos de Bem-Estar</h2>
              <p className="text-gray-400 text-lg max-w-3xl mx-auto">
                Cada módulo foi desenvolvido com base em evidências científicas para oferecer o melhor suporte para sua
                jornada de bem-estar mental
              </p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {modules.map((module, index) => (
                <motion.div
                  key={module.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  viewport={{ once: true }}
                >
                  <Link href={module.href}>
                    <Card className="bg-gray-800/30 border-gray-700/50 h-full group hover:bg-gray-800/50 transition-all duration-300 hover:scale-105">
                      <CardHeader>
                        <div
                          className={`w-12 h-12 rounded-lg bg-gradient-to-r ${module.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}
                        >
                          <module.icon className="h-6 w-6 text-white" />
                        </div>
                        <CardTitle className="text-white text-xl">{module.title}</CardTitle>
                        <CardDescription className="text-gray-400">{module.description}</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <ul className="space-y-2">
                          {module.features.map((feature) => (
                            <li key={feature} className="flex items-center text-sm text-gray-300">
                              <CheckCircle className="mr-2 h-4 w-4 text-green-400" />
                              {feature}
                            </li>
                          ))}
                        </ul>
                        <div className="mt-4 flex items-center text-purple-400 group-hover:text-purple-300">
                          <span className="text-sm font-medium">Explorar módulo</span>
                          <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* How it Works Section */}
        <section id="como-funciona" className="py-16 px-4 bg-gray-900/20">
          <div className="container mx-auto max-w-7xl">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
              className="text-center mb-12"
            >
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Como Funciona</h2>
              <p className="text-gray-400 text-lg max-w-3xl mx-auto">
                Três passos simples para transformar sua saúde mental
              </p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                {
                  step: "1",
                  title: "Conecte-se",
                  description: "Inicie uma conversa via WhatsApp e conte como está se sentindo",
                  icon: MessageCircle,
                },
                {
                  step: "2",
                  title: "Receba Apoio",
                  description: "Nossa IA empática oferece suporte personalizado e técnicas validadas",
                  icon: Heart,
                },
                {
                  step: "3",
                  title: "Evolua",
                  description: "Acompanhe seu progresso e desenvolva hábitos saudáveis",
                  icon: BarChart3,
                },
              ].map((item, index) => (
                <motion.div
                  key={item.step}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.2 }}
                  viewport={{ once: true }}
                  className="text-center"
                >
                  <div className="relative mb-6">
                    <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-blue-500 rounded-full flex items-center justify-center mx-auto mb-4">
                      <item.icon className="h-8 w-8 text-white" />
                    </div>
                    <div className="absolute -top-2 -right-2 w-8 h-8 bg-purple-600 rounded-full flex items-center justify-center text-white font-bold text-sm">
                      {item.step}
                    </div>
                  </div>
                  <h3 className="text-xl font-semibold text-white mb-3">{item.title}</h3>
                  <p className="text-gray-400">{item.description}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Testimonials Section */}
        <section id="depoimentos" className="py-16 px-4">
          <div className="container mx-auto max-w-7xl">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
              className="text-center mb-12"
            >
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">O que nossos usuários dizem</h2>
              <p className="text-gray-400 text-lg max-w-3xl mx-auto">
                Mais de 10.000 pessoas já transformaram suas vidas com a MindWave.AI
              </p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {testimonials.map((testimonial, index) => (
                <motion.div
                  key={testimonial.name}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  viewport={{ once: true }}
                >
                  <Card className="bg-gray-800/30 border-gray-700/50 h-full">
                    <CardContent className="p-6">
                      <div className="flex items-center mb-4">
                        {[...Array(testimonial.rating)].map((_, i) => (
                          <Star key={i} className="h-4 w-4 text-yellow-400 fill-current" />
                        ))}
                      </div>
                      <p className="text-gray-300 mb-6 italic">"{testimonial.text}"</p>
                      <div className="flex items-center">
                        <Avatar className="h-10 w-10 mr-3">
                          <AvatarImage src={testimonial.avatar || "/placeholder.svg"} alt={testimonial.name} />
                          <AvatarFallback className="bg-purple-600 text-white">
                            {testimonial.name
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="text-white font-medium">{testimonial.name}</p>
                          <p className="text-gray-400 text-sm">{testimonial.role}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Pricing Section */}
        <section id="precos" className="py-16 px-4 bg-gray-900/20">
          <div className="container mx-auto max-w-7xl">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
              className="text-center mb-12"
            >
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Planos que cabem no seu bolso</h2>
              <p className="text-gray-400 text-lg max-w-3xl mx-auto">
                Comece gratuitamente e evolua conforme suas necessidades
              </p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
              {[
                {
                  name: "Gratuito",
                  price: "R$ 0",
                  period: "/mês",
                  description: "Perfeito para começar sua jornada",
                  features: [
                    "3 conversas por dia",
                    "Módulo básico de mindfulness",
                    "Relatórios semanais",
                    "Suporte por email",
                  ],
                  cta: "Começar Grátis",
                  popular: false,
                },
                {
                  name: "Premium",
                  price: "R$ 29,90",
                  period: "/mês",
                  description: "Para quem quer resultados consistentes",
                  features: [
                    "Conversas ilimitadas",
                    "Todos os módulos",
                    "Relatórios detalhados",
                    "Suporte prioritário",
                    "Sessões em grupo",
                    "Backup na nuvem",
                  ],
                  cta: "Assinar Premium",
                  popular: true,
                },
                {
                  name: "Família",
                  price: "R$ 49,90",
                  period: "/mês",
                  description: "Cuidado para toda a família",
                  features: [
                    "Até 5 usuários",
                    "Painel familiar",
                    "Alertas de crise",
                    "Consultoria especializada",
                    "Workshops mensais",
                    "Suporte 24/7",
                  ],
                  cta: "Assinar Família",
                  popular: false,
                },
              ].map((plan, index) => (
                <motion.div
                  key={plan.name}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  viewport={{ once: true }}
                >
                  <Card
                    className={`relative h-full ${plan.popular ? "border-purple-500 bg-purple-500/5" : "bg-gray-800/30 border-gray-700/50"}`}
                  >
                    {plan.popular && (
                      <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                        <Badge className="bg-purple-600 text-white px-4 py-1">Mais Popular</Badge>
                      </div>
                    )}
                    <CardHeader className="text-center">
                      <CardTitle className="text-white text-2xl">{plan.name}</CardTitle>
                      <div className="mt-4">
                        <span className="text-4xl font-bold text-white">{plan.price}</span>
                        <span className="text-gray-400">{plan.period}</span>
                      </div>
                      <CardDescription className="text-gray-400 mt-2">{plan.description}</CardDescription>
                    </CardHeader>
                    <CardContent className="flex-1">
                      <ul className="space-y-3 mb-8">
                        {plan.features.map((feature) => (
                          <li key={feature} className="flex items-center text-gray-300">
                            <CheckCircle className="mr-3 h-4 w-4 text-green-400" />
                            {feature}
                          </li>
                        ))}
                      </ul>
                      <Button
                        className={`w-full ${plan.popular ? "bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700" : "bg-gray-700 hover:bg-gray-600 text-white"}`}
                        onClick={plan.name === "Gratuito" ? handleWhatsAppClick : undefined}
                        aria-label={`Selecionar plano ${plan.name}`}
                      >
                        {plan.cta}
                      </Button>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Final */}
        <section className="py-20 px-4 bg-gradient-to-r from-purple-900/20 to-blue-900/20">
          <div className="container mx-auto max-w-7xl text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
            >
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">Pronto para transformar sua vida?</h2>
              <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
                Junte-se a milhares de pessoas que já encontraram paz e bem-estar com a MindWave.AI
              </p>
              <Button
                size="lg"
                onClick={handleWhatsAppClick}
                className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-lg px-8 py-4"
                aria-label="Começar jornada de bem-estar no WhatsApp"
              >
                <MessageCircle className="mr-2 h-5 w-5" />
                Começar Agora no WhatsApp
              </Button>
            </motion.div>
          </div>
        </section>

        {/* Footer */}
        <footer className="bg-gray-900/50 border-t border-gray-800 py-12 px-4">
          <div className="container mx-auto max-w-7xl">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
              <div>
                <div className="flex items-center space-x-2 mb-4">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-r from-purple-500 to-blue-500 flex items-center justify-center">
                    <Heart className="h-4 w-4 text-white" />
                  </div>
                  <span className="text-xl font-bold text-white">MindWave.AI</span>
                </div>
                <p className="text-gray-400 mb-4">
                  Transformando vidas através da tecnologia empática e cuidado mental personalizado.
                </p>
                <div className="flex space-x-4">
                  <a href="#" className="text-gray-400 hover:text-white transition-colors" aria-label="Facebook">
                    <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.367-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                    </svg>
                  </a>
                  <a href="#" className="text-gray-400 hover:text-white transition-colors" aria-label="Instagram">
                    <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M12.017 0C5.396 0 .029 5.367.029 11.987c0 6.62 5.367 11.987 11.988 11.987c6.62 0 11.987-5.367 11.987-11.987C24.014 5.367 18.637.001 12.017.001zM8.449 16.988c-1.297 0-2.448-.49-3.323-1.297L3.323 17.49c.875.807 2.026 1.297 3.323 1.297 1.297 0 2.448-.49 3.323-1.297l-1.803-1.799c-.875.807-2.026 1.297-3.323 1.297z" />
                    </svg>
                  </a>
                </div>
              </div>

              <div>
                <h3 className="text-white font-semibold mb-4">Recursos</h3>
                <ul className="space-y-2">
                  <li>
                    <a href="#" className="text-gray-400 hover:text-white transition-colors">
                      Mindfulness
                    </a>
                  </li>
                  <li>
                    <a href="#" className="text-gray-400 hover:text-white transition-colors">
                      Detox Digital
                    </a>
                  </li>
                  <li>
                    <a href="#" className="text-gray-400 hover:text-white transition-colors">
                      Fitoterapia
                    </a>
                  </li>
                  <li>
                    <a href="#" className="text-gray-400 hover:text-white transition-colors">
                      Análise Emocional
                    </a>
                  </li>
                </ul>
              </div>

              <div>
                <h3 className="text-white font-semibold mb-4">Suporte</h3>
                <ul className="space-y-2">
                  <li>
                    <a href="#" className="text-gray-400 hover:text-white transition-colors">
                      Central de Ajuda
                    </a>
                  </li>
                  <li>
                    <a href="#" className="text-gray-400 hover:text-white transition-colors">
                      Contato
                    </a>
                  </li>
                  <li>
                    <a href="#" className="text-gray-400 hover:text-white transition-colors">
                      WhatsApp
                    </a>
                  </li>
                  <li>
                    <a href="#" className="text-gray-400 hover:text-white transition-colors">
                      Status
                    </a>
                  </li>
                </ul>
              </div>

              <div>
                <h3 className="text-white font-semibold mb-4">Legal</h3>
                <ul className="space-y-2">
                  <li>
                    <a href="#" className="text-gray-400 hover:text-white transition-colors">
                      Privacidade
                    </a>
                  </li>
                  <li>
                    <a href="#" className="text-gray-400 hover:text-white transition-colors">
                      Termos
                    </a>
                  </li>
                  <li>
                    <a href="#" className="text-gray-400 hover:text-white transition-colors">
                      LGPD
                    </a>
                  </li>
                  <li>
                    <a href="#" className="text-gray-400 hover:text-white transition-colors">
                      Cookies
                    </a>
                  </li>
                </ul>
              </div>
            </div>

            <div className="border-t border-gray-800 mt-8 pt-8 text-center">
              <p className="text-gray-400">
                © 2024 MindWave.AI. Todos os direitos reservados. Feito com ❤️ para seu bem-estar.
              </p>
            </div>
          </div>
        </footer>
      </main>
    </div>
  )
}
