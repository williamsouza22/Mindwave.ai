"use client"

import { useState } from "react"
import { SidebarProvider, SidebarInset, SidebarTrigger } from "@/components/ui/sidebar"
import { UserSidebar } from "@/components/dashboard/user-sidebar"
import { ModernDashboardHeader } from "@/components/dashboard/modern-dashboard-header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Play, Pause, Timer, Target, Zap } from "lucide-react"
import { motion } from "framer-motion"
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb"

const exercises = [
  {
    id: "quick-cardio",
    name: "Cardio Rápido",
    description: "5 minutos de exercícios cardiovasculares para energizar",
    duration: 5,
    difficulty: "Fácil",
    calories: 25,
    exercises: ["Polichinelos", "Corrida no lugar", "Burpees modificados"],
    color: "from-red-500 to-pink-500",
    icon: "❤️",
  },
  {
    id: "desk-stretch",
    name: "Alongamento Mesa",
    description: "Exercícios para quem trabalha muito tempo sentado",
    duration: 10,
    difficulty: "Muito Fácil",
    calories: 15,
    exercises: ["Rotação de pescoço", "Alongamento de braços", "Torção de tronco"],
    color: "from-green-500 to-emerald-500",
    icon: "🧘‍♀️",
  },
  {
    id: "strength-basic",
    name: "Força Básica",
    description: "Exercícios de fortalecimento sem equipamentos",
    duration: 15,
    difficulty: "Médio",
    calories: 60,
    exercises: ["Flexões", "Agachamentos", "Prancha"],
    color: "from-blue-500 to-cyan-500",
    icon: "💪",
  },
  {
    id: "yoga-flow",
    name: "Yoga Flow",
    description: "Sequência de yoga para relaxamento e flexibilidade",
    duration: 20,
    difficulty: "Fácil",
    calories: 40,
    exercises: ["Saudação ao sol", "Postura do guerreiro", "Postura da criança"],
    color: "from-purple-500 to-indigo-500",
    icon: "🕉️",
  },
  {
    id: "hiit-beginner",
    name: "HIIT Iniciante",
    description: "Treino intervalado de alta intensidade para iniciantes",
    duration: 12,
    difficulty: "Médio",
    calories: 80,
    exercises: ["Mountain climbers", "Squat jumps", "High knees"],
    color: "from-orange-500 to-yellow-500",
    icon: "⚡",
  },
  {
    id: "mindful-movement",
    name: "Movimento Consciente",
    description: "Exercícios lentos focados na conexão mente-corpo",
    duration: 18,
    difficulty: "Fácil",
    calories: 30,
    exercises: ["Tai chi básico", "Respiração com movimento", "Meditação ativa"],
    color: "from-teal-500 to-green-500",
    icon: "🌸",
  },
]

export default function ExercisesPage() {
  const [selectedExercise, setSelectedExercise] = useState(exercises[0])
  const [isActive, setIsActive] = useState(false)
  const [timeLeft, setTimeLeft] = useState(selectedExercise.duration * 60)

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Muito Fácil":
        return "bg-green-900/50 text-green-300 border-green-800"
      case "Fácil":
        return "bg-blue-900/50 text-blue-300 border-blue-800"
      case "Médio":
        return "bg-yellow-900/50 text-yellow-300 border-yellow-800"
      case "Difícil":
        return "bg-red-900/50 text-red-300 border-red-800"
      default:
        return "bg-gray-900/50 text-gray-300 border-gray-800"
    }
  }

  return (
    <SidebarProvider>
      <UserSidebar />
      <SidebarInset className="flex flex-col min-h-screen">
        <header className="flex h-16 shrink-0 items-center gap-2 border-b border-gray-800 bg-[#1A2332] px-4">
          <SidebarTrigger className="-ml-1 text-gray-300 hover:text-white" />
          <Separator orientation="vertical" className="mr-2 h-4 bg-gray-700" />
          <Breadcrumb>
            <BreadcrumbList>
              <BreadcrumbItem className="hidden md:block">
                <BreadcrumbLink href="/dashboard" className="text-gray-400 hover:text-white">
                  Dashboard
                </BreadcrumbLink>
              </BreadcrumbItem>
              <BreadcrumbSeparator className="hidden md:block text-gray-600" />
              <BreadcrumbItem>
                <BreadcrumbPage className="text-white">Exercícios</BreadcrumbPage>
              </BreadcrumbItem>
            </BreadcrumbList>
          </Breadcrumb>
          <div className="ml-auto">
            <ModernDashboardHeader />
          </div>
        </header>

        <main className="flex-1 bg-[#0B1426] p-6">
          <div className="max-w-full mx-auto">
            <div className="mb-6">
              <h1 className="text-3xl font-bold text-white mb-2">Exercícios</h1>
              <p className="text-gray-400">Mova-se para melhorar seu bem-estar físico e mental</p>
            </div>

            <div className="grid grid-cols-1 xl:grid-cols-4 gap-6 w-full">
              {/* Exercise Selection */}
              <div className="xl:col-span-1 space-y-4">
                <h2 className="text-xl font-semibold text-white mb-4">Escolha um Exercício</h2>
                {exercises.map((exercise) => (
                  <Card
                    key={exercise.id}
                    className={`cursor-pointer transition-all duration-300 ${
                      selectedExercise.id === exercise.id
                        ? `bg-gradient-to-r ${exercise.color} border-transparent`
                        : "bg-[#1A2332] border-gray-800 hover:border-gray-600"
                    }`}
                    onClick={() => {
                      setSelectedExercise(exercise)
                      setTimeLeft(exercise.duration * 60)
                      setIsActive(false)
                    }}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-center space-x-3 mb-2">
                        <span className="text-2xl">{exercise.icon}</span>
                        <div className="flex-1">
                          <h3 className="font-semibold text-white text-sm">{exercise.name}</h3>
                          <p className="text-xs text-gray-300">{exercise.description}</p>
                        </div>
                      </div>
                      <div className="flex items-center justify-between text-xs text-gray-400">
                        <div className="flex items-center space-x-1">
                          <Timer className="h-3 w-3" />
                          <span>{exercise.duration} min</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Zap className="h-3 w-3" />
                          <span>{exercise.calories} cal</span>
                        </div>
                      </div>
                      <Badge variant="secondary" className={`mt-2 text-xs ${getDifficultyColor(exercise.difficulty)}`}>
                        {exercise.difficulty}
                      </Badge>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Main Exercise Interface */}
              <div className="xl:col-span-3">
                <Card className="bg-[#1A2332] border-gray-800 h-full">
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <span className="text-3xl">{selectedExercise.icon}</span>
                        <div>
                          <span className="text-white">{selectedExercise.name}</span>
                          <p className="text-sm text-gray-400 font-normal">{selectedExercise.description}</p>
                        </div>
                      </div>
                      <Badge variant="secondary" className={getDifficultyColor(selectedExercise.difficulty)}>
                        {selectedExercise.difficulty}
                      </Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="flex flex-col items-center justify-center space-y-8 p-8">
                    {/* Exercise Timer */}
                    <div className="text-center space-y-4">
                      <motion.div
                        animate={{
                          scale: isActive ? [1, 1.05, 1] : 1,
                          opacity: isActive ? [0.8, 1, 0.8] : 1,
                        }}
                        transition={{
                          duration: 2,
                          repeat: isActive ? Number.POSITIVE_INFINITY : 0,
                          ease: "easeInOut",
                        }}
                        className={`w-48 h-48 rounded-full bg-gradient-to-r ${selectedExercise.color} flex items-center justify-center shadow-2xl`}
                      >
                        <div className="text-center">
                          <div className="text-4xl font-bold text-white mb-2">{formatTime(timeLeft)}</div>
                          <p className="text-white text-sm">{!isActive ? "Pronto para começar?" : "Continue assim!"}</p>
                        </div>
                      </motion.div>

                      {/* Exercise Stats */}
                      <div className="grid grid-cols-3 gap-4 text-center">
                        <div>
                          <div className="text-2xl font-bold text-white">{selectedExercise.duration}</div>
                          <div className="text-xs text-gray-400">Minutos</div>
                        </div>
                        <div>
                          <div className="text-2xl font-bold text-white">{selectedExercise.calories}</div>
                          <div className="text-xs text-gray-400">Calorias</div>
                        </div>
                        <div>
                          <div className="text-2xl font-bold text-white">{selectedExercise.exercises.length}</div>
                          <div className="text-xs text-gray-400">Exercícios</div>
                        </div>
                      </div>
                    </div>

                    {/* Controls */}
                    <div className="flex items-center space-x-4">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setTimeLeft(selectedExercise.duration * 60)
                          setIsActive(false)
                        }}
                        className="bg-transparent border-gray-700 text-gray-300 hover:bg-gray-800"
                      >
                        Reiniciar
                      </Button>

                      <Button
                        onClick={() => setIsActive(!isActive)}
                        className={`bg-gradient-to-r ${selectedExercise.color} hover:opacity-90 px-8`}
                      >
                        {isActive ? <Pause className="h-4 w-4 mr-2" /> : <Play className="h-4 w-4 mr-2" />}
                        {isActive ? "Pausar" : "Iniciar"}
                      </Button>
                    </div>

                    {/* Exercise List */}
                    <div className="w-full max-w-md">
                      <h4 className="text-sm font-semibold text-white mb-3">Exercícios inclusos:</h4>
                      <div className="space-y-2">
                        {selectedExercise.exercises.map((exercise, index) => (
                          <div
                            key={index}
                            className="flex items-center space-x-3 p-2 bg-[#0F1B2A] rounded border border-gray-700"
                          >
                            <div className="w-6 h-6 rounded-full bg-gradient-to-r from-gray-600 to-gray-700 flex items-center justify-center">
                              <span className="text-xs text-white font-bold">{index + 1}</span>
                            </div>
                            <span className="text-sm text-gray-300">{exercise}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Progress */}
                    <div className="w-full max-w-md space-y-2">
                      <div className="flex justify-between text-xs text-gray-400">
                        <span>Progresso da sessão</span>
                        <span>
                          {Math.round(
                            ((selectedExercise.duration * 60 - timeLeft) / (selectedExercise.duration * 60)) * 100,
                          )}
                          %
                        </span>
                      </div>
                      <div className="w-full bg-gray-700 rounded-full h-2">
                        <div
                          className={`h-2 rounded-full bg-gradient-to-r ${selectedExercise.color} transition-all duration-300`}
                          style={{
                            width: `${((selectedExercise.duration * 60 - timeLeft) / (selectedExercise.duration * 60)) * 100}%`,
                          }}
                        ></div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* Weekly Goals */}
            <div className="mt-8">
              <Card className="bg-[#1A2332] border-gray-800">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Target className="h-5 w-5 text-green-400" />
                    <span className="text-white">Metas Semanais</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="text-center">
                      <div className="text-3xl font-bold text-white mb-2">3/5</div>
                      <div className="text-sm text-gray-400 mb-2">Sessões esta semana</div>
                      <div className="w-full bg-gray-700 rounded-full h-2">
                        <div className="w-3/5 h-2 bg-gradient-to-r from-green-500 to-emerald-500 rounded-full"></div>
                      </div>
                    </div>
                    <div className="text-center">
                      <div className="text-3xl font-bold text-white mb-2">180</div>
                      <div className="text-sm text-gray-400 mb-2">Calorias queimadas</div>
                      <div className="w-full bg-gray-700 rounded-full h-2">
                        <div className="w-4/5 h-2 bg-gradient-to-r from-orange-500 to-red-500 rounded-full"></div>
                      </div>
                    </div>
                    <div className="text-center">
                      <div className="text-3xl font-bold text-white mb-2">45</div>
                      <div className="text-sm text-gray-400 mb-2">Minutos ativos</div>
                      <div className="w-full bg-gray-700 rounded-full h-2">
                        <div className="w-2/3 h-2 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full"></div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </main>
      </SidebarInset>
    </SidebarProvider>
  )
}
