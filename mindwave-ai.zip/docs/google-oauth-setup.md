# Configuração do Google OAuth para MindWave.AI

## 1. Criar Projeto no Google Cloud Console

1. Acesse [Google Cloud Console](https://console.cloud.google.com/)
2. Crie um novo projeto ou selecione um existente
3. Ative a **Google+ API** e **Google Identity API**

## 2. Configurar OAuth 2.0

1. Vá para **APIs & Services** > **Credentials**
2. Clique em **Create Credentials** > **OAuth 2.0 Client IDs**
3. Configure:
   - **Application type**: Web application
   - **Name**: MindWave.AI
   - **Authorized JavaScript origins**:
     - `http://localhost:3000` (desenvolvimento)
     - `https://yourdomain.com` (produção)
   - **Authorized redirect URIs**:
     - `http://localhost:3000/auth/callback` (desenvolvimento)
     - `https://yourdomain.com/auth/callback` (produção)

## 3. Configurar no Supabase

1. Acesse seu [Supabase Dashboard](https://supabase.com/dashboard)
2. Vá para **Authentication** > **Providers**
3. Ative o **Google Provider**
4. Adicione:
   - **Client ID**: Copie do Google Cloud Console
   - **Client Secret**: Copie do Google Cloud Console
5. Salve as configurações

## 4. Configurar Variáveis de Ambiente

Crie um arquivo `.env.local` na raiz do projeto:

\`\`\`env
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
NEXT_PUBLIC_APP_URL=http://localhost:3000
\`\`\`

## 5. Configurar Domínios Autorizados

No Supabase Dashboard:
1. Vá para **Authentication** > **URL Configuration**
2. Adicione seus domínios em **Site URL**:
   - `http://localhost:3000` (desenvolvimento)
   - `https://yourdomain.com` (produção)

## 6. Testar a Configuração

1. Execute o projeto: `npm run dev`
2. Acesse `/auth`
3. Clique em "Entrar com Google"
4. Verifique se o redirecionamento funciona corretamente

## 7. Configurações de Produção

Para produção, certifique-se de:
- Atualizar as URLs autorizadas no Google Cloud Console
- Configurar o domínio correto no Supabase
- Atualizar as variáveis de ambiente

## Troubleshooting

### Erro: "redirect_uri_mismatch"
- Verifique se as URLs de redirecionamento estão corretas no Google Cloud Console
- Certifique-se de que não há barras extras no final das URLs

### Erro: "invalid_client"
- Verifique se o Client ID e Client Secret estão corretos no Supabase
- Confirme se as credenciais não expiraram

### Erro: "access_denied"
- O usuário cancelou a autenticação
- Verifique se as permissões solicitadas são apropriadas

## Recursos Adicionais

- [Documentação Supabase Auth](https://supabase.com/docs/guides/auth)
- [Google OAuth 2.0 Documentation](https://developers.google.com/identity/protocols/oauth2)
- [Next.js Authentication](https://nextjs.org/docs/authentication)
