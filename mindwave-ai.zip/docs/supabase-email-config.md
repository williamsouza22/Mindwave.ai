# Configuração de Email no Supabase

## 1. Configuração de URLs

No painel do Supabase, vá para **Authentication > URL Configuration**:

### Site URL
\`\`\`
http://localhost:3000
\`\`\`

### Redirect URLs
Adicione as seguintes URLs:
\`\`\`
http://localhost:3000/auth/callback
http://localhost:3000/auth/confirm
http://localhost:3000/auth/confirmed
\`\`\`

## 2. Template de Email de Confirmação

Vá para **Authentication > Email Templates > Confirm signup**:

### Subject
\`\`\`
Confirme seu email - MindWave.AI
\`\`\`

### Body (HTML)
\`\`\`html
<h2>Confirme seu email</h2>
<p>Obrigado por se cadastrar no MindWave.AI!</p>
<p>Clique no link abaixo para confirmar seu email:</p>
<p><a href="{{ .SiteURL }}/auth/confirm?token_hash={{ .TokenHash }}&type=email">Confirmar Email</a></p>
<p>Se você não criou uma conta, pode ignorar este email.</p>
\`\`\`

## 3. Configuração RLS (Row Level Security)

Execute no SQL Editor:

\`\`\`sql
-- Habilitar RLS na tabela profiles
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

-- Política para usuários verem apenas seu próprio perfil
CREATE POLICY "Users can view own profile" ON profiles
  FOR SELECT USING (auth.uid() = id);

-- Política para usuários atualizarem apenas seu próprio perfil
CREATE POLICY "Users can update own profile" ON profiles
  FOR UPDATE USING (auth.uid() = id);

-- Política para inserir perfil após signup
CREATE POLICY "Users can insert own profile" ON profiles
  FOR INSERT WITH CHECK (auth.uid() = id);
\`\`\`

## 4. Variáveis de Ambiente

Certifique-se de ter as seguintes variáveis no `.env.local`:

\`\`\`env
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key
\`\`\`

## 5. Teste do Fluxo

1. Acesse `/auth`
2. Clique em "Cadastrar"
3. Preencha os dados e envie
4. Verifique o email
5. Clique no link de confirmação
6. Deve ser redirecionado para `/auth/confirmed`
7. Depois para `/onboarding` ou `/dashboard`
