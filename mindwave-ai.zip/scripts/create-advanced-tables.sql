-- Create notifications table
create table public.notifications (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references public.users(id) on delete cascade not null,
  type text check (type in ('info', 'success', 'warning', 'error', 'reminder')) not null,
  title text not null,
  message text not null,
  read boolean default false,
  action_url text,
  action_label text,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Create analytics_events table
create table public.analytics_events (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references public.users(id) on delete cascade not null,
  event_name text not null,
  properties jsonb default '{}',
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Create user_settings table
create table public.user_settings (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references public.users(id) on delete cascade not null,
  setting_key text not null,
  setting_value jsonb not null,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  updated_at timestamp with time zone default timezone('utc'::text, now()) not null,
  unique(user_id, setting_key)
);

-- Create sync_status table
create table public.sync_status (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references public.users(id) on delete cascade not null,
  device_id text not null,
  last_sync timestamp with time zone default timezone('utc'::text, now()) not null,
  sync_data jsonb default '{}',
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  unique(user_id, device_id)
);

-- Add RLS policies for new tables
alter table public.notifications enable row level security;
alter table public.analytics_events enable row level security;
alter table public.user_settings enable row level security;
alter table public.sync_status enable row level security;

-- Notifications policies
create policy "Users can view own notifications" on public.notifications
  for select using (auth.uid() = user_id);

create policy "Users can update own notifications" on public.notifications
  for update using (auth.uid() = user_id);

create policy "System can insert notifications" on public.notifications
  for insert with check (true);

-- Analytics policies
create policy "Users can view own analytics" on public.analytics_events
  for select using (auth.uid() = user_id);

create policy "Users can insert own analytics" on public.analytics_events
  for insert with check (auth.uid() = user_id);

-- User settings policies
create policy "Users can manage own settings" on public.user_settings
  for all using (auth.uid() = user_id);

-- Sync status policies
create policy "Users can manage own sync status" on public.sync_status
  for all using (auth.uid() = user_id);

-- Create indexes for performance
create index idx_notifications_user_id on public.notifications(user_id);
create index idx_notifications_created_at on public.notifications(created_at desc);
create index idx_analytics_events_user_id on public.analytics_events(user_id);
create index idx_analytics_events_created_at on public.analytics_events(created_at desc);
create index idx_user_settings_user_id on public.user_settings(user_id);
create index idx_sync_status_user_id on public.sync_status(user_id);

-- Add updated_at trigger for user_settings
create trigger handle_user_settings_updated_at
  before update on public.user_settings
  for each row execute procedure public.handle_updated_at();
