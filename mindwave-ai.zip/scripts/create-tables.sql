-- Enable RLS (Row Level Security)
alter table auth.users enable row level security;

-- Create users table
create table public.users (
  id uuid references auth.users on delete cascade primary key,
  email text unique not null,
  name text,
  avatar_url text,
  plan text check (plan in ('free', 'premium')) default 'free',
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  updated_at timestamp with time zone default timezone('utc'::text, now()) not null,
  last_login timestamp with time zone,
  onboarding_completed boolean default false
);

-- Create mood_entries table
create table public.mood_entries (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references public.users(id) on delete cascade not null,
  mood_score integer check (mood_score >= 1 and mood_score <= 10) not null,
  note text,
  tags text[],
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Create chat_messages table
create table public.chat_messages (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references public.users(id) on delete cascade not null,
  content text not null,
  sender text check (sender in ('user', 'ai')) not null,
  message_type text check (message_type in ('text', 'audio', 'image')) default 'text',
  metadata jsonb,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Set up Row Level Security (RLS)
-- Users can only see their own data
create policy "Users can view own profile" on public.users
  for select using (auth.uid() = id);

create policy "Users can update own profile" on public.users
  for update using (auth.uid() = id);

-- Mood entries policies
create policy "Users can view own mood entries" on public.mood_entries
  for select using (auth.uid() = user_id);

create policy "Users can insert own mood entries" on public.mood_entries
  for insert with check (auth.uid() = user_id);

create policy "Users can update own mood entries" on public.mood_entries
  for update using (auth.uid() = user_id);

create policy "Users can delete own mood entries" on public.mood_entries
  for delete using (auth.uid() = user_id);

-- Chat messages policies
create policy "Users can view own chat messages" on public.chat_messages
  for select using (auth.uid() = user_id);

create policy "Users can insert own chat messages" on public.chat_messages
  for insert with check (auth.uid() = user_id);

-- Enable RLS on all tables
alter table public.users enable row level security;
alter table public.mood_entries enable row level security;
alter table public.chat_messages enable row level security;

-- Create function to handle user creation
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.users (id, email, name, avatar_url)
  values (
    new.id,
    new.email,
    new.raw_user_meta_data->>'name',
    new.raw_user_meta_data->>'avatar_url'
  );
  return new;
end;
$$ language plpgsql security definer;

-- Create trigger for new user creation
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- Create function to update updated_at timestamp
create or replace function public.handle_updated_at()
returns trigger as $$
begin
  new.updated_at = timezone('utc'::text, now());
  return new;
end;
$$ language plpgsql;

-- Create trigger for updated_at
create trigger handle_users_updated_at
  before update on public.users
  for each row execute procedure public.handle_updated_at();
