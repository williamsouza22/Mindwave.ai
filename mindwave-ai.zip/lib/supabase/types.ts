export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[]

export interface Database {
  public: {
    Tables: {
      users: {
        Row: {
          id: string
          email: string
          name: string | null
          avatar_url: string | null
          plan: "free" | "premium"
          created_at: string
          updated_at: string
          last_login: string | null
          onboarding_completed: boolean
        }
        Insert: {
          id: string
          email: string
          name?: string | null
          avatar_url?: string | null
          plan?: "free" | "premium"
          created_at?: string
          updated_at?: string
          last_login?: string | null
          onboarding_completed?: boolean
        }
        Update: {
          id?: string
          email?: string
          name?: string | null
          avatar_url?: string | null
          plan?: "free" | "premium"
          created_at?: string
          updated_at?: string
          last_login?: string | null
          onboarding_completed?: boolean
        }
      }
      mood_entries: {
        Row: {
          id: string
          user_id: string
          mood_score: number
          note: string | null
          tags: string[] | null
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          mood_score: number
          note?: string | null
          tags?: string[] | null
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          mood_score?: number
          note?: string | null
          tags?: string[] | null
          created_at?: string
        }
      }
      chat_messages: {
        Row: {
          id: string
          user_id: string
          content: string
          sender: "user" | "ai"
          message_type: "text" | "audio" | "image"
          metadata: Json | null
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          content: string
          sender: "user" | "ai"
          message_type?: "text" | "audio" | "image"
          metadata?: Json | null
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          content?: string
          sender?: "user" | "ai"
          message_type?: "text" | "audio" | "image"
          metadata?: Json | null
          created_at?: string
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
  }
}
