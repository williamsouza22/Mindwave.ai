export function getAsaasConfig(environment: "sandbox" | "production" = "sandbox") {
  // Primeiro tenta a chave específica do ambiente, depois a genérica
  let apiKey = ""

  if (environment === "sandbox") {
    apiKey = process.env.ASAAS_SANDBOX_API_KEY || process.env.ASAAS_API_KEY || ""
  } else {
    apiKey = process.env.ASAAS_API_KEY || ""
  }

  // Se a chave contém _hmlg_, força sandbox
  const isSandboxKey = apiKey.includes("_hmlg_")
  const finalEnvironment = isSandboxKey ? "sandbox" : environment

  return {
    baseUrl: finalEnvironment === "sandbox" ? "https://sandbox.asaas.com/api/v3" : "https://www.asaas.com/api/v3",
    apiKey: apiKey,
    environment: finalEnvironment,
  }
}

export function generateValidCpf(): string {
  // Gera um CPF válido para testes
  const cpfBase = Math.floor(Math.random() * 999999999)
    .toString()
    .padStart(9, "0")

  // Calcula primeiro dígito verificador
  let sum = 0
  for (let i = 0; i < 9; i++) {
    sum += Number.parseInt(cpfBase[i]) * (10 - i)
  }
  const firstDigit = ((sum * 10) % 11) % 10

  // Calcula segundo dígito verificador
  sum = 0
  for (let i = 0; i < 9; i++) {
    sum += Number.parseInt(cpfBase[i]) * (11 - i)
  }
  sum += firstDigit * 2
  const secondDigit = ((sum * 10) % 11) % 10

  return `${cpfBase}${firstDigit}${secondDigit}`
}

export function generateValidMobilePhone(): string {
  // Gera um número de celular válido brasileiro
  const ddds = ["11", "21", "31", "41", "51", "61", "71", "81", "85", "91"]
  const ddd = ddds[Math.floor(Math.random() * ddds.length)]

  // Número com 9 dígitos (formato atual brasileiro)
  const nineDigits = Math.floor(100000000 + Math.random() * 899999999)
    .toString()
    .padStart(9, "0")

  return `${ddd}9${nineDigits.substring(1)}` // DDD + 9 + 8 dígitos
}

export function formatCpf(cpf: string): string {
  return cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, "$1.$2.$3-$4")
}

export function formatPhone(phone: string): string {
  if (phone.length === 11) {
    return phone.replace(/(\d{2})(\d{5})(\d{4})/, "($1) $2-$3")
  }
  return phone
}
