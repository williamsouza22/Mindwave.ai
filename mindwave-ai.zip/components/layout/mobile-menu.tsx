"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { useAuth } from "@/lib/auth/auth-context"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  Brain,
  MessageCircle,
  Heart,
  Leaf,
  Dumbbell,
  Calendar,
  BarChart3,
  Settings,
  Crown,
  Smartphone,
  Wind,
  BookOpen,
  Headphones,
  LogOut,
  X,
} from "lucide-react"

interface MobileMenuProps {
  isOpen: boolean
  onClose: () => void
}

const menuItems = [
  {
    title: "Dashboard",
    href: "/dashboard",
    icon: BarChart3,
  },
  {
    title: "Chat IA",
    href: "/chat",
    icon: MessageCircle,
  },
  {
    title: "Mapa Emocional",
    href: "/emotional-map",
    icon: Heart,
  },
  {
    title: "Detox Digital",
    href: "/digital-detox",
    icon: Smartphone,
    premium: true,
  },
  {
    title: "Fitoterapia",
    href: "/fitotherapy",
    icon: Leaf,
    premium: true,
  },
  {
    title: "Exercícios",
    href: "/exercises",
    icon: Dumbbell,
  },
  {
    title: "Respiração",
    href: "/breathing",
    icon: Wind,
  },
  {
    title: "Sons da Natureza",
    href: "/nature-sounds",
    icon: Headphones,
  },
  {
    title: "Diário",
    href: "/journal",
    icon: BookOpen,
  },
  {
    title: "Calendário",
    href: "/calendar",
    icon: Calendar,
  },
]

export function MobileMenu({ isOpen, onClose }: MobileMenuProps) {
  const pathname = usePathname()
  const { user, signOut } = useAuth()

  const userPlan = user?.user_metadata?.plan || "free"
  const isPremium = userPlan === "premium" || userPlan === "family"

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 md:hidden">
      {/* Backdrop */}
      <div className="fixed inset-0 bg-black/50" onClick={onClose} />

      {/* Menu */}
      <div className="fixed left-0 top-0 h-full w-80 bg-slate-800/95 backdrop-blur-sm border-r border-purple-500/20 flex flex-col">
        {/* Header */}
        <div className="p-4 border-b border-purple-500/20">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Brain className="h-8 w-8 text-purple-400" />
              <span className="text-xl font-bold text-white">MindWave.AI</span>
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-lg bg-purple-600/20 text-purple-300 hover:bg-purple-600/30 transition-colors"
              aria-label="Fechar menu"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* User Profile */}
        <div className="p-4 border-b border-purple-500/20">
          <div className="flex items-center space-x-3">
            <Avatar className="h-12 w-12">
              <AvatarImage src={user?.user_metadata?.avatar_url || "/placeholder.svg"} />
              <AvatarFallback className="bg-purple-600 text-white">
                {user?.user_metadata?.name?.charAt(0) || user?.email?.charAt(0) || "U"}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-white truncate">{user?.user_metadata?.name || "Usuário"}</p>
              <Badge
                variant={isPremium ? "default" : "secondary"}
                className={isPremium ? "bg-gradient-to-r from-yellow-400 to-orange-500 text-black" : ""}
              >
                {isPremium && <Crown className="h-3 w-3 mr-1" />}
                {userPlan === "premium" ? "Premium" : userPlan === "family" ? "Família" : "Gratuito"}
              </Badge>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
          {menuItems.map((item) => {
            const Icon = item.icon
            const isActive = pathname === item.href
            const needsPremium = item.premium && !isPremium

            return (
              <Link
                key={item.href}
                href={needsPremium ? "/pricing" : item.href}
                onClick={onClose}
                className={`
                  flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors
                  ${isActive ? "bg-purple-600 text-white" : "text-gray-300 hover:bg-purple-600/20 hover:text-white"}
                  ${needsPremium ? "opacity-60" : ""}
                `}
              >
                <Icon className={`h-5 w-5 ${needsPremium ? "text-yellow-400" : ""}`} />
                <span className="text-sm font-medium">{item.title}</span>
                {needsPremium && <Crown className="h-4 w-4 text-yellow-400 ml-auto" />}
              </Link>
            )
          })}
        </nav>

        {/* Upgrade CTA */}
        {!isPremium && (
          <div className="p-4 border-t border-purple-500/20">
            <div className="bg-gradient-to-r from-purple-600 to-pink-600 rounded-lg p-4 text-center">
              <Crown className="h-8 w-8 text-yellow-300 mx-auto mb-2" />
              <h3 className="text-sm font-bold text-white mb-1">Upgrade para Premium</h3>
              <p className="text-xs text-purple-100 mb-3">Desbloqueie todos os recursos</p>
              <Button asChild size="sm" className="w-full bg-white text-purple-600 hover:bg-gray-100" onClick={onClose}>
                <Link href="/pricing">Assinar Agora</Link>
              </Button>
            </div>
          </div>
        )}

        {/* Settings & Logout */}
        <div className="p-4 border-t border-purple-500/20 space-y-2">
          <Link
            href="/settings"
            onClick={onClose}
            className={`
              flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors
              ${
                pathname === "/settings"
                  ? "bg-purple-600 text-white"
                  : "text-gray-300 hover:bg-purple-600/20 hover:text-white"
              }
            `}
          >
            <Settings className="h-5 w-5" />
            <span className="text-sm">Configurações</span>
          </Link>

          <button
            onClick={() => {
              signOut()
              onClose()
            }}
            className="flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors text-gray-300 hover:bg-red-600/20 hover:text-red-300 w-full"
          >
            <LogOut className="h-5 w-5" />
            <span className="text-sm">Sair</span>
          </button>
        </div>
      </div>
    </div>
  )
}
