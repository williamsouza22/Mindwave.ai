"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { usePathname } from "next/navigation"
import { Sidebar } from "./sidebar"
import { MobileMenu } from "./mobile-menu"
import { useAuth } from "@/lib/auth/auth-context"
import { AnalyticsProvider } from "@/components/analytics/analytics-provider"

interface GlobalLayoutProps {
  children: React.ReactNode
}

export function GlobalLayout({ children }: GlobalLayoutProps) {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [isMobile, setIsMobile] = useState(false)
  const pathname = usePathname()
  const { user } = useAuth()

  // Check if current page should show sidebar
  const showSidebar = user && !["/", "/auth", "/signup", "/login"].includes(pathname)

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768)
      if (window.innerWidth >= 768) {
        setSidebarOpen(false)
      }
    }

    checkMobile()
    window.addEventListener("resize", checkMobile)
    return () => window.removeEventListener("resize", checkMobile)
  }, [])

  // Close mobile menu when route changes
  useEffect(() => {
    setSidebarOpen(false)
  }, [pathname])

  if (!showSidebar) {
    return (
      <AnalyticsProvider>
        <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">{children}</div>
      </AnalyticsProvider>
    )
  }

  return (
    <AnalyticsProvider>
      <div className="flex h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
        {/* Desktop Sidebar */}
        {!isMobile && (
          <div className="w-60 flex-shrink-0">
            <Sidebar />
          </div>
        )}

        {/* Mobile Menu */}
        {isMobile && <MobileMenu isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />}

        {/* Main Content */}
        <div className="flex-1 flex flex-col min-w-0">
          {/* Mobile Header */}
          {isMobile && (
            <header className="bg-slate-800/50 backdrop-blur-sm border-b border-purple-500/20 p-4">
              <div className="flex items-center justify-between">
                <button
                  onClick={() => setSidebarOpen(true)}
                  className="p-2 rounded-lg bg-purple-600/20 text-purple-300 hover:bg-purple-600/30 transition-colors"
                  aria-label="Abrir menu"
                >
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                  </svg>
                </button>
                <h1 className="text-xl font-bold text-white">MindWave.AI</h1>
                <div className="w-10" /> {/* Spacer */}
              </div>
            </header>
          )}

          {/* Page Content */}
          <main className="flex-1 overflow-auto">
            <div className="p-6">{children}</div>
          </main>
        </div>

        {/* Mobile Overlay */}
        {isMobile && sidebarOpen && (
          <div className="fixed inset-0 bg-black/50 z-40" onClick={() => setSidebarOpen(false)} />
        )}
      </div>
    </AnalyticsProvider>
  )
}
