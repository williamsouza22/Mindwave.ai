"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { useAuth } from "@/lib/auth/auth-context"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  Brain,
  MessageCircle,
  Heart,
  Leaf,
  Dumbbell,
  Calendar,
  BarChart3,
  Settings,
  Crown,
  Smartphone,
  Wind,
  BookOpen,
  Headphones,
  LogOut,
} from "lucide-react"

const menuItems = [
  {
    title: "Dashboard",
    href: "/dashboard",
    icon: BarChart3,
    description: "Visão geral do seu progresso",
  },
  {
    title: "Chat IA",
    href: "/chat",
    icon: MessageCircle,
    description: "Converse com nossa IA empática",
  },
  {
    title: "Mapa Emocional",
    href: "/emotional-map",
    icon: Heart,
    description: "Visualize suas emoções",
  },
  {
    title: "Detox Digital",
    href: "/digital-detox",
    icon: Smartphone,
    description: "Reduza o vício em tecnologia",
    premium: true,
  },
  {
    title: "Fitoterapia",
    href: "/fitotherapy",
    icon: Leaf,
    description: "Plantas medicinais para bem-estar",
    premium: true,
  },
  {
    title: "Exercícios",
    href: "/exercises",
    icon: Dumbbell,
    description: "Atividades físicas personalizadas",
  },
  {
    title: "Respiração",
    href: "/breathing",
    icon: Wind,
    description: "Técnicas de respiração guiada",
  },
  {
    title: "Sons da Natureza",
    href: "/nature-sounds",
    icon: Headphones,
    description: "Relaxe com sons naturais",
  },
  {
    title: "Diário",
    href: "/journal",
    icon: BookOpen,
    description: "Registre seus pensamentos",
  },
  {
    title: "Calendário",
    href: "/calendar",
    icon: Calendar,
    description: "Organize sua rotina de bem-estar",
  },
]

export function Sidebar() {
  const pathname = usePathname()
  const { user, signOut } = useAuth()
  const [isCollapsed, setIsCollapsed] = useState(false)

  const userPlan = user?.user_metadata?.plan || "free"
  const isPremium = userPlan === "premium" || userPlan === "family"

  return (
    <div
      className={`h-full bg-slate-800/50 backdrop-blur-sm border-r border-purple-500/20 flex flex-col transition-all duration-300 ${isCollapsed ? "w-16" : "w-60"}`}
    >
      {/* Header */}
      <div className="p-4 border-b border-purple-500/20">
        <div className="flex items-center justify-between">
          {!isCollapsed && (
            <div className="flex items-center space-x-2">
              <Brain className="h-8 w-8 text-purple-400" />
              <span className="text-xl font-bold text-white">MindWave.AI</span>
            </div>
          )}
          <button
            onClick={() => setIsCollapsed(!isCollapsed)}
            className="p-2 rounded-lg bg-purple-600/20 text-purple-300 hover:bg-purple-600/30 transition-colors"
            aria-label={isCollapsed ? "Expandir sidebar" : "Recolher sidebar"}
          >
            <svg
              className={`w-4 h-4 transition-transform ${isCollapsed ? "rotate-180" : ""}`}
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
        </div>
      </div>

      {/* User Profile */}
      <div className="p-4 border-b border-purple-500/20">
        <div className="flex items-center space-x-3">
          <Avatar className="h-10 w-10">
            <AvatarImage src={user?.user_metadata?.avatar_url || "/placeholder.svg"} />
            <AvatarFallback className="bg-purple-600 text-white">
              {user?.user_metadata?.name?.charAt(0) || user?.email?.charAt(0) || "U"}
            </AvatarFallback>
          </Avatar>
          {!isCollapsed && (
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-white truncate">{user?.user_metadata?.name || "Usuário"}</p>
              <div className="flex items-center space-x-2">
                <Badge
                  variant={isPremium ? "default" : "secondary"}
                  className={isPremium ? "bg-gradient-to-r from-yellow-400 to-orange-500 text-black" : ""}
                >
                  {isPremium && <Crown className="h-3 w-3 mr-1" />}
                  {userPlan === "premium" ? "Premium" : userPlan === "family" ? "Família" : "Gratuito"}
                </Badge>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
        {menuItems.map((item) => {
          const Icon = item.icon
          const isActive = pathname === item.href
          const needsPremium = item.premium && !isPremium

          return (
            <Link
              key={item.href}
              href={needsPremium ? "/pricing" : item.href}
              className={`
                flex items-center space-x-3 px-3 py-2 rounded-lg transition-all duration-200 group
                ${
                  isActive
                    ? "bg-purple-600 text-white shadow-lg shadow-purple-600/25"
                    : "text-gray-300 hover:bg-purple-600/20 hover:text-white"
                }
                ${needsPremium ? "opacity-60" : ""}
              `}
              title={isCollapsed ? item.title : item.description}
            >
              <Icon className={`h-5 w-5 flex-shrink-0 ${needsPremium ? "text-yellow-400" : ""}`} />
              {!isCollapsed && (
                <>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{item.title}</p>
                    <p className="text-xs opacity-75 truncate">{item.description}</p>
                  </div>
                  {needsPremium && <Crown className="h-4 w-4 text-yellow-400 flex-shrink-0" />}
                </>
              )}
            </Link>
          )
        })}
      </nav>

      {/* Upgrade CTA */}
      {!isPremium && !isCollapsed && (
        <div className="p-4 border-t border-purple-500/20">
          <div className="bg-gradient-to-r from-purple-600 to-pink-600 rounded-lg p-4 text-center">
            <Crown className="h-8 w-8 text-yellow-300 mx-auto mb-2" />
            <h3 className="text-sm font-bold text-white mb-1">Upgrade para Premium</h3>
            <p className="text-xs text-purple-100 mb-3">Desbloqueie todos os recursos e tenha apoio ilimitado</p>
            <Button asChild size="sm" className="w-full bg-white text-purple-600 hover:bg-gray-100">
              <Link href="/pricing">Assinar Agora</Link>
            </Button>
          </div>
        </div>
      )}

      {/* Settings & Logout */}
      <div className="p-4 border-t border-purple-500/20 space-y-2">
        <Link
          href="/settings"
          className={`
            flex items-center space-x-3 px-3 py-2 rounded-lg transition-colors
            ${
              pathname === "/settings"
                ? "bg-purple-600 text-white"
                : "text-gray-300 hover:bg-purple-600/20 hover:text-white"
            }
          `}
          title={isCollapsed ? "Configurações" : undefined}
        >
          <Settings className="h-5 w-5 flex-shrink-0" />
          {!isCollapsed && <span className="text-sm">Configurações</span>}
        </Link>

        <button
          onClick={signOut}
          className="flex items-center space-x-3 px-3 py-2 rounded-lg transition-colors text-gray-300 hover:bg-red-600/20 hover:text-red-300 w-full"
          title={isCollapsed ? "Sair" : undefined}
        >
          <LogOut className="h-5 w-5 flex-shrink-0" />
          {!isCollapsed && <span className="text-sm">Sair</span>}
        </button>
      </div>
    </div>
  )
}
