"use client"

import { createContext, useContext, useEffect, type ReactNode } from "react"
import { usePathname, useSearchParams } from "next/navigation"

declare global {
  interface Window {
    gtag: (command: string, targetId: string, config?: any) => void
  }
}

interface AnalyticsContextType {
  trackEvent: (eventName: string, parameters?: Record<string, any>) => void
  trackPageView: (url: string) => void
  trackConversion: (conversionData: {
    event: string
    value?: number
    currency?: string
    transaction_id?: string
  }) => void
  trackUserEngagement: (engagementData: {
    engagement_time_msec?: number
    session_id?: string
  }) => void
}

const AnalyticsContext = createContext<AnalyticsContextType | undefined>(undefined)

interface AnalyticsProviderProps {
  children: ReactNode
  measurementId: string
}

export function AnalyticsProvider({ children, measurementId }: AnalyticsProviderProps) {
  const pathname = usePathname()
  const searchParams = useSearchParams()

  useEffect(() => {
    // Carrega o Google Analytics 4
    const script = document.createElement("script")
    script.src = `https://www.googletagmanager.com/gtag/js?id=${measurementId}`
    script.async = true
    document.head.appendChild(script)

    script.onload = () => {
      window.gtag =
        window.gtag ||
        (() => {
          ;(window as any).dataLayer = (window as any).dataLayer || []
          ;(window as any).dataLayer.push(arguments)
        })

      window.gtag("js", new Date())
      window.gtag("config", measurementId, {
        page_title: document.title,
        page_location: window.location.href,
        send_page_view: true,
      })

      // Configura eventos personalizados
      window.gtag("config", measurementId, {
        custom_map: {
          custom_parameter_1: "user_plan",
          custom_parameter_2: "subscription_status",
          custom_parameter_3: "module_accessed",
        },
      })
    }

    return () => {
      document.head.removeChild(script)
    }
  }, [measurementId])

  useEffect(() => {
    // Rastreia mudanças de página
    if (typeof window.gtag !== "undefined") {
      const url = pathname + searchParams.toString()
      trackPageView(url)
    }
  }, [pathname, searchParams])

  const trackEvent = (eventName: string, parameters: Record<string, any> = {}) => {
    if (typeof window.gtag !== "undefined") {
      window.gtag("event", eventName, {
        event_category: parameters.category || "engagement",
        event_label: parameters.label,
        value: parameters.value,
        user_id: parameters.user_id,
        session_id: parameters.session_id,
        timestamp: new Date().toISOString(),
        ...parameters,
      })

      // Log para desenvolvimento
      if (process.env.NODE_ENV === "development") {
        console.log("Analytics Event:", eventName, parameters)
      }
    }
  }

  const trackPageView = (url: string) => {
    if (typeof window.gtag !== "undefined") {
      window.gtag("config", measurementId, {
        page_path: url,
        page_title: document.title,
        page_location: window.location.href,
      })

      // Evento personalizado de page view
      trackEvent("page_view", {
        page_path: url,
        page_title: document.title,
        category: "navigation",
      })
    }
  }

  const trackConversion = (conversionData: {
    event: string
    value?: number
    currency?: string
    transaction_id?: string
  }) => {
    if (typeof window.gtag !== "undefined") {
      window.gtag("event", conversionData.event, {
        currency: conversionData.currency || "BRL",
        value: conversionData.value,
        transaction_id: conversionData.transaction_id,
        event_category: "ecommerce",
        send_to: measurementId,
      })

      // Evento de conversão personalizado
      trackEvent("conversion", {
        conversion_type: conversionData.event,
        conversion_value: conversionData.value,
        currency: conversionData.currency || "BRL",
        transaction_id: conversionData.transaction_id,
        category: "conversion",
      })
    }
  }

  const trackUserEngagement = (engagementData: {
    engagement_time_msec?: number
    session_id?: string
  }) => {
    if (typeof window.gtag !== "undefined") {
      window.gtag("event", "user_engagement", {
        engagement_time_msec: engagementData.engagement_time_msec,
        session_id: engagementData.session_id,
        event_category: "engagement",
      })
    }
  }

  const contextValue: AnalyticsContextType = {
    trackEvent,
    trackPageView,
    trackConversion,
    trackUserEngagement,
  }

  return <AnalyticsContext.Provider value={contextValue}>{children}</AnalyticsContext.Provider>
}

export function useAnalytics() {
  const context = useContext(AnalyticsContext)
  if (context === undefined) {
    throw new Error("useAnalytics must be used within an AnalyticsProvider")
  }
  return context
}

// Hook para rastrear eventos específicos do MindWave.AI
export function useMindWaveAnalytics() {
  const { trackEvent, trackConversion } = useAnalytics()

  const trackModuleAccess = (moduleName: string, userPlan: string) => {
    trackEvent("module_access", {
      module_name: moduleName,
      user_plan: userPlan,
      category: "module_engagement",
      label: `${moduleName}_${userPlan}`,
    })
  }

  const trackSubscriptionAttempt = (planId: string, paymentMethod: string) => {
    trackEvent("subscription_attempt", {
      plan_id: planId,
      payment_method: paymentMethod,
      category: "subscription",
      label: `${planId}_${paymentMethod}`,
    })
  }

  const trackSubscriptionSuccess = (planId: string, subscriptionId: string, value: number) => {
    trackConversion({
      event: "purchase",
      value: value,
      currency: "BRL",
      transaction_id: subscriptionId,
    })

    trackEvent("subscription_success", {
      plan_id: planId,
      subscription_id: subscriptionId,
      value: value,
      category: "conversion",
      label: `subscription_${planId}`,
    })
  }

  const trackPaymentMethod = (method: string, planId: string) => {
    trackEvent("payment_method_selected", {
      payment_method: method,
      plan_id: planId,
      category: "payment",
      label: `${method}_${planId}`,
    })
  }

  const trackWhatsAppInteraction = (action: string, source: string) => {
    trackEvent("whatsapp_interaction", {
      action: action,
      source: source,
      category: "whatsapp",
      label: `${action}_${source}`,
    })
  }

  const trackChatInteraction = (messageType: string, userPlan: string) => {
    trackEvent("chat_interaction", {
      message_type: messageType,
      user_plan: userPlan,
      category: "ai_chat",
      label: `${messageType}_${userPlan}`,
    })
  }

  const trackMoodEntry = (moodScore: number, userPlan: string) => {
    trackEvent("mood_entry", {
      mood_score: moodScore,
      user_plan: userPlan,
      category: "wellness",
      label: `mood_${moodScore}`,
    })
  }

  const trackOnboardingStep = (step: string, completed: boolean) => {
    trackEvent("onboarding_step", {
      step: step,
      completed: completed,
      category: "onboarding",
      label: `${step}_${completed ? "completed" : "abandoned"}`,
    })
  }

  const trackFeatureUsage = (feature: string, userPlan: string, duration?: number) => {
    trackEvent("feature_usage", {
      feature_name: feature,
      user_plan: userPlan,
      usage_duration: duration,
      category: "feature_engagement",
      label: `${feature}_${userPlan}`,
    })
  }

  return {
    trackModuleAccess,
    trackSubscriptionAttempt,
    trackSubscriptionSuccess,
    trackPaymentMethod,
    trackWhatsAppInteraction,
    trackChatInteraction,
    trackMoodEntry,
    trackOnboardingStep,
    trackFeatureUsage,
  }
}
