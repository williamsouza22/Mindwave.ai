"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Users, MessageCircle, CreditCard, TrendingUp, AlertTriangle, Crown } from "lucide-react"

const stats = [
  {
    title: "Usuários Ativos",
    value: "2,847",
    change: "+12.5%",
    trend: "up",
    icon: Users,
    color: "text-blue-600",
    bgColor: "bg-blue-50",
  },
  {
    title: "Conversas Hoje",
    value: "1,234",
    change: "+8.2%",
    trend: "up",
    icon: MessageCircle,
    color: "text-green-600",
    bgColor: "bg-green-50",
  },
  {
    title: "Receita Mensal",
    value: "R$ 47.890",
    change: "+23.1%",
    trend: "up",
    icon: CreditCard,
    color: "text-purple-600",
    bgColor: "bg-purple-50",
  },
  {
    title: "Taxa de Conversão",
    value: "3.2%",
    change: "+0.8%",
    trend: "up",
    icon: TrendingUp,
    color: "text-yellow-600",
    bgColor: "bg-yellow-50",
  },
  {
    title: "Usuários Premium",
    value: "892",
    change: "+15.3%",
    trend: "up",
    icon: Crown,
    color: "text-indigo-600",
    bgColor: "bg-indigo-50",
  },
  {
    title: "Alertas Críticos",
    value: "3",
    change: "-2",
    trend: "down",
    icon: AlertTriangle,
    color: "text-red-600",
    bgColor: "bg-red-50",
  },
]

export function AdminStats() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-6">
      {stats.map((stat) => (
        <Card key={stat.title}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">{stat.title}</CardTitle>
            <div className={`p-2 rounded-lg ${stat.bgColor}`}>
              <stat.icon className={`h-4 w-4 ${stat.color}`} />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stat.value}</div>
            <div className="flex items-center space-x-2 mt-1">
              <Badge
                variant="secondary"
                className={`text-xs ${stat.trend === "up" ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}`}
              >
                {stat.change}
              </Badge>
              <span className="text-xs text-gray-500">vs. mês anterior</span>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
