"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Label } from "@/components/ui/label"
import { Sparkles, Send, Copy, Download, History, Target, Mail, MessageSquare, Loader2 } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface Campaign {
  id: string
  type: string
  target: string
  content: string
  created_at: string
}

const campaignTypes = [
  { value: "email", label: "Email Marketing", icon: Mail },
  { value: "whatsapp", label: "WhatsApp", icon: MessageSquare },
  { value: "social", label: "Redes Sociais", icon: Target },
  { value: "blog", label: "Blog Post", icon: Sparkles },
]

const targetAudiences = [
  { value: "new_users", label: "Novos Usuários" },
  { value: "free_users", label: "Usuários Gratuitos" },
  { value: "premium_users", label: "Usuários Premium" },
  { value: "churned_users", label: "Usuários que Cancelaram" },
  { value: "high_engagement", label: "Alto Engajamento" },
  { value: "low_engagement", label: "Baixo Engajamento" },
]

export function AIMarketingAssistant() {
  const [campaignType, setCampaignType] = useState("email")
  const [targetAudience, setTargetAudience] = useState("new_users")
  const [prompt, setPrompt] = useState("")
  const [generatedContent, setGeneratedContent] = useState("")
  const [loading, setLoading] = useState(false)
  const [campaigns, setCampaigns] = useState<Campaign[]>([])
  const { toast } = useToast()

  const generateCampaign = async () => {
    if (!prompt.trim()) {
      toast({
        title: "Erro",
        description: "Por favor, descreva o que você quer comunicar.",
        variant: "destructive",
      })
      return
    }

    setLoading(true)

    try {
      const response = await fetch("/api/admin/generate-campaign", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          type: campaignType,
          target: targetAudience,
          prompt: prompt,
        }),
      })

      if (!response.ok) {
        throw new Error("Falha ao gerar campanha")
      }

      const data = await response.json()
      setGeneratedContent(data.content)

      // Save to history
      const newCampaign: Campaign = {
        id: Date.now().toString(),
        type: campaignType,
        target: targetAudience,
        content: data.content,
        created_at: new Date().toISOString(),
      }
      setCampaigns((prev) => [newCampaign, ...prev])

      toast({
        title: "Campanha gerada com sucesso! 🎉",
        description: "Revise o conteúdo e faça ajustes se necessário.",
      })
    } catch (error) {
      console.error("Error generating campaign:", error)
      toast({
        title: "Erro ao gerar campanha",
        description: "Tente novamente em alguns instantes.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const copyContent = () => {
    navigator.clipboard.writeText(generatedContent)
    toast({
      title: "Conteúdo copiado!",
      description: "O texto foi copiado para a área de transferência.",
    })
  }

  const exportCampaign = () => {
    const blob = new Blob([generatedContent], { type: "text/plain" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `campanha-${campaignType}-${Date.now()}.txt`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  return (
    <div className="space-y-6">
      {/* Campaign Generator */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Sparkles className="h-5 w-5 text-purple-500" />
            <span>Assistente de Marketing IA</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Campaign Type */}
          <div className="space-y-2">
            <Label>Tipo de Campanha</Label>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
              {campaignTypes.map((type) => {
                const Icon = type.icon
                return (
                  <Button
                    key={type.value}
                    variant={campaignType === type.value ? "default" : "outline"}
                    onClick={() => setCampaignType(type.value)}
                    className="h-auto p-3 flex flex-col items-center space-y-1"
                  >
                    <Icon className="h-4 w-4" />
                    <span className="text-xs">{type.label}</span>
                  </Button>
                )
              })}
            </div>
          </div>

          {/* Target Audience */}
          <div className="space-y-2">
            <Label>Público-Alvo</Label>
            <select
              value={targetAudience}
              onChange={(e) => setTargetAudience(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              {targetAudiences.map((audience) => (
                <option key={audience.value} value={audience.value}>
                  {audience.label}
                </option>
              ))}
            </select>
          </div>

          {/* Prompt */}
          <div className="space-y-2">
            <Label>Descreva sua campanha</Label>
            <Textarea
              placeholder="Ex: Promover o novo recurso de fitoterapia para usuários que demonstraram interesse em bem-estar natural..."
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              rows={3}
            />
          </div>

          {/* Generate Button */}
          <Button onClick={generateCampaign} disabled={loading} className="w-full">
            {loading ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Gerando campanha...
              </>
            ) : (
              <>
                <Send className="h-4 w-4 mr-2" />
                Gerar Campanha
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {/* Generated Content */}
      {generatedContent && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Conteúdo Gerado</span>
              <div className="flex space-x-2">
                <Button variant="outline" size="sm" onClick={copyContent}>
                  <Copy className="h-4 w-4 mr-2" />
                  Copiar
                </Button>
                <Button variant="outline" size="sm" onClick={exportCampaign}>
                  <Download className="h-4 w-4 mr-2" />
                  Exportar
                </Button>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <Badge variant="secondary">{campaignTypes.find((t) => t.value === campaignType)?.label}</Badge>
                <Badge variant="outline">{targetAudiences.find((a) => a.value === targetAudience)?.label}</Badge>
              </div>

              <div className="p-4 bg-gray-50 rounded-lg border">
                <pre className="whitespace-pre-wrap text-sm">{generatedContent}</pre>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Campaign History */}
      {campaigns.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <History className="h-5 w-5 text-gray-500" />
              <span>Histórico de Campanhas</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {campaigns.slice(0, 5).map((campaign) => (
                <div key={campaign.id} className="p-4 border rounded-lg hover:bg-gray-50">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <Badge variant="secondary">{campaignTypes.find((t) => t.value === campaign.type)?.label}</Badge>
                      <Badge variant="outline">{targetAudiences.find((a) => a.value === campaign.target)?.label}</Badge>
                    </div>
                    <span className="text-xs text-gray-500">
                      {new Date(campaign.created_at).toLocaleDateString("pt-BR")}
                    </span>
                  </div>
                  <p className="text-sm text-gray-700 line-clamp-3">{campaign.content.substring(0, 200)}...</p>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setGeneratedContent(campaign.content)}
                    className="mt-2"
                  >
                    Ver Completo
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
