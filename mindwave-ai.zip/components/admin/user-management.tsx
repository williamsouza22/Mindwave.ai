"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Users, Crown, AlertTriangle } from "lucide-react"

const recentUsers = [
  {
    id: "1",
    name: "Maria Silva",
    email: "maria@email.com",
    plan: "Premium",
    status: "active",
    lastSeen: "2 min atrás",
    riskLevel: "low",
  },
  {
    id: "2",
    name: "João Santos",
    email: "joao@email.com",
    plan: "Free",
    status: "active",
    lastSeen: "1 hora atrás",
    riskLevel: "medium",
  },
  {
    id: "3",
    name: "Ana Costa",
    email: "ana@email.com",
    plan: "Premium",
    status: "inactive",
    lastSeen: "3 dias atrás",
    riskLevel: "high",
  },
]

export function UserManagement() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Users className="h-5 w-5 text-blue-500" />
          <span>Usuários Recentes</span>
        </CardTitle>
      </CardHeader>

      <CardContent className="space-y-4">
        {recentUsers.map((user) => (
          <div key={user.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
            <div className="flex items-center space-x-3">
              <Avatar className="h-10 w-10">
                <AvatarImage src={`/placeholder.svg?height=40&width=40`} />
                <AvatarFallback>
                  {user.name
                    .split(" ")
                    .map((n) => n[0])
                    .join("")}
                </AvatarFallback>
              </Avatar>

              <div className="flex-1">
                <div className="flex items-center space-x-2">
                  <p className="font-medium text-sm">{user.name}</p>
                  {user.plan === "Premium" && <Crown className="h-3 w-3 text-yellow-500" />}
                  {user.riskLevel === "high" && <AlertTriangle className="h-3 w-3 text-red-500" />}
                </div>
                <p className="text-xs text-gray-500">{user.email}</p>
                <p className="text-xs text-gray-400">{user.lastSeen}</p>
              </div>
            </div>

            <div className="flex flex-col items-end space-y-1">
              <Badge variant={user.plan === "Premium" ? "default" : "secondary"} className="text-xs">
                {user.plan}
              </Badge>
              <Badge
                variant={user.status === "active" ? "secondary" : "outline"}
                className={`text-xs ${user.status === "active" ? "bg-green-100 text-green-700" : ""}`}
              >
                {user.status}
              </Badge>
            </div>
          </div>
        ))}

        <Button variant="outline" className="w-full bg-transparent">
          <Users className="h-4 w-4 mr-2" />
          Ver Todos os Usuários
        </Button>
      </CardContent>
    </Card>
  )
}
