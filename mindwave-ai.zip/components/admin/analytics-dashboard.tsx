"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { BarChart3, TrendingUp } from "lucide-react"

// Mock data for analytics
const conversationData = [
  { day: "Seg", conversations: 120, users: 89 },
  { day: "Ter", conversations: 145, users: 102 },
  { day: "Qua", conversations: 167, users: 118 },
  { day: "Qui", conversations: 189, users: 134 },
  { day: "Sex", conversations: 201, users: 145 },
  { day: "Sáb", conversations: 156, users: 112 },
  { day: "Dom", conversations: 134, users: 98 },
]

const moodDistribution = [
  { mood: "Muito Feliz", count: 234, percentage: 23, color: "bg-green-500" },
  { mood: "Feliz", count: 345, percentage: 34, color: "bg-blue-500" },
  { mood: "Neutro", count: 267, percentage: 26, color: "bg-yellow-500" },
  { mood: "Triste", count: 123, percentage: 12, color: "bg-orange-500" },
  { mood: "Muito Triste", count: 45, percentage: 5, color: "bg-red-500" },
]

export function AnalyticsDashboard() {
  return (
    <div className="space-y-6">
      {/* Conversation Analytics */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <BarChart3 className="h-5 w-5 text-blue-500" />
            <span>Conversas por Dia</span>
          </CardTitle>
        </CardHeader>

        <CardContent>
          <div className="flex items-end justify-between h-48 bg-gray-50 rounded-lg p-4">
            {conversationData.map((day, index) => (
              <div key={day.day} className="flex flex-col items-center space-y-2">
                <div className="flex flex-col items-center space-y-1">
                  <div
                    className="w-8 bg-blue-500 rounded-t"
                    style={{ height: `${(day.conversations / 250) * 120}px` }}
                  ></div>
                  <div className="w-8 bg-purple-500 rounded-t" style={{ height: `${(day.users / 200) * 80}px` }}></div>
                </div>
                <span className="text-xs text-gray-500 font-medium">{day.day}</span>
              </div>
            ))}
          </div>

          <div className="flex items-center justify-center space-x-6 mt-4">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-blue-500 rounded"></div>
              <span className="text-sm text-gray-600">Conversas</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-purple-500 rounded"></div>
              <span className="text-sm text-gray-600">Usuários Únicos</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Mood Distribution */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <TrendingUp className="h-5 w-5 text-green-500" />
            <span>Distribuição de Humor</span>
          </CardTitle>
        </CardHeader>

        <CardContent>
          <div className="space-y-4">
            {moodDistribution.map((mood) => (
              <div key={mood.mood} className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className={`w-4 h-4 rounded ${mood.color}`}></div>
                  <span className="text-sm font-medium">{mood.mood}</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-32 bg-gray-200 rounded-full h-2">
                    <div className={`h-2 rounded-full ${mood.color}`} style={{ width: `${mood.percentage}%` }}></div>
                  </div>
                  <span className="text-sm text-gray-600 w-12 text-right">{mood.count}</span>
                  <Badge variant="outline" className="text-xs">
                    {mood.percentage}%
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
