"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { AlertTriangle, Clock, User, MessageCircle } from "lucide-react"

const alerts = [
  {
    id: "1",
    type: "critical",
    title: "Usuário em risco detectado",
    description: "Palavras-chave críticas identificadas na conversa",
    user: "Ana Costa",
    timestamp: "5 min atrás",
    action: "Revisar conversa",
  },
  {
    id: "2",
    type: "warning",
    title: "Alta taxa de cancelamento",
    description: "15% dos usuários premium cancelaram hoje",
    user: null,
    timestamp: "1 hora atrás",
    action: "Analisar motivos",
  },
  {
    id: "3",
    type: "info",
    title: "Pico de conversas",
    description: "Volume 40% acima da média nas últimas 2 horas",
    user: null,
    timestamp: "2 horas atrás",
    action: "Monitorar sistema",
  },
]

const getAlertColor = (type: string) => {
  switch (type) {
    case "critical":
      return "bg-red-100 text-red-700 border-red-200"
    case "warning":
      return "bg-yellow-100 text-yellow-700 border-yellow-200"
    case "info":
      return "bg-blue-100 text-blue-700 border-blue-200"
    default:
      return "bg-gray-100 text-gray-700 border-gray-200"
  }
}

const getAlertIcon = (type: string) => {
  switch (type) {
    case "critical":
      return AlertTriangle
    case "warning":
      return Clock
    case "info":
      return MessageCircle
    default:
      return AlertTriangle
  }
}

export function AlertsPanel() {
  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center space-x-2">
            <AlertTriangle className="h-5 w-5 text-red-500" />
            <span>Alertas do Sistema</span>
          </CardTitle>
          <Badge variant="secondary" className="bg-red-100 text-red-700">
            {alerts.filter((a) => a.type === "critical").length} Críticos
          </Badge>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {alerts.map((alert) => {
          const Icon = getAlertIcon(alert.type)
          return (
            <div key={alert.id} className={`p-4 rounded-lg border ${getAlertColor(alert.type)}`}>
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center space-x-2">
                  <Icon className="h-4 w-4" />
                  <h4 className="font-semibold text-sm">{alert.title}</h4>
                </div>
                <Badge variant="outline" className="text-xs">
                  {alert.type}
                </Badge>
              </div>

              <p className="text-sm mb-2">{alert.description}</p>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2 text-xs">
                  <Clock className="h-3 w-3" />
                  <span>{alert.timestamp}</span>
                  {alert.user && (
                    <>
                      <User className="h-3 w-3 ml-2" />
                      <span>{alert.user}</span>
                    </>
                  )}
                </div>
                <Button variant="outline" size="sm" className="text-xs bg-transparent">
                  {alert.action}
                </Button>
              </div>
            </div>
          )
        })}

        <Button variant="outline" className="w-full bg-transparent">
          <AlertTriangle className="h-4 w-4 mr-2" />
          Ver Todos os Alertas
        </Button>
      </CardContent>
    </Card>
  )
}
