"use client"
import { usePathname } from "next/navigation"
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSub,
  SidebarMenuSubButton,
  SidebarMenuSubItem,
  SidebarRail,
} from "@/components/ui/sidebar"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { useAuth } from "@/lib/auth/auth-context"
import {
  LayoutDashboard,
  BarChart3,
  Users,
  FileText,
  CreditCard,
  Activity,
  AlertTriangle,
  Eye,
  Database,
  Upload,
  Bell,
  Settings,
  Shield,
  LogOut,
  Crown,
  Sparkles,
  ChevronRight,
  TrendingUp,
  UserCheck,
  MessageSquare,
  ImageIcon,
  DollarSign,
  RefreshCw,
  HardDrive,
  Mail,
  Zap,
} from "lucide-react"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"

// Admin menu data structure
const adminMenuData = {
  overview: [
    {
      title: "Dashboard",
      url: "/admin",
      icon: LayoutDashboard,
    },
    {
      title: "Analytics",
      icon: BarChart3,
      items: [
        {
          title: "Usuários Ativos",
          url: "/admin/analytics/users",
          icon: UserCheck,
        },
        {
          title: "Conversas IA",
          url: "/admin/analytics/conversations",
          icon: MessageSquare,
        },
        {
          title: "Humor Trends",
          url: "/admin/analytics/mood-trends",
          icon: TrendingUp,
        },
      ],
    },
    {
      title: "Relatórios",
      url: "/admin/reports",
      icon: FileText,
      badge: "12",
    },
  ],
  management: [
    {
      title: "Usuários",
      icon: Users,
      items: [
        {
          title: "Todos os Usuários",
          url: "/admin/users",
          icon: Users,
        },
        {
          title: "Usuários Premium",
          url: "/admin/users/premium",
          icon: Crown,
        },
        {
          title: "Usuários Bloqueados",
          url: "/admin/users/blocked",
          icon: Shield,
        },
      ],
    },
    {
      title: "Conteúdo",
      icon: FileText,
      items: [
        {
          title: "Artigos",
          url: "/admin/content/articles",
          icon: FileText,
        },
        {
          title: "Meditações",
          url: "/admin/content/meditations",
          icon: Sparkles,
        },
        {
          title: "Imagens",
          url: "/admin/content/images",
          icon: ImageIcon,
        },
      ],
    },
    {
      title: "Pagamentos",
      icon: CreditCard,
      items: [
        {
          title: "Transações",
          url: "/admin/payments/transactions",
          icon: DollarSign,
        },
        {
          title: "Assinaturas",
          url: "/admin/payments/subscriptions",
          icon: RefreshCw,
        },
        {
          title: "Reembolsos",
          url: "/admin/payments/refunds",
          icon: CreditCard,
        },
      ],
    },
  ],
  monitoring: [
    {
      title: "Sistema",
      icon: Activity,
      items: [
        {
          title: "Performance",
          url: "/admin/system/performance",
          icon: Activity,
        },
        {
          title: "Logs",
          url: "/admin/system/logs",
          icon: FileText,
        },
        {
          title: "API Status",
          url: "/admin/system/api",
          icon: Zap,
        },
      ],
    },
    {
      title: "Alertas",
      url: "/admin/alerts",
      icon: AlertTriangle,
      badge: "3",
    },
    {
      title: "Atividade",
      url: "/admin/activity",
      icon: Eye,
    },
  ],
  tools: [
    {
      title: "Backup",
      icon: Database,
      items: [
        {
          title: "Backup Manual",
          url: "/admin/backup/manual",
          icon: Database,
        },
        {
          title: "Agendamentos",
          url: "/admin/backup/scheduled",
          icon: RefreshCw,
        },
        {
          title: "Restaurar",
          url: "/admin/backup/restore",
          icon: Upload,
        },
      ],
    },
    {
      title: "Importar/Exportar",
      url: "/admin/import-export",
      icon: Upload,
    },
    {
      title: "Notificações",
      icon: Bell,
      items: [
        {
          title: "Push Notifications",
          url: "/admin/notifications/push",
          icon: Bell,
        },
        {
          title: "Email Marketing",
          url: "/admin/notifications/email",
          icon: Mail,
        },
        {
          title: "Templates",
          url: "/admin/notifications/templates",
          icon: FileText,
        },
      ],
    },
  ],
  system: [
    {
      title: "Configurações",
      icon: Settings,
      items: [
        {
          title: "Geral",
          url: "/admin/settings/general",
          icon: Settings,
        },
        {
          title: "IA & Modelos",
          url: "/admin/settings/ai",
          icon: Sparkles,
        },
        {
          title: "Integrações",
          url: "/admin/settings/integrations",
          icon: Zap,
        },
      ],
    },
    {
      title: "Segurança",
      url: "/admin/security",
      icon: Shield,
    },
    {
      title: "Database",
      url: "/admin/database",
      icon: HardDrive,
    },
  ],
}

export function AdminSidebar() {
  const pathname = usePathname()
  const { user, profile, logout } = useAuth()

  const isActive = (url: string) => pathname === url

  return (
    <Sidebar variant="inset" className="border-r border-gray-300">
      <SidebarHeader className="border-b border-gray-300 bg-white">
        <div className="flex items-center space-x-3 p-4">
          <div className="w-8 h-8 rounded-full bg-gradient-to-r from-red-500 to-orange-500 flex items-center justify-center">
            <Shield className="h-4 w-4 text-white" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-gray-900">Admin Panel</h2>
            <p className="text-xs text-gray-500">MindWave.AI Management</p>
          </div>
        </div>
      </SidebarHeader>

      <SidebarContent className="bg-white">
        {/* Overview */}
        <SidebarGroup>
          <SidebarGroupLabel className="text-gray-500 text-xs uppercase tracking-wider">Visão Geral</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {adminMenuData.overview.map((item) => (
                <SidebarMenuItem key={item.title}>
                  {item.items ? (
                    <Collapsible defaultOpen={false} className="group/collapsible">
                      <CollapsibleTrigger asChild>
                        <SidebarMenuButton className="text-gray-700 hover:text-gray-900 hover:bg-gray-100">
                          <item.icon className="h-4 w-4" />
                          <span>{item.title}</span>
                          <ChevronRight className="ml-auto h-4 w-4 transition-transform group-data-[state=open]/collapsible:rotate-90" />
                        </SidebarMenuButton>
                      </CollapsibleTrigger>
                      <CollapsibleContent>
                        <SidebarMenuSub>
                          {item.items.map((subItem) => (
                            <SidebarMenuSubItem key={subItem.title}>
                              <SidebarMenuSubButton
                                asChild
                                isActive={isActive(subItem.url)}
                                className="text-gray-600 hover:text-gray-900 hover:bg-gray-100"
                              >
                                <a href={subItem.url}>
                                  <subItem.icon className="h-3 w-3" />
                                  <span>{subItem.title}</span>
                                </a>
                              </SidebarMenuSubButton>
                            </SidebarMenuSubItem>
                          ))}
                        </SidebarMenuSub>
                      </CollapsibleContent>
                    </Collapsible>
                  ) : (
                    <SidebarMenuButton
                      asChild
                      isActive={isActive(item.url!)}
                      className="text-gray-700 hover:text-gray-900 hover:bg-gray-100"
                    >
                      <a href={item.url!}>
                        <item.icon className="h-4 w-4" />
                        <span>{item.title}</span>
                        {item.badge && (
                          <Badge variant="secondary" className="ml-auto bg-red-100 text-red-700 text-xs">
                            {item.badge}
                          </Badge>
                        )}
                      </a>
                    </SidebarMenuButton>
                  )}
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {/* Management */}
        <SidebarGroup>
          <SidebarGroupLabel className="text-gray-500 text-xs uppercase tracking-wider">
            Gerenciamento
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {adminMenuData.management.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <Collapsible defaultOpen={false} className="group/collapsible">
                    <CollapsibleTrigger asChild>
                      <SidebarMenuButton className="text-gray-700 hover:text-gray-900 hover:bg-gray-100">
                        <item.icon className="h-4 w-4" />
                        <span>{item.title}</span>
                        <ChevronRight className="ml-auto h-4 w-4 transition-transform group-data-[state=open]/collapsible:rotate-90" />
                      </SidebarMenuButton>
                    </CollapsibleTrigger>
                    <CollapsibleContent>
                      <SidebarMenuSub>
                        {item.items?.map((subItem) => (
                          <SidebarMenuSubItem key={subItem.title}>
                            <SidebarMenuSubButton
                              asChild
                              isActive={isActive(subItem.url)}
                              className="text-gray-600 hover:text-gray-900 hover:bg-gray-100"
                            >
                              <a href={subItem.url}>
                                <subItem.icon className="h-3 w-3" />
                                <span>{subItem.title}</span>
                              </a>
                            </SidebarMenuSubButton>
                          </SidebarMenuSubItem>
                        ))}
                      </SidebarMenuSub>
                    </CollapsibleContent>
                  </Collapsible>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {/* Monitoring */}
        <SidebarGroup>
          <SidebarGroupLabel className="text-gray-500 text-xs uppercase tracking-wider">
            Monitoramento
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {adminMenuData.monitoring.map((item) => (
                <SidebarMenuItem key={item.title}>
                  {item.items ? (
                    <Collapsible defaultOpen={false} className="group/collapsible">
                      <CollapsibleTrigger asChild>
                        <SidebarMenuButton className="text-gray-700 hover:text-gray-900 hover:bg-gray-100">
                          <item.icon className="h-4 w-4" />
                          <span>{item.title}</span>
                          <ChevronRight className="ml-auto h-4 w-4 transition-transform group-data-[state=open]/collapsible:rotate-90" />
                        </SidebarMenuButton>
                      </CollapsibleTrigger>
                      <CollapsibleContent>
                        <SidebarMenuSub>
                          {item.items.map((subItem) => (
                            <SidebarMenuSubItem key={subItem.title}>
                              <SidebarMenuSubButton
                                asChild
                                isActive={isActive(subItem.url)}
                                className="text-gray-600 hover:text-gray-900 hover:bg-gray-100"
                              >
                                <a href={subItem.url}>
                                  <subItem.icon className="h-3 w-3" />
                                  <span>{subItem.title}</span>
                                </a>
                              </SidebarMenuSubButton>
                            </SidebarMenuSubItem>
                          ))}
                        </SidebarMenuSub>
                      </CollapsibleContent>
                    </Collapsible>
                  ) : (
                    <SidebarMenuButton
                      asChild
                      isActive={isActive(item.url!)}
                      className="text-gray-700 hover:text-gray-900 hover:bg-gray-100"
                    >
                      <a href={item.url!}>
                        <item.icon className="h-4 w-4" />
                        <span>{item.title}</span>
                        {item.badge && (
                          <Badge variant="destructive" className="ml-auto text-xs">
                            {item.badge}
                          </Badge>
                        )}
                      </a>
                    </SidebarMenuButton>
                  )}
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {/* Tools */}
        <SidebarGroup>
          <SidebarGroupLabel className="text-gray-500 text-xs uppercase tracking-wider">Ferramentas</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {adminMenuData.tools.map((item) => (
                <SidebarMenuItem key={item.title}>
                  {item.items ? (
                    <Collapsible defaultOpen={false} className="group/collapsible">
                      <CollapsibleTrigger asChild>
                        <SidebarMenuButton className="text-gray-700 hover:text-gray-900 hover:bg-gray-100">
                          <item.icon className="h-4 w-4" />
                          <span>{item.title}</span>
                          <ChevronRight className="ml-auto h-4 w-4 transition-transform group-data-[state=open]/collapsible:rotate-90" />
                        </SidebarMenuButton>
                      </CollapsibleTrigger>
                      <CollapsibleContent>
                        <SidebarMenuSub>
                          {item.items.map((subItem) => (
                            <SidebarMenuSubItem key={subItem.title}>
                              <SidebarMenuSubButton
                                asChild
                                isActive={isActive(subItem.url)}
                                className="text-gray-600 hover:text-gray-900 hover:bg-gray-100"
                              >
                                <a href={subItem.url}>
                                  <subItem.icon className="h-3 w-3" />
                                  <span>{subItem.title}</span>
                                </a>
                              </SidebarMenuSubButton>
                            </SidebarMenuSubItem>
                          ))}
                        </SidebarMenuSub>
                      </CollapsibleContent>
                    </Collapsible>
                  ) : (
                    <SidebarMenuButton
                      asChild
                      isActive={isActive(item.url!)}
                      className="text-gray-700 hover:text-gray-900 hover:bg-gray-100"
                    >
                      <a href={item.url!}>
                        <item.icon className="h-4 w-4" />
                        <span>{item.title}</span>
                      </a>
                    </SidebarMenuButton>
                  )}
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {/* System */}
        <SidebarGroup>
          <SidebarGroupLabel className="text-gray-500 text-xs uppercase tracking-wider">Sistema</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {adminMenuData.system.map((item) => (
                <SidebarMenuItem key={item.title}>
                  {item.items ? (
                    <Collapsible defaultOpen={false} className="group/collapsible">
                      <CollapsibleTrigger asChild>
                        <SidebarMenuButton className="text-gray-700 hover:text-gray-900 hover:bg-gray-100">
                          <item.icon className="h-4 w-4" />
                          <span>{item.title}</span>
                          <ChevronRight className="ml-auto h-4 w-4 transition-transform group-data-[state=open]/collapsible:rotate-90" />
                        </SidebarMenuButton>
                      </CollapsibleTrigger>
                      <CollapsibleContent>
                        <SidebarMenuSub>
                          {item.items.map((subItem) => (
                            <SidebarMenuSubItem key={subItem.title}>
                              <SidebarMenuSubButton
                                asChild
                                isActive={isActive(subItem.url)}
                                className="text-gray-600 hover:text-gray-900 hover:bg-gray-100"
                              >
                                <a href={subItem.url}>
                                  <subItem.icon className="h-3 w-3" />
                                  <span>{subItem.title}</span>
                                </a>
                              </SidebarMenuSubButton>
                            </SidebarMenuSubItem>
                          ))}
                        </SidebarMenuSub>
                      </CollapsibleContent>
                    </Collapsible>
                  ) : (
                    <SidebarMenuButton
                      asChild
                      isActive={isActive(item.url!)}
                      className="text-gray-700 hover:text-gray-900 hover:bg-gray-100"
                    >
                      <a href={item.url!}>
                        <item.icon className="h-4 w-4" />
                        <span>{item.title}</span>
                      </a>
                    </SidebarMenuButton>
                  )}
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="border-t border-gray-300 bg-white">
        <div className="p-4 space-y-4">
          {/* Admin Profile */}
          <div className="flex items-center space-x-3">
            <Avatar className="h-10 w-10">
              <AvatarImage src={profile?.avatar_url || "/placeholder.svg"} alt={profile?.name} />
              <AvatarFallback className="bg-gradient-to-r from-red-500 to-orange-500 text-white">
                {profile?.name
                  ?.split(" ")
                  .map((n) => n[0])
                  .join("")
                  .toUpperCase() || "A"}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-gray-900 truncate">{profile?.name || "Admin"}</p>
              <Badge className="bg-gradient-to-r from-red-500 to-orange-500 text-xs">
                <Shield className="h-3 w-3 mr-1" />
                Administrator
              </Badge>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={logout}
              className="text-gray-500 hover:text-red-500 hover:bg-gray-100"
            >
              <LogOut className="h-4 w-4" />
            </Button>
          </div>

          {/* System Status */}
          <div className="grid grid-cols-3 gap-2 text-center">
            <div className="p-2 bg-green-50 rounded border border-green-200">
              <div className="text-sm font-bold text-green-600">99.9%</div>
              <div className="text-xs text-green-500">Uptime</div>
            </div>
            <div className="p-2 bg-blue-50 rounded border border-blue-200">
              <div className="text-sm font-bold text-blue-600">1.2k</div>
              <div className="text-xs text-blue-500">Users</div>
            </div>
            <div className="p-2 bg-purple-50 rounded border border-purple-200">
              <div className="text-sm font-bold text-purple-600">45ms</div>
              <div className="text-xs text-purple-500">Response</div>
            </div>
          </div>
        </div>
      </SidebarFooter>

      <SidebarRail />
    </Sidebar>
  )
}
