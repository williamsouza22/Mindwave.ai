"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Input } from "@/components/ui/input"
import { CreditCard, Search, Download, AlertTriangle, CheckCircle, Clock, XCircle } from "lucide-react"
import { createClient } from "@/lib/supabase/client"

interface Subscription {
  id: string
  user_id: string
  plan_id: string
  status: string
  amount: number
  billing_type: string
  next_due_date: string
  last_payment_date: string | null
  created_at: string
  users: {
    name: string
    email: string
    avatar_url: string | null
  }
}

const statusColors = {
  active: "bg-green-100 text-green-800",
  overdue: "bg-yellow-100 text-yellow-800",
  cancelled: "bg-red-100 text-red-800",
  pending: "bg-blue-100 text-blue-800",
}

const statusIcons = {
  active: CheckCircle,
  overdue: Clock,
  cancelled: XCircle,
  pending: AlertTriangle,
}

export function SubscriptionManagement() {
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")

  const supabase = createClient()

  useEffect(() => {
    loadSubscriptions()
  }, [])

  const loadSubscriptions = async () => {
    try {
      const { data, error } = await supabase
        .from("subscriptions")
        .select(`
          *,
          users (
            name,
            email,
            avatar_url
          )
        `)
        .order("created_at", { ascending: false })

      if (error) throw error
      setSubscriptions(data || [])
    } catch (error) {
      console.error("Error loading subscriptions:", error)
    } finally {
      setLoading(false)
    }
  }

  const filteredSubscriptions = subscriptions.filter((sub) => {
    const matchesSearch =
      sub.users.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      sub.users.email.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesStatus = statusFilter === "all" || sub.status === statusFilter

    return matchesSearch && matchesStatus
  })

  const stats = {
    total: subscriptions.length,
    active: subscriptions.filter((s) => s.status === "active").length,
    overdue: subscriptions.filter((s) => s.status === "overdue").length,
    cancelled: subscriptions.filter((s) => s.status === "cancelled").length,
    revenue: subscriptions.filter((s) => s.status === "active").reduce((sum, s) => sum + s.amount, 0),
  }

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-gray-200 rounded w-1/4"></div>
            <div className="space-y-2">
              <div className="h-4 bg-gray-200 rounded"></div>
              <div className="h-4 bg-gray-200 rounded w-5/6"></div>
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              <p className="text-2xl font-bold text-blue-600">{stats.total}</p>
              <p className="text-sm text-gray-600">Total</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              <p className="text-2xl font-bold text-green-600">{stats.active}</p>
              <p className="text-sm text-gray-600">Ativas</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              <p className="text-2xl font-bold text-yellow-600">{stats.overdue}</p>
              <p className="text-sm text-gray-600">Em Atraso</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              <p className="text-2xl font-bold text-red-600">{stats.cancelled}</p>
              <p className="text-sm text-gray-600">Canceladas</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              <p className="text-2xl font-bold text-purple-600">R$ {stats.revenue.toFixed(2)}</p>
              <p className="text-sm text-gray-600">Receita Mensal</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters and Search */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <CreditCard className="h-5 w-5 text-blue-500" />
            <span>Gerenciar Assinaturas</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Buscar por nome ou email..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <div className="flex gap-2">
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="all">Todos os Status</option>
                <option value="active">Ativas</option>
                <option value="overdue">Em Atraso</option>
                <option value="cancelled">Canceladas</option>
                <option value="pending">Pendentes</option>
              </select>
              <Button variant="outline" size="sm">
                <Download className="h-4 w-4 mr-2" />
                Exportar
              </Button>
            </div>
          </div>

          {/* Subscriptions List */}
          <div className="space-y-4">
            {filteredSubscriptions.map((subscription) => {
              const StatusIcon = statusIcons[subscription.status as keyof typeof statusIcons]
              return (
                <div
                  key={subscription.id}
                  className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
                >
                  <div className="flex items-center space-x-4">
                    <Avatar className="h-10 w-10">
                      <AvatarImage src={subscription.users.avatar_url || ""} />
                      <AvatarFallback>
                        {subscription.users.name
                          ?.split(" ")
                          .map((n) => n[0])
                          .join("") || "U"}
                      </AvatarFallback>
                    </Avatar>

                    <div>
                      <p className="font-medium text-gray-900">{subscription.users.name || "Usuário"}</p>
                      <p className="text-sm text-gray-500">{subscription.users.email}</p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-4">
                    <div className="text-right">
                      <p className="font-medium text-gray-900">
                        {subscription.plan_id.charAt(0).toUpperCase() + subscription.plan_id.slice(1)}
                      </p>
                      <p className="text-sm text-gray-500">R$ {subscription.amount.toFixed(2)}/mês</p>
                    </div>

                    <Badge
                      className={`${statusColors[subscription.status as keyof typeof statusColors]} flex items-center space-x-1`}
                    >
                      <StatusIcon className="h-3 w-3" />
                      <span className="capitalize">{subscription.status}</span>
                    </Badge>

                    <div className="text-right text-sm text-gray-500">
                      <p>Próximo: {new Date(subscription.next_due_date).toLocaleDateString("pt-BR")}</p>
                      {subscription.last_payment_date && (
                        <p>Último: {new Date(subscription.last_payment_date).toLocaleDateString("pt-BR")}</p>
                      )}
                    </div>

                    <Button variant="outline" size="sm">
                      Detalhes
                    </Button>
                  </div>
                </div>
              )
            })}
          </div>

          {filteredSubscriptions.length === 0 && (
            <div className="text-center py-8">
              <CreditCard className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500">Nenhuma assinatura encontrada</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
