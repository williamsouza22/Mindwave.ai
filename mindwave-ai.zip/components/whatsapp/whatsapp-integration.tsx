"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { MessageCircle, Sparkles, Heart, Clock, Shield } from "lucide-react"
import { useAnalytics } from "@/components/analytics/analytics-provider"
import { motion } from "framer-motion"

interface WhatsAppIntegrationProps {
  variant?: "primary" | "secondary" | "floating" | "cta"
  size?: "sm" | "md" | "lg"
  showBenefits?: boolean
  className?: string
}

export function WhatsAppIntegration({
  variant = "primary",
  size = "md",
  showBenefits = false,
  className = "",
}: WhatsAppIntegrationProps) {
  const [isHovered, setIsHovered] = useState(false)
  const { trackEvent } = useAnalytics()

  const whatsappNumber = process.env.NEXT_PUBLIC_WHATSAPP_NUMBER || "5511999999999"
  const welcomeMessage = encodeURIComponent(
    "Olá! 👋 Vim do site MindWave.AI e gostaria de começar minha jornada de bem-estar emocional. Pode me ajudar?",
  )

  const handleWhatsAppClick = () => {
    trackEvent("whatsapp_click", {
      variant,
      size,
      source: "whatsapp_integration_component",
    })

    // Send welcome message via API
    fetch("/api/whatsapp/send-welcome", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        action: "button_click",
        variant,
        timestamp: new Date().toISOString(),
      }),
    }).catch(console.error)

    // Open WhatsApp
    window.open(`https://wa.me/${whatsappNumber}?text=${welcomeMessage}`, "_blank")
  }

  const buttonSizes = {
    sm: "px-4 py-2 text-sm",
    md: "px-6 py-3 text-base",
    lg: "px-8 py-4 text-lg",
  }

  const iconSizes = {
    sm: "h-4 w-4",
    md: "h-5 w-5",
    lg: "h-6 w-6",
  }

  if (variant === "floating") {
    return (
      <motion.div
        className="fixed bottom-6 right-6 z-50"
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 2, duration: 0.5, type: "spring" }}
      >
        <Button
          onClick={handleWhatsAppClick}
          className="rounded-full bg-green-500 hover:bg-green-600 text-white shadow-lg hover:shadow-xl transition-all duration-300 p-4"
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
        >
          <MessageCircle className="h-6 w-6" />
          {isHovered && (
            <motion.span
              initial={{ width: 0, opacity: 0 }}
              animate={{ width: "auto", opacity: 1 }}
              className="ml-2 whitespace-nowrap"
            >
              Falar no WhatsApp
            </motion.span>
          )}
        </Button>

        {/* Pulse animation */}
        <div className="absolute inset-0 rounded-full bg-green-500 animate-ping opacity-20" />
      </motion.div>
    )
  }

  if (variant === "cta") {
    return (
      <div className={`bg-gradient-to-r from-green-500 to-emerald-600 rounded-2xl p-6 text-white ${className}`}>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            <MessageCircle className="h-8 w-8" />
            <div>
              <h3 className="text-xl font-bold">Comece Agora no WhatsApp</h3>
              <p className="text-green-100">Apoio emocional 24/7 na palma da sua mão</p>
            </div>
          </div>
          <Badge className="bg-white/20 text-white border-white/30">Gratuito</Badge>
        </div>

        {showBenefits && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div className="flex items-center space-x-2">
              <Clock className="h-5 w-5 text-green-200" />
              <span className="text-sm">Resposta em segundos</span>
            </div>
            <div className="flex items-center space-x-2">
              <Heart className="h-5 w-5 text-green-200" />
              <span className="text-sm">IA empática</span>
            </div>
            <div className="flex items-center space-x-2">
              <Shield className="h-5 w-5 text-green-200" />
              <span className="text-sm">100% privado</span>
            </div>
          </div>
        )}

        <Button
          onClick={handleWhatsAppClick}
          className="w-full bg-white text-green-600 hover:bg-gray-100 font-semibold py-3"
        >
          <MessageCircle className="h-5 w-5 mr-2" />
          Iniciar Conversa Gratuita
          <Sparkles className="h-4 w-4 ml-2" />
        </Button>
      </div>
    )
  }

  return (
    <Button
      onClick={handleWhatsAppClick}
      className={`
        ${
          variant === "primary"
            ? "bg-green-500 hover:bg-green-600 text-white"
            : "bg-white text-green-600 border-2 border-green-500 hover:bg-green-50"
        }
        ${buttonSizes[size]}
        font-semibold transition-all duration-300 shadow-lg hover:shadow-xl
        ${className}
      `}
    >
      <MessageCircle className={`${iconSizes[size]} mr-2`} />
      Testar no WhatsApp
      {variant === "primary" && <Sparkles className="h-4 w-4 ml-2" />}
    </Button>
  )
}
