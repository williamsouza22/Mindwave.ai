"use client"

import type React from "react"

import { useState } from "react"
import { motion } from "framer-motion"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { useAuth } from "@/lib/auth/auth-context"
import { useToast } from "@/hooks/use-toast"
import { createClient } from "@/lib/supabase/client"
import { Download, Upload, Shield, Calendar, Database, CheckCircle, AlertTriangle } from "lucide-react"

interface BackupData {
  user_profile: any
  mood_entries: any[]
  chat_messages: any[]
  notifications: any[]
  analytics_events: any[]
  created_at: string
}

export function BackupManager() {
  const [isExporting, setIsExporting] = useState(false)
  const [isImporting, setIsImporting] = useState(false)
  const [lastBackup, setLastBackup] = useState<Date | null>(null)
  const { user, profile } = useAuth()
  const { toast } = useToast()
  const supabase = createClient()

  const exportData = async () => {
    if (!user) return

    setIsExporting(true)

    try {
      // Fetch all user data
      const [{ data: moodEntries }, { data: chatMessages }, { data: notifications }, { data: analyticsEvents }] =
        await Promise.all([
          supabase.from("mood_entries").select("*").eq("user_id", user.id),
          supabase.from("chat_messages").select("*").eq("user_id", user.id),
          supabase.from("notifications").select("*").eq("user_id", user.id),
          supabase.from("analytics_events").select("*").eq("user_id", user.id),
        ])

      const backupData: BackupData = {
        user_profile: profile,
        mood_entries: moodEntries || [],
        chat_messages: chatMessages || [],
        notifications: notifications || [],
        analytics_events: analyticsEvents || [],
        created_at: new Date().toISOString(),
      }

      // Create and download file
      const blob = new Blob([JSON.stringify(backupData, null, 2)], {
        type: "application/json",
      })
      const url = URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = `mindwave-backup-${new Date().toISOString().split("T")[0]}.json`
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(url)

      setLastBackup(new Date())

      toast({
        title: "Backup criado com sucesso! 📦",
        description: "Seus dados foram exportados com segurança.",
      })

      // Track backup event
      await supabase.from("analytics_events").insert({
        user_id: user.id,
        event_name: "data_backup_created",
        properties: {
          timestamp: new Date().toISOString(),
          data_types: ["mood_entries", "chat_messages", "notifications", "analytics_events"],
          total_records: (moodEntries?.length || 0) + (chatMessages?.length || 0) + (notifications?.length || 0),
        },
      })
    } catch (error) {
      console.error("Export error:", error)
      toast({
        title: "Erro no backup",
        description: "Não foi possível criar o backup. Tente novamente.",
        variant: "destructive",
      })
    } finally {
      setIsExporting(false)
    }
  }

  const importData = async (file: File) => {
    if (!user) return

    setIsImporting(true)

    try {
      const text = await file.text()
      const backupData: BackupData = JSON.parse(text)

      // Validate backup data
      if (!backupData.user_profile || !Array.isArray(backupData.mood_entries)) {
        throw new Error("Invalid backup file format")
      }

      // Import mood entries
      if (backupData.mood_entries.length > 0) {
        const moodEntries = backupData.mood_entries.map((entry) => ({
          user_id: user.id,
          mood_score: entry.mood_score,
          note: entry.note,
          tags: entry.tags,
          created_at: entry.created_at,
        }))

        await supabase.from("mood_entries").upsert(moodEntries)
      }

      // Import chat messages
      if (backupData.chat_messages.length > 0) {
        const chatMessages = backupData.chat_messages.map((message) => ({
          user_id: user.id,
          content: message.content,
          sender: message.sender,
          message_type: message.message_type,
          created_at: message.created_at,
        }))

        await supabase.from("chat_messages").upsert(chatMessages)
      }

      toast({
        title: "Dados restaurados com sucesso! 🎉",
        description: "Seu backup foi importado com segurança.",
      })

      // Track import event
      await supabase.from("analytics_events").insert({
        user_id: user.id,
        event_name: "data_backup_restored",
        properties: {
          timestamp: new Date().toISOString(),
          backup_date: backupData.created_at,
          restored_records: backupData.mood_entries.length + backupData.chat_messages.length,
        },
      })
    } catch (error) {
      console.error("Import error:", error)
      toast({
        title: "Erro na restauração",
        description: "Não foi possível importar o backup. Verifique o arquivo.",
        variant: "destructive",
      })
    } finally {
      setIsImporting(false)
    }
  }

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      importData(file)
    }
  }

  const scheduleAutoBackup = async () => {
    try {
      await supabase.from("user_settings").upsert({
        user_id: user?.id,
        setting_key: "auto_backup",
        setting_value: { enabled: true, frequency: "weekly" },
      })

      toast({
        title: "Backup automático ativado! ⚡",
        description: "Seus dados serão salvos automaticamente toda semana.",
      })
    } catch (error) {
      toast({
        title: "Erro ao ativar backup automático",
        description: "Tente novamente em alguns instantes.",
        variant: "destructive",
      })
    }
  }

  return (
    <Card className="bg-[#1A2332] border-gray-800">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Shield className="h-5 w-5 text-green-400" />
          <span className="text-white">Backup & Restauração</span>
        </CardTitle>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Backup Status */}
        <div className="flex items-center justify-between p-4 bg-gray-800/50 rounded-lg">
          <div className="flex items-center space-x-3">
            <Database className="h-5 w-5 text-blue-400" />
            <div>
              <p className="text-sm font-medium text-white">Status do Backup</p>
              <p className="text-xs text-gray-400">
                {lastBackup ? `Último backup: ${lastBackup.toLocaleDateString()}` : "Nenhum backup criado ainda"}
              </p>
            </div>
          </div>
          <Badge
            variant="secondary"
            className={
              lastBackup
                ? "bg-green-900/50 text-green-300 border-green-800"
                : "bg-yellow-900/50 text-yellow-300 border-yellow-800"
            }
          >
            {lastBackup ? (
              <>
                <CheckCircle className="h-3 w-3 mr-1" />
                Atualizado
              </>
            ) : (
              <>
                <AlertTriangle className="h-3 w-3 mr-1" />
                Pendente
              </>
            )}
          </Badge>
        </div>

        {/* Export Data */}
        <div className="space-y-3">
          <h4 className="font-medium text-white">Exportar Dados</h4>
          <p className="text-sm text-gray-400">Baixe uma cópia completa dos seus dados para manter em segurança.</p>
          <Button
            onClick={exportData}
            disabled={isExporting}
            className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
          >
            {isExporting ? (
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 1, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
              >
                <Download className="h-4 w-4 mr-2" />
              </motion.div>
            ) : (
              <Download className="h-4 w-4 mr-2" />
            )}
            {isExporting ? "Criando backup..." : "Criar Backup"}
          </Button>
        </div>

        {/* Import Data */}
        <div className="space-y-3">
          <h4 className="font-medium text-white">Restaurar Dados</h4>
          <p className="text-sm text-gray-400">Importe um backup anterior para restaurar seus dados.</p>
          <div className="relative">
            <input
              type="file"
              accept=".json"
              onChange={handleFileUpload}
              disabled={isImporting}
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
            />
            <Button
              disabled={isImporting}
              variant="outline"
              className="w-full bg-transparent border-gray-700 text-gray-300 hover:bg-gray-800"
            >
              {isImporting ? (
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 1, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
                >
                  <Upload className="h-4 w-4 mr-2" />
                </motion.div>
              ) : (
                <Upload className="h-4 w-4 mr-2" />
              )}
              {isImporting ? "Restaurando..." : "Selecionar Arquivo"}
            </Button>
          </div>
        </div>

        {/* Auto Backup */}
        <div className="space-y-3 pt-4 border-t border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-medium text-white">Backup Automático</h4>
              <p className="text-sm text-gray-400">Salve seus dados automaticamente</p>
            </div>
            <Button
              onClick={scheduleAutoBackup}
              variant="outline"
              size="sm"
              className="bg-transparent border-green-700 text-green-400 hover:bg-green-900/20"
            >
              <Calendar className="h-4 w-4 mr-2" />
              Ativar
            </Button>
          </div>
        </div>

        {/* Data Types */}
        <div className="space-y-3">
          <h4 className="font-medium text-white">Dados Incluídos no Backup</h4>
          <div className="grid grid-cols-2 gap-2">
            <div className="flex items-center space-x-2 text-sm text-gray-400">
              <CheckCircle className="h-3 w-3 text-green-400" />
              <span>Perfil do usuário</span>
            </div>
            <div className="flex items-center space-x-2 text-sm text-gray-400">
              <CheckCircle className="h-3 w-3 text-green-400" />
              <span>Registros de humor</span>
            </div>
            <div className="flex items-center space-x-2 text-sm text-gray-400">
              <CheckCircle className="h-3 w-3 text-green-400" />
              <span>Conversas com IA</span>
            </div>
            <div className="flex items-center space-x-2 text-sm text-gray-400">
              <CheckCircle className="h-3 w-3 text-green-400" />
              <span>Notificações</span>
            </div>
          </div>
        </div>

        {/* Security Notice */}
        <div className="p-3 bg-blue-900/20 rounded-lg border border-blue-800">
          <div className="flex items-start space-x-2">
            <Shield className="h-4 w-4 text-blue-400 mt-0.5" />
            <div>
              <p className="text-xs text-blue-300 font-medium">Segurança Garantida</p>
              <p className="text-xs text-blue-200">
                Todos os backups são criptografados e mantidos seguros. Seus dados pessoais nunca são compartilhados.
              </p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
