"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Trophy, Star, Target, Calendar, Heart, Brain, Flame, Crown, Medal, Award } from "lucide-react"
import { createClient } from "@/lib/supabase/client"
import { useAuth } from "@/lib/auth/auth-context"

interface Achievement {
  id: string
  name: string
  description: string
  icon: string
  category: string
  requirement: number
  current_progress: number
  unlocked: boolean
  unlocked_at?: string
  rarity: "common" | "rare" | "epic" | "legendary"
}

const achievementIcons = {
  trophy: Trophy,
  star: Star,
  target: Target,
  calendar: Calendar,
  heart: Heart,
  brain: Brain,
  flame: Flame,
  crown: Crown,
  medal: Medal,
  award: Award,
}

const rarityColors = {
  common: "bg-gray-100 text-gray-800 border-gray-300",
  rare: "bg-blue-100 text-blue-800 border-blue-300",
  epic: "bg-purple-100 text-purple-800 border-purple-300",
  legendary: "bg-yellow-100 text-yellow-800 border-yellow-300",
}

const rarityGlow = {
  common: "",
  rare: "shadow-blue-200",
  epic: "shadow-purple-200",
  legendary: "shadow-yellow-200",
}

export function AchievementSystem() {
  const [achievements, setAchievements] = useState<Achievement[]>([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState("all")
  const { user } = useAuth()
  const supabase = createClient()

  useEffect(() => {
    if (user) {
      loadAchievements()
    }
  }, [user])

  const loadAchievements = async () => {
    try {
      const { data, error } = await supabase
        .from("user_achievements")
        .select(`
          *,
          achievements (
            name,
            description,
            icon,
            category,
            requirement,
            rarity
          )
        `)
        .eq("user_id", user?.id)

      if (error) throw error

      const formattedAchievements: Achievement[] = data.map((item: any) => ({
        id: item.achievement_id,
        name: item.achievements.name,
        description: item.achievements.description,
        icon: item.achievements.icon,
        category: item.achievements.category,
        requirement: item.achievements.requirement,
        current_progress: item.current_progress,
        unlocked: item.unlocked,
        unlocked_at: item.unlocked_at,
        rarity: item.achievements.rarity,
      }))

      setAchievements(formattedAchievements)
    } catch (error) {
      console.error("Error loading achievements:", error)
    } finally {
      setLoading(false)
    }
  }

  const filteredAchievements = achievements.filter((achievement) => {
    if (filter === "all") return true
    if (filter === "unlocked") return achievement.unlocked
    if (filter === "locked") return !achievement.unlocked
    return achievement.category === filter
  })

  const stats = {
    total: achievements.length,
    unlocked: achievements.filter((a) => a.unlocked).length,
    progress: achievements.length > 0 ? (achievements.filter((a) => a.unlocked).length / achievements.length) * 100 : 0,
  }

  const categories = [...new Set(achievements.map((a) => a.category))]

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-gray-200 rounded w-1/4"></div>
            <div className="space-y-2">
              <div className="h-4 bg-gray-200 rounded"></div>
              <div className="h-4 bg-gray-200 rounded w-5/6"></div>
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      {/* Stats Overview */}
      <Card className="bg-gradient-to-r from-purple-50 to-blue-50 border-purple-200">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Trophy className="h-6 w-6 text-yellow-500" />
            <span>Suas Conquistas</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-600 mb-1">{stats.unlocked}</div>
              <div className="text-sm text-gray-600">Conquistas Desbloqueadas</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600 mb-1">{stats.total}</div>
              <div className="text-sm text-gray-600">Total Disponível</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-green-600 mb-1">{stats.progress.toFixed(0)}%</div>
              <div className="text-sm text-gray-600">Progresso Geral</div>
            </div>
          </div>

          <div className="mt-6">
            <div className="flex justify-between text-sm text-gray-600 mb-2">
              <span>Progresso Geral</span>
              <span>
                {stats.unlocked}/{stats.total}
              </span>
            </div>
            <Progress value={stats.progress} className="h-3" />
          </div>
        </CardContent>
      </Card>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-wrap gap-2">
            <Badge
              variant={filter === "all" ? "default" : "outline"}
              className="cursor-pointer"
              onClick={() => setFilter("all")}
            >
              Todas
            </Badge>
            <Badge
              variant={filter === "unlocked" ? "default" : "outline"}
              className="cursor-pointer"
              onClick={() => setFilter("unlocked")}
            >
              Desbloqueadas
            </Badge>
            <Badge
              variant={filter === "locked" ? "default" : "outline"}
              className="cursor-pointer"
              onClick={() => setFilter("locked")}
            >
              Bloqueadas
            </Badge>
            {categories.map((category) => (
              <Badge
                key={category}
                variant={filter === category ? "default" : "outline"}
                className="cursor-pointer"
                onClick={() => setFilter(category)}
              >
                {category}
              </Badge>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Achievements Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredAchievements.map((achievement) => {
          const IconComponent = achievementIcons[achievement.icon as keyof typeof achievementIcons] || Trophy
          const progressPercentage = (achievement.current_progress / achievement.requirement) * 100

          return (
            <motion.div
              key={achievement.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              whileHover={{ scale: 1.02 }}
              className={`${achievement.unlocked ? rarityGlow[achievement.rarity] : ""}`}
            >
              <Card className={`${achievement.unlocked ? "border-2" : "opacity-75"} transition-all duration-300`}>
                <CardContent className="p-6">
                  <div className="flex items-start space-x-4">
                    <div
                      className={`p-3 rounded-full ${
                        achievement.unlocked ? "bg-gradient-to-r from-yellow-400 to-orange-500" : "bg-gray-200"
                      }`}
                    >
                      <IconComponent className={`h-6 w-6 ${achievement.unlocked ? "text-white" : "text-gray-400"}`} />
                    </div>

                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className={`font-semibold ${achievement.unlocked ? "text-gray-900" : "text-gray-500"}`}>
                          {achievement.name}
                        </h3>
                        <Badge className={rarityColors[achievement.rarity]}>{achievement.rarity}</Badge>
                      </div>

                      <p className={`text-sm mb-3 ${achievement.unlocked ? "text-gray-600" : "text-gray-400"}`}>
                        {achievement.description}
                      </p>

                      {achievement.unlocked ? (
                        <div className="flex items-center space-x-2">
                          <Badge variant="secondary" className="bg-green-100 text-green-800">
                            ✓ Desbloqueada
                          </Badge>
                          {achievement.unlocked_at && (
                            <span className="text-xs text-gray-500">
                              {new Date(achievement.unlocked_at).toLocaleDateString("pt-BR")}
                            </span>
                          )}
                        </div>
                      ) : (
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span className="text-gray-600">Progresso</span>
                            <span className="text-gray-600">
                              {achievement.current_progress}/{achievement.requirement}
                            </span>
                          </div>
                          <Progress value={progressPercentage} className="h-2" />
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )
        })}
      </div>

      {filteredAchievements.length === 0 && (
        <Card>
          <CardContent className="p-12 text-center">
            <Trophy className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-500">Nenhuma conquista encontrada</p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
