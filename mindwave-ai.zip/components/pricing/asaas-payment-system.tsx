"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Label } from "@/components/ui/label"
import { CreditCard, QrCode, Receipt, Check, Loader2, Copy, ExternalLink } from "lucide-react"
import { useAuth } from "@/lib/auth/auth-context"
import { useAnalytics } from "@/components/analytics/analytics-provider"
import { useToast } from "@/hooks/use-toast"
import { motion } from "framer-motion"

interface Plan {
  id: string
  name: string
  price: number
  originalPrice?: number
  features: string[]
  popular?: boolean
  description: string
}

const plans: Plan[] = [
  {
    id: "premium",
    name: "Premium",
    price: 29.9,
    originalPrice: 49.9,
    description: "Perfeito para uso individual",
    popular: true,
    features: [
      "Chat IA ilimitado 24/7",
      "Todos os módulos desbloqueados",
      "Detox Digital personalizado",
      "Fitoterapia com receitas",
      "Exercícios personalizados",
      "Relatórios detalhados",
      "Suporte prioritário",
      "Sem anúncios",
    ],
  },
  {
    id: "family",
    name: "Família",
    price: 79.9,
    originalPrice: 129.9,
    description: "Para toda a família (até 5 pessoas)",
    features: [
      "Tudo do Premium",
      "Até 5 contas familiares",
      "Dashboard familiar",
      "Controle parental",
      "Relatórios familiares",
      "Sessões em grupo",
      "Suporte 24/7 dedicado",
      "Desconto em consultas",
    ],
  },
]

const paymentMethods = [
  {
    id: "PIX",
    name: "PIX",
    icon: QrCode,
    description: "Pagamento instantâneo",
    discount: 10,
    processingTime: "Imediato",
  },
  {
    id: "CREDIT_CARD",
    name: "Cartão de Crédito",
    icon: CreditCard,
    description: "Parcelamento disponível",
    discount: 0,
    processingTime: "1-2 dias úteis",
  },
  {
    id: "BOLETO",
    name: "Boleto Bancário",
    icon: Receipt,
    description: "Vencimento em 3 dias úteis",
    discount: 5,
    processingTime: "1-3 dias úteis",
  },
]

interface PaymentData {
  subscriptionId: string
  paymentId: string
  paymentUrl?: string
  pixCode?: string
  pixQrCode?: string
  boletoUrl?: string
}

export function AsaasPaymentSystem() {
  const [selectedPlan, setSelectedPlan] = useState<string>("premium")
  const [selectedPayment, setSelectedPayment] = useState<string>("PIX")
  const [loading, setLoading] = useState(false)
  const [paymentData, setPaymentData] = useState<PaymentData | null>(null)
  const [step, setStep] = useState<"selection" | "payment" | "success">("selection")

  const { user } = useAuth()
  const { trackEvent } = useAnalytics()
  const { toast } = useToast()

  const currentPlan = plans.find((p) => p.id === selectedPlan)!
  const currentPaymentMethod = paymentMethods.find((p) => p.id === selectedPayment)!

  const finalPrice = currentPlan.price * (1 - currentPaymentMethod.discount / 100)
  const savings = currentPlan.originalPrice ? currentPlan.originalPrice - finalPrice : 0

  const handleCreateSubscription = async () => {
    if (!user) {
      toast({
        title: "Login necessário",
        description: "Faça login para continuar com a assinatura.",
        variant: "destructive",
      })
      return
    }

    setLoading(true)
    trackEvent("subscription_attempt", {
      plan: selectedPlan,
      payment_method: selectedPayment,
      price: finalPrice,
    })

    try {
      const response = await fetch("/api/asaas/create-subscription", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          planId: selectedPlan,
          billingType: selectedPayment,
        }),
      })

      if (!response.ok) {
        throw new Error("Falha ao criar assinatura")
      }

      const data: PaymentData = await response.json()
      setPaymentData(data)
      setStep("payment")

      trackEvent("subscription_created", {
        plan: selectedPlan,
        payment_method: selectedPayment,
        subscription_id: data.subscriptionId,
      })

      toast({
        title: "Assinatura criada com sucesso!",
        description: "Complete o pagamento para ativar sua conta Premium.",
      })
    } catch (error) {
      console.error("Erro ao criar assinatura:", error)
      toast({
        title: "Erro ao processar pagamento",
        description: "Tente novamente em alguns instantes.",
        variant: "destructive",
      })

      trackEvent("subscription_error", {
        plan: selectedPlan,
        payment_method: selectedPayment,
        error: error instanceof Error ? error.message : "Unknown error",
      })
    } finally {
      setLoading(false)
    }
  }

  const copyPixCode = async () => {
    if (paymentData?.pixCode) {
      await navigator.clipboard.writeText(paymentData.pixCode)
      toast({
        title: "Código PIX copiado!",
        description: "Cole no seu app do banco para finalizar o pagamento.",
      })
      trackEvent("pix_code_copied", {
        subscription_id: paymentData.subscriptionId,
      })
    }
  }

  const openPaymentUrl = () => {
    if (paymentData?.paymentUrl) {
      window.open(paymentData.paymentUrl, "_blank")
      trackEvent("payment_url_opened", {
        subscription_id: paymentData.subscriptionId,
        payment_method: selectedPayment,
      })
    }
  }

  if (step === "payment" && paymentData) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-2xl mx-auto space-y-6"
      >
        <Card className="bg-slate-800/50 border-purple-500/20">
          <CardHeader className="text-center">
            <CardTitle className="flex items-center justify-center space-x-2 text-2xl">
              {selectedPayment === "PIX" && <QrCode className="h-6 w-6 text-green-500" />}
              {selectedPayment === "CREDIT_CARD" && <CreditCard className="h-6 w-6 text-blue-500" />}
              {selectedPayment === "BOLETO" && <Receipt className="h-6 w-6 text-orange-500" />}
              <span>Finalize seu Pagamento</span>
            </CardTitle>
            <p className="text-gray-400">
              Plano {currentPlan.name} - R$ {finalPrice.toFixed(2)}/mês
            </p>
          </CardHeader>
          <CardContent className="space-y-6">
            {selectedPayment === "PIX" && paymentData.pixCode && (
              <>
                {paymentData.pixQrCode && (
                  <div className="text-center">
                    <img
                      src={`data:image/png;base64,${paymentData.pixQrCode}`}
                      alt="QR Code PIX"
                      className="mx-auto w-64 h-64 border rounded-lg bg-white p-4"
                    />
                    <p className="text-sm text-gray-400 mt-2">Escaneie com o app do seu banco</p>
                  </div>
                )}

                <div className="space-y-3">
                  <Label className="text-white">Ou copie o código PIX:</Label>
                  <div className="flex space-x-2">
                    <input
                      type="text"
                      value={paymentData.pixCode}
                      readOnly
                      className="flex-1 p-3 bg-slate-700 border border-slate-600 rounded-lg text-white text-sm"
                    />
                    <Button onClick={copyPixCode} variant="outline">
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <h4 className="font-medium text-green-800 mb-2">Como pagar com PIX:</h4>
                  <ol className="text-sm text-green-700 space-y-1 list-decimal list-inside">
                    <li>Abra o app do seu banco</li>
                    <li>Escolha a opção PIX</li>
                    <li>Escaneie o QR Code ou cole o código</li>
                    <li>Confirme o pagamento de R$ {finalPrice.toFixed(2)}</li>
                  </ol>
                </div>
              </>
            )}

            {(selectedPayment === "CREDIT_CARD" || selectedPayment === "BOLETO") && paymentData.paymentUrl && (
              <div className="text-center space-y-4">
                <div className="bg-slate-700 rounded-lg p-8">
                  <div className="text-6xl mb-4">{selectedPayment === "CREDIT_CARD" ? "💳" : "📄"}</div>
                  <h3 className="text-xl font-semibold text-white mb-2">
                    {selectedPayment === "CREDIT_CARD" ? "Pagamento com Cartão" : "Boleto Bancário"}
                  </h3>
                  <p className="text-gray-400 mb-4">Clique no botão abaixo para finalizar seu pagamento</p>
                  <Button onClick={openPaymentUrl} className="bg-purple-600 hover:bg-purple-700">
                    <ExternalLink className="h-4 w-4 mr-2" />
                    Finalizar Pagamento
                  </Button>
                </div>
              </div>
            )}

            <div className="flex items-center justify-center space-x-2 text-orange-400">
              <Loader2 className="h-4 w-4 animate-spin" />
              <span className="text-sm">Aguardando confirmação do pagamento...</span>
            </div>

            <div className="flex space-x-3">
              <Button variant="outline" onClick={() => setStep("selection")} className="flex-1">
                Voltar
              </Button>
              <Button
                onClick={() => (window.location.href = "/dashboard")}
                className="flex-1 bg-purple-600 hover:bg-purple-700"
              >
                Ir para Dashboard
              </Button>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    )
  }

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      {/* Plan Selection */}
      <div className="text-center space-y-4">
        <h2 className="text-3xl font-bold text-white">Escolha seu Plano Premium</h2>
        <p className="text-gray-400 text-lg">Desbloqueie todo o potencial do MindWave.AI</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {plans.map((plan) => (
          <motion.div
            key={plan.id}
            whileHover={{ scale: 1.02 }}
            className={`relative ${selectedPlan === plan.id ? "ring-2 ring-purple-500" : ""}`}
          >
            <Card
              className={`
              h-full cursor-pointer transition-all duration-300
              ${
                selectedPlan === plan.id
                  ? "bg-gradient-to-br from-purple-900/50 to-pink-900/50 border-purple-500"
                  : "bg-slate-800/50 border-slate-700 hover:border-purple-500/50"
              }
            `}
            >
              {/* Plan Content */}
              <CardHeader>
                <CardTitle>{plan.name}</CardTitle>
                {plan.popular && <Badge className="bg-purple-500 text-white">Popular</Badge>}
              </CardHeader>
              <CardContent>
                <p className="text-gray-400 mb-4">{plan.description}</p>
                <p className="text-2xl font-bold text-white mb-4">R$ {plan.price.toFixed(2)}/mês</p>
                {plan.originalPrice && (
                  <p className="text-sm text-gray-400 mb-4">Economize R$ {savings.toFixed(2)} com o pagamento PIX</p>
                )}
                <ul className="space-y-2 mb-4">
                  {plan.features.map((feature, index) => (
                    <li key={index} className="flex items-center space-x-2">
                      <Check className="h-4 w-4 text-green-500" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
                <Button onClick={() => setSelectedPlan(plan.id)} className="bg-purple-600 hover:bg-purple-700">
                  Selecionar Plano
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Payment Method Selection */}
      <div className="text-center space-y-4">
        <h2 className="text-3xl font-bold text-white">Escolha seu Método de Pagamento</h2>
        <p className="text-gray-400 text-lg">Finalize sua assinatura com o método mais conveniente para você</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {paymentMethods.map((method) => (
          <motion.div
            key={method.id}
            whileHover={{ scale: 1.02 }}
            className={`relative ${selectedPayment === method.id ? "ring-2 ring-purple-500" : ""}`}
          >
            <Card
              className={`
              h-full cursor-pointer transition-all duration-300
              ${
                selectedPayment === method.id
                  ? "bg-gradient-to-br from-purple-900/50 to-pink-900/50 border-purple-500"
                  : "bg-slate-800/50 border-slate-700 hover:border-purple-500/50"
              }
            `}
            >
              <CardHeader>
                <CardTitle>{method.name}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-400 mb-4">{method.description}</p>
                <p className="text-sm text-gray-400 mb-4">Tempo de processamento: {method.processingTime}</p>
                <Button onClick={() => setSelectedPayment(method.id)} className="bg-purple-600 hover:bg-purple-700">
                  Selecionar Método
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Create Subscription Button */}
      <div className="text-center">
        <Button onClick={handleCreateSubscription} className="bg-purple-600 hover:bg-purple-700">
          {loading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <span>Finalizar Assinatura</span>}
        </Button>
      </div>
    </div>
  )
}
