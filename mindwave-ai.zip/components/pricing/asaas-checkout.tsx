"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { CreditCard, Smartphone, QrCode, Check, Loader2, Shield, Clock } from "lucide-react"
import { useAuth } from "@/lib/auth/auth-context"
import { useToast } from "@/hooks/use-toast"

interface AsaasCheckoutProps {
  planId: string
  planName: string
  planPrice: number
  planFeatures: string[]
  onClose: () => void
}

export function AsaasCheckout({ planId, planName, planPrice, planFeatures, onClose }: AsaasCheckoutProps) {
  const [billingType, setBillingType] = useState("PIX")
  const [loading, setLoading] = useState(false)
  const [paymentData, setPaymentData] = useState<any>(null)
  const { user } = useAuth()
  const { toast } = useToast()

  const billingOptions = [
    {
      value: "PIX",
      label: "PIX",
      icon: QrCode,
      description: "Pagamento instantâneo",
      discount: 5,
    },
    {
      value: "CREDIT_CARD",
      label: "Cartão de Crédito",
      icon: CreditCard,
      description: "Parcelamento disponível",
      discount: 0,
    },
    {
      value: "BOLETO",
      label: "Boleto Bancário",
      icon: Smartphone,
      description: "Vencimento em 3 dias úteis",
      discount: 0,
    },
  ]

  const selectedOption = billingOptions.find((option) => option.value === billingType)
  const finalPrice = selectedOption?.discount ? planPrice * (1 - selectedOption.discount / 100) : planPrice

  const handleCreateSubscription = async () => {
    if (!user) {
      toast({
        title: "Erro",
        description: "Você precisa estar logado para assinar um plano.",
        variant: "destructive",
      })
      return
    }

    setLoading(true)

    try {
      const response = await fetch("/api/asaas/create-subscription", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          planId,
          billingType,
        }),
      })

      if (!response.ok) {
        throw new Error("Falha ao criar assinatura")
      }

      const data = await response.json()
      setPaymentData(data)

      if (billingType === "PIX") {
        toast({
          title: "PIX gerado com sucesso! 🎉",
          description: "Escaneie o QR Code ou copie o código PIX para finalizar o pagamento.",
        })
      } else {
        // Redirect to payment URL for other methods
        window.open(data.paymentUrl, "_blank")
      }
    } catch (error) {
      console.error("Error creating subscription:", error)
      toast({
        title: "Erro ao processar pagamento",
        description: "Tente novamente em alguns instantes.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const copyPixCode = () => {
    if (paymentData?.pixCode) {
      navigator.clipboard.writeText(paymentData.pixCode)
      toast({
        title: "Código PIX copiado!",
        description: "Cole no seu app do banco para finalizar o pagamento.",
      })
    }
  }

  if (paymentData && billingType === "PIX") {
    return (
      <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="space-y-6">
        <Card className="bg-gradient-to-r from-green-50 to-blue-50 border-green-200">
          <CardHeader className="text-center">
            <CardTitle className="flex items-center justify-center space-x-2">
              <QrCode className="h-6 w-6 text-green-600" />
              <span>PIX Gerado com Sucesso!</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* QR Code */}
            {paymentData.pixQrCode && (
              <div className="text-center">
                <img
                  src={`data:image/png;base64,${paymentData.pixQrCode}`}
                  alt="QR Code PIX"
                  className="mx-auto w-48 h-48 border rounded-lg"
                />
                <p className="text-sm text-gray-600 mt-2">Escaneie com o app do seu banco</p>
              </div>
            )}

            {/* PIX Code */}
            <div className="space-y-2">
              <Label>Ou copie o código PIX:</Label>
              <div className="flex space-x-2">
                <input
                  type="text"
                  value={paymentData.pixCode || ""}
                  readOnly
                  className="flex-1 p-2 border rounded text-sm bg-gray-50"
                />
                <Button onClick={copyPixCode} variant="outline">
                  Copiar
                </Button>
              </div>
            </div>

            {/* Instructions */}
            <div className="bg-blue-50 p-4 rounded-lg">
              <h4 className="font-medium text-blue-900 mb-2">Como pagar:</h4>
              <ol className="text-sm text-blue-800 space-y-1">
                <li>1. Abra o app do seu banco</li>
                <li>2. Escolha a opção PIX</li>
                <li>3. Escaneie o QR Code ou cole o código</li>
                <li>4. Confirme o pagamento</li>
              </ol>
            </div>

            {/* Status */}
            <div className="flex items-center justify-center space-x-2 text-orange-600">
              <Clock className="h-4 w-4" />
              <span className="text-sm">Aguardando pagamento...</span>
            </div>

            <div className="flex space-x-2">
              <Button onClick={onClose} variant="outline" className="flex-1 bg-transparent">
                Fechar
              </Button>
              <Button onClick={() => (window.location.href = "/dashboard")} className="flex-1">
                Ir para Dashboard
              </Button>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    )
  }

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
      {/* Plan Summary */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Resumo do Plano</span>
            <Badge variant="secondary">{planName}</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span>Plano {planName}</span>
              <span className="font-medium">R$ {planPrice.toFixed(2)}/mês</span>
            </div>

            {selectedOption?.discount && selectedOption.discount > 0 && (
              <div className="flex justify-between items-center text-green-600">
                <span>Desconto {selectedOption.discount}% (PIX)</span>
                <span>-R$ {((planPrice * selectedOption.discount) / 100).toFixed(2)}</span>
              </div>
            )}

            <div className="border-t pt-4">
              <div className="flex justify-between items-center font-bold">
                <span>Total</span>
                <span>R$ {finalPrice.toFixed(2)}/mês</span>
              </div>
            </div>

            <div className="space-y-2">
              <h4 className="font-medium">Recursos inclusos:</h4>
              <ul className="space-y-1">
                {planFeatures.map((feature, index) => (
                  <li key={index} className="flex items-center space-x-2 text-sm">
                    <Check className="h-4 w-4 text-green-500" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Payment Method */}
      <Card>
        <CardHeader>
          <CardTitle>Forma de Pagamento</CardTitle>
        </CardHeader>
        <CardContent>
          <RadioGroup value={billingType} onValueChange={setBillingType}>
            {billingOptions.map((option) => {
              const Icon = option.icon
              return (
                <div key={option.value} className="flex items-center space-x-2 p-3 border rounded-lg hover:bg-gray-50">
                  <RadioGroupItem value={option.value} id={option.value} />
                  <Label htmlFor={option.value} className="flex-1 cursor-pointer">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <Icon className="h-5 w-5 text-gray-600" />
                        <div>
                          <p className="font-medium">{option.label}</p>
                          <p className="text-sm text-gray-500">{option.description}</p>
                        </div>
                      </div>
                      {option.discount > 0 && (
                        <Badge variant="secondary" className="bg-green-100 text-green-800">
                          -{option.discount}%
                        </Badge>
                      )}
                    </div>
                  </Label>
                </div>
              )
            })}
          </RadioGroup>
        </CardContent>
      </Card>

      {/* Security Notice */}
      <Card className="bg-blue-50 border-blue-200">
        <CardContent className="p-4">
          <div className="flex items-start space-x-3">
            <Shield className="h-5 w-5 text-blue-600 mt-0.5" />
            <div>
              <p className="font-medium text-blue-900">Pagamento Seguro</p>
              <p className="text-sm text-blue-800">
                Seus dados estão protegidos com criptografia SSL. Processamento via Asaas, empresa certificada pelo
                Banco Central.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Action Buttons */}
      <div className="flex space-x-4">
        <Button onClick={onClose} variant="outline" className="flex-1 bg-transparent">
          Cancelar
        </Button>
        <Button onClick={handleCreateSubscription} disabled={loading} className="flex-1">
          {loading ? (
            <>
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              Processando...
            </>
          ) : (
            `Assinar por R$ ${finalPrice.toFixed(2)}/mês`
          )}
        </Button>
      </div>
    </motion.div>
  )
}
