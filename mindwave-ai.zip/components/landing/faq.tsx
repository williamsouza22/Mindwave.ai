"use client"

import { motion } from "framer-motion"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

const faqs = [
  {
    question: "Como funciona a IA do MindWave.AI?",
    answer:
      "Nossa IA é treinada especificamente para conversas empáticas sobre saúde mental. Ela usa técnicas de processamento de linguagem natural para entender suas emoções e oferecer suporte personalizado, sempre respeitando sua privacidade.",
  },
  {
    question: "Meus dados estão seguros?",
    answer:
      "Sim! Todas as conversas são criptografadas de ponta a ponta. Não compartilhamos seus dados com terceiros e você pode deletar seu histórico a qualquer momento. Sua privacidade é nossa prioridade máxima.",
  },
  {
    question: "Posso usar no lugar de terapia tradicional?",
    answer:
      "O MindWave.AI é uma ferramenta complementar, não um substituto para terapia profissional. Recomendamos sempre buscar ajuda de psicólogos ou psiquiatras para questões mais sérias. Somos um apoio diário para seu bem-estar.",
  },
  {
    question: "Como funciona o período gratuito?",
    answer:
      "Você pode usar o plano gratuito indefinidamente com 1 check-in por dia. O teste premium de 7 dias inclui todas as funcionalidades avançadas sem cobrança. Após o período, você escolhe se quer continuar.",
  },
  {
    question: "Funciona em quais plataformas?",
    answer:
      "Atualmente funcionamos via WhatsApp e nosso WebApp. Em breve teremos integração com Telegram e aplicativo móvel nativo para iOS e Android.",
  },
  {
    question: "Como cancelo minha assinatura?",
    answer:
      "Você pode cancelar a qualquer momento através do seu painel de usuário ou entrando em contato conosco. Não há taxas de cancelamento e você mantém acesso até o final do período pago.",
  },
  {
    question: "A IA detecta situações de risco?",
    answer:
      "Sim, nossa IA é treinada para identificar sinais de risco como pensamentos suicidas ou autolesão. Nesses casos, oferecemos recursos de emergência e recomendamos buscar ajuda profissional imediatamente.",
  },
  {
    question: "Posso usar para minha família?",
    answer:
      "Cada pessoa precisa de sua própria conta para garantir privacidade. Oferecemos descontos familiares para múltiplas assinaturas. Entre em contato para saber mais sobre nossos planos familiares.",
  },
]

export function FAQ() {
  return (
    <section className="py-24 bg-white">
      <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">Perguntas Frequentes</h2>
            <p className="mt-4 text-lg text-gray-600">Tire suas dúvidas sobre o MindWave.AI</p>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          viewport={{ once: true }}
          className="mt-20"
        >
          <Accordion type="single" collapsible className="space-y-4">
            {faqs.map((faq, index) => (
              <AccordionItem key={index} value={`item-${index}`} className="rounded-lg border border-gray-200 px-6">
                <AccordionTrigger className="text-left font-semibold text-gray-900 hover:text-purple-600">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-gray-600 pb-4">{faq.answer}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </motion.div>
      </div>
    </section>
  )
}
