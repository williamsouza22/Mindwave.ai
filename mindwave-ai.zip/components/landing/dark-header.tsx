"use client"

import { Button } from "@/components/ui/button"
import { Heart, Menu, X } from "lucide-react"
import { useState } from "react"
import Link from "next/link"

export function DarkHeader() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 bg-[#0B1426]/95 backdrop-blur-sm border-b border-gray-800">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="h-8 w-8 rounded-full bg-gradient-to-r from-blue-500 to-purple-500 flex items-center justify-center">
              <Heart className="h-5 w-5 text-white" />
            </div>
            <span className="text-xl font-bold text-white">MindWave.AI</span>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <a href="#features" className="text-gray-300 hover:text-white transition-colors">
              Recursos
            </a>
            <a href="#how-it-works" className="text-gray-300 hover:text-white transition-colors">
              Como Funciona
            </a>
            <a href="#testimonials" className="text-gray-300 hover:text-white transition-colors">
              Depoimentos
            </a>
            <a href="#pricing" className="text-gray-300 hover:text-white transition-colors">
              Preços
            </a>
          </nav>

          {/* Desktop Auth Buttons */}
          <div className="hidden md:flex items-center space-x-4">
            <Link href="/auth">
              <Button variant="ghost" className="text-gray-300 hover:text-white hover:bg-gray-800">
                Entrar
              </Button>
            </Link>
            <Link href="/auth">
              <Button className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
                Começar Grátis
              </Button>
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button className="md:hidden text-gray-300 hover:text-white" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden py-4 border-t border-gray-800">
            <nav className="flex flex-col space-y-4">
              <a href="#features" className="text-gray-300 hover:text-white transition-colors">
                Recursos
              </a>
              <a href="#how-it-works" className="text-gray-300 hover:text-white transition-colors">
                Como Funciona
              </a>
              <a href="#testimonials" className="text-gray-300 hover:text-white transition-colors">
                Depoimentos
              </a>
              <a href="#pricing" className="text-gray-300 hover:text-white transition-colors">
                Preços
              </a>
              <div className="flex flex-col space-y-2 pt-4 border-t border-gray-800">
                <Link href="/auth">
                  <Button variant="ghost" className="w-full text-gray-300 hover:text-white hover:bg-gray-800">
                    Entrar
                  </Button>
                </Link>
                <Link href="/auth">
                  <Button className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
                    Começar Grátis
                  </Button>
                </Link>
              </div>
            </nav>
          </div>
        )}
      </div>
    </header>
  )
}
