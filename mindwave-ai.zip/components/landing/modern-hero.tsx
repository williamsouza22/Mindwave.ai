"use client"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Heart, MessageCircle, Sparkles } from "lucide-react"
import { motion } from "framer-motion"
import Link from "next/link"

export function ModernHero() {
  return (
    <section className="relative overflow-hidden bg-[#0B1426] px-4 py-20 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <div className="text-center">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <Badge
              variant="secondary"
              className="mb-6 bg-gradient-to-r from-blue-900/50 to-purple-900/50 text-blue-300 border-blue-800"
            >
              <Sparkles className="mr-1 h-3 w-3" />
              Apoio Emocional Inteligente
            </Badge>

            <h1 className="text-4xl font-bold tracking-tight text-white sm:text-6xl lg:text-7xl mb-6">
              Um abraço digital{" "}
              <span className="bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
                nos seus dias difíceis
              </span>
            </h1>

            <p className="mx-auto mt-6 max-w-2xl text-lg leading-8 text-gray-300">
              Plataforma empática com IA especializada em ansiedade, burnout, nomofobia e ecoansiedade. Apoio 24/7 via
              WhatsApp com técnicas validadas e comunidade acolhedora.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4"
          >
            <Link href="/auth">
              <Button
                size="lg"
                className="bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 text-white px-8 py-3"
              >
                <MessageCircle className="mr-2 h-5 w-5" />
                Testar no WhatsApp
              </Button>
            </Link>
            <Link href="/auth">
              <Button
                variant="outline"
                size="lg"
                className="border-gray-600 text-gray-300 hover:bg-gray-800 hover:text-white px-8 py-3 bg-transparent"
              >
                Comece Grátis
              </Button>
            </Link>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="mt-16"
          >
            <div className="relative mx-auto max-w-4xl">
              <div className="absolute inset-0 bg-gradient-to-r from-blue-200/20 via-purple-200/20 to-pink-200/20 blur-3xl"></div>
              <div className="relative rounded-2xl bg-[#1A2332]/80 p-8 shadow-2xl backdrop-blur-sm border border-gray-700">
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center space-x-3">
                    <div className="h-10 w-10 rounded-full bg-gradient-to-r from-green-500 to-blue-500 flex items-center justify-center">
                      <Heart className="h-5 w-5 text-white" />
                    </div>
                    <div>
                      <span className="font-medium text-white">MindWave.AI</span>
                      <Badge variant="secondary" className="ml-2 bg-green-900/50 text-green-300 border-green-800">
                        Online 24/7
                      </Badge>
                    </div>
                  </div>
                </div>

                <div className="space-y-4 text-left">
                  <div className="flex items-start space-x-3">
                    <div className="h-8 w-8 rounded-full bg-gradient-to-r from-green-500 to-blue-500 flex items-center justify-center">
                      <Heart className="h-4 w-4 text-white" />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm text-gray-300">
                        Olá! Percebi que você pode estar passando por um momento difícil. Como posso te ajudar hoje? 💙
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3 mt-4">
                    <Button
                      variant="outline"
                      size="sm"
                      className="bg-blue-900/30 border-blue-700 text-blue-300 hover:bg-blue-800/50"
                    >
                      😰 Estou ansioso
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="bg-orange-900/30 border-orange-700 text-orange-300 hover:bg-orange-800/50"
                    >
                      😴 Me sinto esgotado
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="bg-purple-900/30 border-purple-700 text-purple-300 hover:bg-purple-800/50"
                    >
                      📱 Vício no celular
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="bg-green-900/30 border-green-700 text-green-300 hover:bg-green-800/50"
                    >
                      🌍 Ecoansiedade
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
