"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { motion } from "framer-motion"
import { Star, Shield } from "lucide-react"

const testimonials = [
  {
    name: "Ana M.",
    age: "28 anos",
    condition: "Ansiedade Generalizada",
    content:
      "O MindWave.AI me salvou durante uma crise de pânico às 3h da manhã. A respiração guiada funcionou em minutos.",
    rating: 5,
    verified: true,
    avatar: "/placeholder.svg?height=40&width=40",
    improvement: "85% menos crises",
  },
  {
    name: "Carlos R.",
    age: "34 anos",
    condition: "Burnout",
    content: "Estava no limite do esgotamento. As sessões de cozy mindfulness me ajudaram a recuperar o equilíbrio.",
    rating: 5,
    verified: true,
    avatar: "/placeholder.svg?height=40&width=40",
    improvement: "Voltou ao trabalho",
  },
  {
    name: "Júlia S.",
    age: "22 anos",
    condition: "Nomofobia",
    content: "Passava 8h/dia no celular. Com o detox digital, reduzi para 3h e me sinto muito mais presente.",
    rating: 5,
    verified: true,
    avatar: "/placeholder.svg?height=40&width=40",
    improvement: "62% menos tempo de tela",
  },
  {
    name: "Pedro L.",
    age: "26 anos",
    condition: "Ecoansiedade",
    content: "A ansiedade climática estava me paralisando. Os grupos de apoio me mostraram que não estou sozinho.",
    rating: 5,
    verified: true,
    avatar: "/placeholder.svg?height=40&width=40",
    improvement: "Ativismo positivo",
  },
  {
    name: "Maria F.",
    age: "31 anos",
    condition: "Depressão",
    content: "O diário emocional com IA me ajudou a identificar padrões que nem eu percebia. Mudou minha vida.",
    rating: 5,
    verified: true,
    avatar: "/placeholder.svg?height=40&width=40",
    improvement: "Autoconhecimento",
  },
  {
    name: "Lucas T.",
    age: "29 anos",
    condition: "Ansiedade Social",
    content: "Consegui me conectar com pessoas que passam pelo mesmo. A comunidade é muito acolhedora.",
    rating: 5,
    verified: true,
    avatar: "/placeholder.svg?height=40&width=40",
    improvement: "Novas amizades",
  },
]

export function RealTestimonials() {
  return (
    <section className="bg-[#0B1426] py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl font-bold text-white sm:text-4xl mb-4">Histórias Reais de Superação</h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Depoimentos verificados de pessoas que transformaram sua saúde mental com o MindWave.AI
            </p>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <Card className="bg-[#1A2332] border-gray-800 h-full hover:border-gray-600 transition-all duration-300">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-2">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <Star key={i} className="h-4 w-4 text-yellow-400 fill-current" />
                      ))}
                    </div>
                    {testimonial.verified && (
                      <Badge variant="secondary" className="bg-green-900/50 text-green-300 border-green-800 text-xs">
                        <Shield className="h-3 w-3 mr-1" />
                        Verificado
                      </Badge>
                    )}
                  </div>

                  <p className="text-gray-300 text-sm mb-6 leading-relaxed">"{testimonial.content}"</p>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={testimonial.avatar || "/placeholder.svg"} alt={testimonial.name} />
                        <AvatarFallback className="bg-gradient-to-r from-blue-500 to-purple-500 text-white text-xs">
                          {testimonial.name
                            .split(" ")
                            .map((n) => n[0])
                            .join("")}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <div className="font-semibold text-white text-sm">{testimonial.name}</div>
                        <div className="text-gray-400 text-xs">
                          {testimonial.age} • {testimonial.condition}
                        </div>
                      </div>
                    </div>
                    <Badge variant="outline" className="text-xs bg-blue-900/30 border-blue-700 text-blue-300">
                      {testimonial.improvement}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        <div className="text-center mt-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            viewport={{ once: true }}
          >
            <p className="text-gray-400 text-sm mb-4">
              <Shield className="h-4 w-4 inline mr-1" />
              Todos os depoimentos são verificados e anonimizados para proteger a privacidade
            </p>
            <Badge variant="secondary" className="bg-green-900/50 text-green-300 border-green-800">
              +2.847 vidas transformadas
            </Badge>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
