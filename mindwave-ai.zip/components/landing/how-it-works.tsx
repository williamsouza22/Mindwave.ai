"use client"

import { motion } from "framer-motion"
import { MessageCircle, BarChart3, Headphones, Heart } from "lucide-react"

const steps = [
  {
    step: "01",
    title: "Conecte-se",
    description: "Inicie uma conversa via WhatsApp ou acesse nosso WebApp. É gratuito e leva menos de 1 minuto.",
    icon: MessageCircle,
    color: "from-blue-500 to-blue-600",
  },
  {
    step: "02",
    title: "Check-in Diário",
    description: "Nossa IA fará perguntas empáticas sobre seu dia e estado emocional. Responda no seu ritmo.",
    icon: Heart,
    color: "from-purple-500 to-purple-600",
  },
  {
    step: "03",
    title: "Receba Orientação",
    description: "Com base nas suas respostas, receba áudios guiados, exercícios e dicas personalizadas.",
    icon: Headphones,
    color: "from-yellow-500 to-yellow-600",
  },
  {
    step: "04",
    title: "Acompanhe Evolução",
    description: "Visualize seu progresso emocional através de gráficos e insights gerados pela IA.",
    icon: BarChart3,
    color: "from-green-500 to-green-600",
  },
]

export function HowItWorks() {
  return (
    <section className="py-24 bg-gradient-to-br from-blue-50 via-purple-50 to-yellow-50">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">Como Funciona</h2>
            <p className="mt-4 text-lg text-gray-600">4 passos simples para começar sua jornada de bem-estar mental</p>
          </motion.div>
        </div>

        <div className="mt-20">
          <div className="grid grid-cols-1 gap-12 lg:grid-cols-4">
            {steps.map((step, index) => (
              <motion.div
                key={step.step}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.2 }}
                viewport={{ once: true }}
                className="relative text-center"
              >
                <div className="relative">
                  <div
                    className={`mx-auto h-16 w-16 rounded-full bg-gradient-to-r ${step.color} flex items-center justify-center shadow-lg`}
                  >
                    <step.icon className="h-8 w-8 text-white" />
                  </div>
                  <div className="absolute -top-2 -right-2 h-8 w-8 rounded-full bg-white shadow-md flex items-center justify-center">
                    <span className="text-sm font-bold text-gray-700">{step.step}</span>
                  </div>
                </div>
                <h3 className="mt-6 text-xl font-semibold text-gray-900">{step.title}</h3>
                <p className="mt-2 text-gray-600">{step.description}</p>

                {index < steps.length - 1 && (
                  <div className="hidden lg:block absolute top-8 left-full w-full">
                    <div className="h-0.5 bg-gradient-to-r from-gray-300 to-transparent"></div>
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
