"use client"

import { motion } from "framer-motion"
import { Star, Quote } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

const testimonials = [
  {
    name: "Maria Silva",
    role: "Estudante de Medicina",
    content:
      "O MindWave.AI me ajudou muito durante os períodos de estresse da faculdade. Os check-ins diários me fazem sentir acolhida.",
    rating: 5,
    avatar: "/placeholder.svg?height=40&width=40",
  },
  {
    name: "João Santos",
    role: "Desenvolvedor",
    content:
      "Como alguém que trabalha muito, ter um assistente de IA disponível 24/7 para conversar sobre ansiedade é incrível.",
    rating: 5,
    avatar: "/placeholder.svg?height=40&width=40",
  },
  {
    name: "Ana Costa",
    role: "Empreendedora",
    content:
      "Os áudios guiados são perfeitos para minha rotina corrida. Consigo fazer uma pausa e cuidar da minha mente.",
    rating: 5,
    avatar: "/placeholder.svg?height=40&width=40",
  },
  {
    name: "Pedro Lima",
    role: "Professor",
    content: "A privacidade total me deu confiança para ser vulnerável. Os insights sobre meu humor são muito úteis.",
    rating: 5,
    avatar: "/placeholder.svg?height=40&width=40",
  },
  {
    name: "Carla Mendes",
    role: "Mãe e Psicóloga",
    content: "Recomendo para meus pacientes. É uma ferramenta complementar fantástica para o cuidado da saúde mental.",
    rating: 5,
    avatar: "/placeholder.svg?height=40&width=40",
  },
  {
    name: "Rafael Oliveira",
    role: "Executivo",
    content: "Depois de um burnout, o MindWave.AI me ajudou a reconstruir minha relação com o trabalho e o estresse.",
    rating: 5,
    avatar: "/placeholder.svg?height=40&width=40",
  },
]

export function Testimonials() {
  return (
    <section className="py-24 bg-white">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">O que nossos usuários dizem</h2>
            <p className="mt-4 text-lg text-gray-600">
              Milhares de pessoas já transformaram sua saúde mental com o MindWave.AI
            </p>
          </motion.div>
        </div>

        <div className="mt-20 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={testimonial.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="relative"
            >
              <div className="rounded-2xl bg-gradient-to-br from-gray-50 to-gray-100 p-8 shadow-sm transition-all duration-300 hover:shadow-lg">
                <Quote className="h-8 w-8 text-purple-500 mb-4" />

                <div className="flex items-center mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="h-4 w-4 text-yellow-400 fill-current" />
                  ))}
                </div>

                <p className="text-gray-700 mb-6">"{testimonial.content}"</p>

                <div className="flex items-center">
                  <Avatar className="h-10 w-10">
                    <AvatarImage src={testimonial.avatar || "/placeholder.svg"} alt={testimonial.name} />
                    <AvatarFallback>
                      {testimonial.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </AvatarFallback>
                  </Avatar>
                  <div className="ml-3">
                    <p className="font-semibold text-gray-900">{testimonial.name}</p>
                    <p className="text-sm text-gray-600">{testimonial.role}</p>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
