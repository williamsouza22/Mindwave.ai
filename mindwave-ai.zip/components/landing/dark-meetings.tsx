"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Calendar } from "lucide-react"
import { motion } from "framer-motion"

export function DarkMeetings() {
  return (
    <section className="bg-[#0B1426] py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl font-bold text-white sm:text-4xl mb-4">Keep track of your wellness journey</h2>
            <h3 className="text-2xl font-semibold text-gray-300 mb-6">all in one place</h3>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Capture your daily moods, thoughts, and wellness notes in a beautifully organized calendar view.
            </p>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="flex justify-center"
        >
          <Card className="bg-[#1A2332] border-gray-800 max-w-md">
            <CardContent className="p-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Calendar className="h-5 w-5 text-blue-400" />
                    <span className="font-semibold text-white">Wellness Calendar</span>
                  </div>
                  <Badge variant="secondary" className="bg-blue-900/50 text-blue-300 border-blue-800">
                    Jan 2024
                  </Badge>
                </div>

                <div className="grid grid-cols-7 gap-1 text-center text-xs text-gray-400 mb-2">
                  {["S", "M", "T", "W", "T", "F", "S"].map((day) => (
                    <div key={day} className="p-2">
                      {day}
                    </div>
                  ))}
                </div>

                <div className="grid grid-cols-7 gap-1">
                  {Array.from({ length: 35 }, (_, i) => {
                    const day = i - 6
                    const isCurrentMonth = day > 0 && day <= 31
                    const hasEntry = [5, 12, 18, 25].includes(day)

                    return (
                      <div
                        key={i}
                        className={`
                          aspect-square flex items-center justify-center text-xs rounded
                          ${isCurrentMonth ? "text-gray-300" : "text-gray-600"}
                          ${hasEntry ? "bg-blue-600 text-white" : ""}
                          ${day === 15 ? "bg-purple-600 text-white" : ""}
                        `}
                      >
                        {isCurrentMonth ? day : ""}
                      </div>
                    )
                  })}
                </div>

                <div className="space-y-3 mt-6">
                  <div className="flex items-center space-x-3 p-3 bg-[#0F1B2A] rounded-lg">
                    <div className="h-3 w-3 rounded-full bg-blue-500"></div>
                    <div className="flex-1">
                      <div className="text-sm text-white">Daily Check-in</div>
                      <div className="text-xs text-gray-400">Mood tracking session</div>
                    </div>
                  </div>

                  <div className="flex items-center space-x-3 p-3 bg-[#0F1B2A] rounded-lg">
                    <div className="h-3 w-3 rounded-full bg-green-500"></div>
                    <div className="flex-1">
                      <div className="text-sm text-white">Meditation</div>
                      <div className="text-xs text-gray-400">10 min breathing exercise</div>
                    </div>
                  </div>

                  <div className="flex items-center space-x-3 p-3 bg-[#0F1B2A] rounded-lg">
                    <div className="h-3 w-3 rounded-full bg-purple-500"></div>
                    <div className="flex-1">
                      <div className="text-sm text-white">Journal Entry</div>
                      <div className="text-xs text-gray-400">Reflection and insights</div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </section>
  )
}
