"use client"

import { motion } from "framer-motion"
import { MessageCircle, BarChart3, Headphones, BookOpen, Shield, Zap } from "lucide-react"

const features = [
  {
    name: "Check-ins Diários com IA",
    description: "Conversas empáticas e personalizadas para acompanhar seu bem-estar emocional todos os dias.",
    icon: MessageCircle,
    color: "from-blue-500 to-blue-600",
  },
  {
    name: "Insights de Humor",
    description: "Gráficos e análises visuais da sua evolução emocional ao longo do tempo.",
    icon: BarChart3,
    color: "from-purple-500 to-purple-600",
  },
  {
    name: "Áudios Guiados",
    description: "Meditações, respirações e práticas de autocuidado personalizadas para você.",
    icon: Headphones,
    color: "from-yellow-500 to-yellow-600",
  },
  {
    name: "Diário Inteligente",
    description: "Escreva seus pensamentos com assistência de IA para maior autoconhecimento.",
    icon: BookOpen,
    color: "from-green-500 to-green-600",
  },
  {
    name: "Privacidade Total",
    description: "Suas conversas são criptografadas e nunca compartilhadas. Sua privacidade é sagrada.",
    icon: Shield,
    color: "from-red-500 to-red-600",
  },
  {
    name: "Disponível 24/7",
    description: "Acesso instantâneo via WhatsApp, Telegram ou WebApp quando você precisar.",
    icon: Zap,
    color: "from-indigo-500 to-indigo-600",
  },
]

export function Features() {
  return (
    <section className="py-24 bg-white">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">
              Por que o MindWave.AI funciona?
            </h2>
            <p className="mt-4 text-lg text-gray-600">
              Tecnologia de ponta combinada com cuidado humano para sua saúde mental
            </p>
          </motion.div>
        </div>

        <div className="mt-20 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((feature, index) => (
            <motion.div
              key={feature.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="relative group"
            >
              <div className="relative rounded-2xl bg-gradient-to-br from-gray-50 to-gray-100 p-8 shadow-sm transition-all duration-300 group-hover:shadow-lg group-hover:scale-105">
                <div
                  className={`inline-flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-r ${feature.color} shadow-lg`}
                >
                  <feature.icon className="h-6 w-6 text-white" />
                </div>
                <h3 className="mt-6 text-xl font-semibold text-gray-900">{feature.name}</h3>
                <p className="mt-2 text-gray-600">{feature.description}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
