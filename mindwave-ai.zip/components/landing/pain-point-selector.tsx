"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { motion } from "framer-motion"
import { Brain, Zap, Smartphone, Leaf, Heart, Users } from "lucide-react"

const painPoints = [
  {
    icon: Brain,
    title: "Tenho ansiedade",
    description: "Pensamentos acelerados, preocupações constantes, sintomas físicos",
    color: "from-blue-500 to-blue-600",
    bgColor: "bg-blue-900/20",
    borderColor: "border-blue-700",
    emoji: "😰",
  },
  {
    icon: Zap,
    title: "Me sinto sobrecarregado",
    description: "Burnout, exaustão mental, falta de energia para atividades",
    color: "from-orange-500 to-red-500",
    bgColor: "bg-orange-900/20",
    borderColor: "border-orange-700",
    emoji: "😴",
  },
  {
    icon: Smartphone,
    title: "Vício no celular",
    description: "Nomofobia, uso excessivo de redes sociais, FOMO",
    color: "from-purple-500 to-pink-500",
    bgColor: "bg-purple-900/20",
    borderColor: "border-purple-700",
    emoji: "📱",
  },
  {
    icon: Leaf,
    title: "Ecoansiedade",
    description: "Preocupação com mudanças climáticas, futuro do planeta",
    color: "from-green-500 to-emerald-500",
    bgColor: "bg-green-900/20",
    borderColor: "border-green-700",
    emoji: "🌍",
  },
  {
    icon: Heart,
    title: "Quero me cuidar melhor",
    description: "Autocuidado, mindfulness, equilíbrio emocional",
    color: "from-pink-500 to-rose-500",
    bgColor: "bg-pink-900/20",
    borderColor: "border-pink-700",
    emoji: "💝",
  },
  {
    icon: Users,
    title: "Preciso de apoio",
    description: "Solidão, isolamento, necessidade de conexão humana",
    color: "from-indigo-500 to-purple-500",
    bgColor: "bg-indigo-900/20",
    borderColor: "border-indigo-700",
    emoji: "🤝",
  },
]

export function PainPointSelector() {
  return (
    <section className="bg-[#0B1426] py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl font-bold text-white sm:text-4xl mb-4">Como você está se sentindo hoje?</h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Escolha o que mais se identifica com você agora. Nossa IA vai personalizar o apoio para suas necessidades
              específicas.
            </p>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {painPoints.map((point, index) => (
            <motion.div
              key={point.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <Card
                className={`bg-[#1A2332] border-gray-800 hover:${point.borderColor} transition-all duration-300 cursor-pointer group hover:scale-105`}
              >
                <CardContent className="p-6">
                  <div className="text-center">
                    <div
                      className={`inline-flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-r ${point.color} mb-4 group-hover:scale-110 transition-transform`}
                    >
                      <span className="text-2xl">{point.emoji}</span>
                    </div>
                    <h3 className="text-xl font-semibold text-white mb-2">{point.title}</h3>
                    <p className="text-gray-400 text-sm mb-4">{point.description}</p>
                    <Button
                      className={`w-full bg-gradient-to-r ${point.color} hover:opacity-90 transition-opacity`}
                      size="sm"
                    >
                      Quero ajuda com isso
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
