"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { motion } from "framer-motion"
import { Brain, Smartphone, Leaf, Shield, Users, Sparkles, Timer, BookOpen } from "lucide-react"

const modules = [
  {
    icon: Brain,
    title: "Agente IA de Crise",
    description: "Detecta sintomas físicos (taquicardia, sudorese) e ativa plano de ação imediato",
    features: ["Respiração guiada", "Contato de emergência", "Conteúdo calmante"],
    color: "from-red-500 to-pink-500",
    badge: "Emergencial",
  },
  {
    icon: Smartphone,
    title: "Detox Digital",
    description: "Monitoramento de tempo de tela e metas de uso consciente",
    features: ["Relatórios semanais", "Alertas proativos", "Gamificação"],
    color: "from-purple-500 to-indigo-500",
    badge: "Nomofobia",
  },
  {
    icon: Timer,
    title: "Cozy Mindfulness",
    description: "Sessões de floor time, candle watch e body scan com microinterações",
    features: ["Timer personalizável", "Trilha relaxante", "UI animada"],
    color: "from-blue-500 to-cyan-500",
    badge: "Trending",
  },
  {
    icon: Users,
    title: "Experiências Reais",
    description: "Biblioteca curada com depoimentos validados por IA",
    features: ["Histórias positivas", "Comunidades", "Moderação IA"],
    color: "from-green-500 to-emerald-500",
    badge: "Validado",
  },
  {
    icon: Shield,
    title: "Filtro Anti-Fake",
    description: "Detecção de auto-diagnósticos incorretos e desinformação",
    features: ["Fontes científicas", "Tag verificado", "Alertas de risco"],
    color: "from-orange-500 to-red-500",
    badge: "Segurança",
  },
  {
    icon: Leaf,
    title: "Ecoansiedade",
    description: "Apoio específico para ansiedade climática com recursos multimídia",
    features: ["Vídeos de natureza", "Atividades eco-friendly", "Grupos temáticos"],
    color: "from-green-400 to-green-600",
    badge: "Especializado",
  },
  {
    icon: Sparkles,
    title: "Fitoterapia Assistida",
    description: "Sugestões de infusões naturais com informações de segurança",
    features: ["Valeriana, camomila", "Contraindicações", "Trilha semanal"],
    color: "from-yellow-500 to-orange-500",
    badge: "Natural",
  },
  {
    icon: BookOpen,
    title: "Diário Emocional",
    description: "Escrita assistida por IA com análise de padrões emocionais",
    features: ["Transcrição de áudio", "Insights personalizados", "Evolução temporal"],
    color: "from-pink-500 to-purple-500",
    badge: "IA Avançada",
  },
]

export function ModulesShowcase() {
  return (
    <section className="bg-[#0B1426] py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl font-bold text-white sm:text-4xl mb-4">Funcionalidades Inteligentes</h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Cada módulo foi desenvolvido com base nas necessidades emocionais mais atuais, usando IA e técnicas
              validadas cientificamente.
            </p>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {modules.map((module, index) => (
            <motion.div
              key={module.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="group"
            >
              <Card className="bg-[#1A2332] border-gray-800 h-full hover:border-gray-600 transition-all duration-300 group-hover:scale-105">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div
                      className={`inline-flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-r ${module.color} shadow-lg`}
                    >
                      <module.icon className="h-6 w-6 text-white" />
                    </div>
                    <Badge variant="secondary" className="bg-gray-800 text-gray-300 text-xs">
                      {module.badge}
                    </Badge>
                  </div>

                  <h3 className="text-lg font-semibold text-white mb-2">{module.title}</h3>
                  <p className="text-gray-400 text-sm mb-4">{module.description}</p>

                  <ul className="space-y-1">
                    {module.features.map((feature, idx) => (
                      <li key={idx} className="flex items-center text-xs text-gray-500">
                        <div className="h-1 w-1 rounded-full bg-gray-500 mr-2"></div>
                        {feature}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
