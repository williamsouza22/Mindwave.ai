"use client"

import { Button } from "@/components/ui/button"
import { Heart, MessageCircle } from "lucide-react"
import Link from "next/link"

export function ModernFooter() {
  return (
    <footer className="bg-[#0B1426] border-t border-gray-800">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center space-x-2 mb-4">
              <div className="h-8 w-8 rounded-full bg-gradient-to-r from-blue-500 to-purple-500 flex items-center justify-center">
                <Heart className="h-5 w-5 text-white" />
              </div>
              <span className="text-xl font-bold text-white">MindWave.AI</span>
            </div>
            <p className="text-gray-400 mb-6 max-w-md">
              Sua plataforma de bem-estar emocional com IA empática. Apoio 24/7 para ansiedade, burnout e saúde mental
              através do WhatsApp e nossa plataforma web.
            </p>
            <div className="flex space-x-4">
              <Link href="/auth">
                <Button className="bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700">
                  <MessageCircle className="mr-2 h-4 w-4" />
                  Começar Agora
                </Button>
              </Link>
            </div>
          </div>

          {/* Links */}
          <div>
            <h3 className="text-white font-semibold mb-4">Plataforma</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/auth" className="text-gray-400 hover:text-white transition-colors">
                  Entrar
                </Link>
              </li>
              <li>
                <Link href="/auth" className="text-gray-400 hover:text-white transition-colors">
                  Criar Conta
                </Link>
              </li>
              <li>
                <a href="#pricing" className="text-gray-400 hover:text-white transition-colors">
                  Preços
                </a>
              </li>
              <li>
                <a href="#features" className="text-gray-400 hover:text-white transition-colors">
                  Recursos
                </a>
              </li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h3 className="text-white font-semibold mb-4">Suporte</h3>
            <ul className="space-y-2">
              <li>
                <a href="#faq" className="text-gray-400 hover:text-white transition-colors">
                  FAQ
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition-colors">
                  Central de Ajuda
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition-colors">
                  Contato
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition-colors">
                  Política de Privacidade
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom */}
        <div className="border-t border-gray-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400 text-sm">
            © 2024 MindWave.AI. Todos os direitos reservados. Feito com 💙 para sua saúde mental.
          </p>
          <div className="flex items-center space-x-4 mt-4 md:mt-0">
            <span className="text-gray-400 text-sm">Disponível 24/7 via WhatsApp</span>
            <div className="h-2 w-2 bg-green-400 rounded-full animate-pulse"></div>
          </div>
        </div>
      </div>
    </footer>
  )
}
