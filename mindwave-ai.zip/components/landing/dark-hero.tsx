"use client"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Sparkles } from "lucide-react"
import { motion } from "framer-motion"

export function DarkHero() {
  return (
    <section className="relative overflow-hidden bg-[#0B1426] px-4 py-20 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <div className="text-center">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <Badge variant="secondary" className="mb-6 bg-blue-900/50 text-blue-300 border-blue-800">
              <Sparkles className="mr-1 h-3 w-3" />
              Your Workplace Perfected
            </Badge>

            <h1 className="text-4xl font-bold tracking-tight text-white sm:text-6xl lg:text-7xl mb-6">
              All-In-One Mental Health and{" "}
              <span className="bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
                Wellness Platform
              </span>
            </h1>

            <p className="mx-auto mt-6 max-w-2xl text-lg leading-8 text-gray-300">
              Transform your mental wellness journey with AI-powered support, daily check-ins, and personalized guidance
              available 24/7 through WhatsApp and our web platform.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="mt-10"
          >
            <Button
              size="lg"
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-3"
            >
              Get Started Free
            </Button>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
