"use client"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Check, Heart, Sparkles, Crown } from "lucide-react"
import { motion } from "framer-motion"
import Link from "next/link"

export function ModernPricing() {
  const plans = [
    {
      name: "Gratuito",
      price: "R$ 0",
      period: "/mês",
      description: "Para começar sua jornada de bem-estar",
      features: [
        "3 check-ins diários",
        "Áudios básicos de meditação",
        "Relatório semanal simples",
        "Suporte via WhatsApp",
        "Comunidade básica",
      ],
      cta: "Começar Grátis",
      popular: false,
      icon: Heart,
    },
    {
      name: "Premium",
      price: "R$ 29",
      period: "/mês",
      description: "Apoio completo para sua saúde mental",
      features: [
        "Check-ins ilimitados",
        "Biblioteca completa de áudios",
        "IA personalizada avançada",
        "Relatórios detalhados",
        "Sessões cozy personalizadas",
        "Detox digital guiado",
        "Suporte prioritário 24/7",
        "Comunidade premium",
      ],
      cta: "Começar Premium",
      popular: true,
      icon: Sparkles,
    },
    {
      name: "Família",
      price: "R$ 79",
      period: "/mês",
      description: "Cuidado para toda a família",
      features: [
        "Até 5 contas Premium",
        "Dashboard familiar",
        "Alertas de crise familiares",
        "Sessões em grupo",
        "Relatórios familiares",
        "Suporte especializado",
        "Tudo do Premium incluído",
      ],
      cta: "Começar Família",
      popular: false,
      icon: Crown,
    },
  ]

  return (
    <section className="relative overflow-hidden bg-[#0B1426] px-4 py-20 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <div className="text-center mb-16">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <Badge variant="secondary" className="mb-4 bg-purple-900/50 text-purple-300 border-purple-800">
              <Sparkles className="mr-1 h-3 w-3" />
              Planos Acessíveis
            </Badge>
            <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl lg:text-5xl mb-4">
              Escolha o cuidado ideal{" "}
              <span className="bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
                para você
              </span>
            </h2>
            <p className="mx-auto max-w-2xl text-lg text-gray-300">
              Comece gratuitamente e evolua conforme suas necessidades. Todos os planos incluem nossa IA empática e
              suporte via WhatsApp.
            </p>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {plans.map((plan, index) => {
            const Icon = plan.icon
            return (
              <motion.div
                key={plan.name}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className={`relative rounded-2xl p-8 ${
                  plan.popular
                    ? "bg-gradient-to-b from-purple-900/50 to-blue-900/50 border-2 border-purple-500"
                    : "bg-[#1A2332]/80 border border-gray-700"
                } backdrop-blur-sm`}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <Badge className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-4 py-1">
                      Mais Popular
                    </Badge>
                  </div>
                )}

                <div className="text-center mb-8">
                  <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-gradient-to-r from-blue-500 to-purple-500 mb-4">
                    <Icon className="h-6 w-6 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-white mb-2">{plan.name}</h3>
                  <p className="text-gray-400 text-sm mb-4">{plan.description}</p>
                  <div className="flex items-baseline justify-center">
                    <span className="text-4xl font-bold text-white">{plan.price}</span>
                    <span className="text-gray-400 ml-1">{plan.period}</span>
                  </div>
                </div>

                <ul className="space-y-3 mb-8">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-start">
                      <Check className="h-5 w-5 text-green-400 mr-3 mt-0.5 flex-shrink-0" />
                      <span className="text-gray-300 text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>

                <Link href="/auth" className="block">
                  <Button
                    className={`w-full ${
                      plan.popular
                        ? "bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                        : "bg-gray-700 hover:bg-gray-600 text-white"
                    }`}
                  >
                    {plan.cta}
                  </Button>
                </Link>
              </motion.div>
            )
          })}
        </div>

        <div className="text-center mt-12">
          <p className="text-gray-400 text-sm">
            Todos os planos incluem 7 dias de teste grátis • Cancele a qualquer momento • Suporte em português
          </p>
        </div>
      </div>
    </section>
  )
}
