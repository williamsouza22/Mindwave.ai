"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Heart, Mail, ArrowRight } from "lucide-react"
import { motion } from "framer-motion"
import { useState } from "react"
import Link from "next/link"

export function ValidationForm() {
  const [email, setEmail] = useState("")
  const [isSubmitted, setIsSubmitted] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Aqui você pode adicionar lógica para salvar o email
    setIsSubmitted(true)
    setTimeout(() => setIsSubmitted(false), 3000)
  }

  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-[#0B1426] to-[#1A2332] px-4 py-20 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-4xl text-center">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gradient-to-r from-green-500 to-blue-500 mb-6">
            <Heart className="h-8 w-8 text-white" />
          </div>

          <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl lg:text-5xl mb-6">
            Pronto para transformar{" "}
            <span className="bg-gradient-to-r from-green-400 via-blue-400 to-purple-400 bg-clip-text text-transparent">
              sua saúde mental?
            </span>
          </h2>

          <p className="mx-auto max-w-2xl text-lg text-gray-300 mb-8">
            Junte-se a milhares de pessoas que já encontraram apoio emocional com nossa IA empática. Comece sua jornada
            de bem-estar hoje mesmo.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-8">
            <Badge variant="secondary" className="bg-green-900/50 text-green-300 border-green-800">
              ✅ 100% Gratuito para começar
            </Badge>
            <Badge variant="secondary" className="bg-blue-900/50 text-blue-300 border-blue-800">
              🔒 Seus dados são privados
            </Badge>
            <Badge variant="secondary" className="bg-purple-900/50 text-purple-300 border-purple-800">
              🤖 IA treinada em português
            </Badge>
          </div>

          {!isSubmitted ? (
            <form onSubmit={handleSubmit} className="mx-auto max-w-md">
              <div className="flex flex-col sm:flex-row gap-3">
                <div className="flex-1">
                  <Input
                    type="email"
                    placeholder="Seu melhor email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    className="bg-[#1A2332] border-gray-600 text-white placeholder-gray-400 focus:border-blue-500"
                  />
                </div>
                <Button
                  type="submit"
                  className="bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 px-6"
                >
                  <Mail className="mr-2 h-4 w-4" />
                  Quero Começar
                </Button>
              </div>
              <p className="text-xs text-gray-400 mt-3">
                Ao se cadastrar, você concorda com nossos{" "}
                <a href="#" className="text-blue-400 hover:underline">
                  Termos de Uso
                </a>{" "}
                e{" "}
                <a href="#" className="text-blue-400 hover:underline">
                  Política de Privacidade
                </a>
              </p>
            </form>
          ) : (
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              className="mx-auto max-w-md p-6 bg-green-900/20 border border-green-800 rounded-lg"
            >
              <div className="text-green-400 text-center">
                <Heart className="h-8 w-8 mx-auto mb-2" />
                <p className="font-medium">Obrigado! 💚</p>
                <p className="text-sm text-gray-300 mt-1">
                  Enviamos um link de acesso para seu email. Verifique sua caixa de entrada!
                </p>
              </div>
            </motion.div>
          )}

          <div className="mt-8">
            <Link href="/auth">
              <Button
                variant="outline"
                className="border-gray-600 text-gray-300 hover:bg-gray-800 hover:text-white bg-transparent"
              >
                Ou acesse diretamente
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
