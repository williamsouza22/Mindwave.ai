"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Avatar } from "@/components/ui/avatar"
import { Heart, Play, Users, Calendar, Database, BarChart3, Settings } from "lucide-react"

export function DarkDemo() {
  return (
    <section className="bg-[#0B1426] py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <Card className="bg-[#1A2332] border-gray-800">
              <CardContent className="p-6">
                <div className="space-y-6">
                  <div>
                    <div className="flex items-center space-x-2 mb-4">
                      <div className="h-2 w-2 rounded-full bg-blue-500"></div>
                      <span className="text-sm text-gray-300">Web Packages</span>
                    </div>
                    <div className="flex items-center space-x-2 text-white">
                      <Users className="h-4 w-4" />
                      <span className="text-sm">My Workspace</span>
                      <span className="text-xs text-gray-400">Clients</span>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <div className="flex items-center space-x-2 text-gray-300">
                      <div className="h-2 w-2 rounded-full bg-gray-600"></div>
                      <span className="text-sm">My Workspace</span>
                    </div>
                    <div className="ml-4 space-y-2">
                      <div className="flex items-center space-x-2 text-gray-400">
                        <Users className="h-3 w-3" />
                        <span className="text-xs">Clients</span>
                      </div>
                      <div className="flex items-center space-x-2 text-gray-400">
                        <Calendar className="h-3 w-3" />
                        <span className="text-xs">Sessions</span>
                      </div>
                      <div className="flex items-center space-x-2 text-gray-400">
                        <Database className="h-3 w-3" />
                        <span className="text-xs">Database</span>
                      </div>
                      <div className="flex items-center space-x-2 text-gray-400">
                        <BarChart3 className="h-3 w-3" />
                        <span className="text-xs">Dashboard</span>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center space-x-2 text-gray-300">
                      <div className="h-2 w-2 rounded-full bg-purple-500"></div>
                      <span className="text-sm">Social Media</span>
                    </div>
                    <div className="ml-4">
                      <div className="flex items-center space-x-2 text-gray-400">
                        <Settings className="h-3 w-3" />
                        <span className="text-xs">Settings</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            <Card className="bg-[#1A2332] border-gray-800">
              <CardContent className="p-8">
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center space-x-3">
                    <Avatar className="h-10 w-10">
                      <div className="h-10 w-10 rounded-full bg-gradient-to-r from-blue-500 to-purple-500 flex items-center justify-center">
                        <Heart className="h-5 w-5 text-white" />
                      </div>
                    </Avatar>
                    <div>
                      <h3 className="text-xl font-semibold text-white">MindWave AI Assistant</h3>
                      <div className="flex items-center space-x-2">
                        <Badge variant="secondary" className="bg-green-900/50 text-green-300 border-green-800">
                          Online
                        </Badge>
                      </div>
                    </div>
                  </div>
                  <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                    <Play className="h-4 w-4 mr-2" />
                    Start Session
                  </Button>
                </div>

                <div className="space-y-4">
                  <div className="flex items-start space-x-2">
                    <div className="h-2 w-2 rounded-full bg-green-500 mt-2"></div>
                    <span className="text-sm text-gray-300">Welcome to your daily check-in</span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <div className="h-2 w-2 rounded-full bg-blue-500 mt-2"></div>
                    <span className="text-sm text-gray-300">AI-powered mood tracking</span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <div className="h-2 w-2 rounded-full bg-purple-500 mt-2"></div>
                    <span className="text-sm text-gray-300">Personalized wellness insights</span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <div className="h-2 w-2 rounded-full bg-yellow-500 mt-2"></div>
                    <span className="text-sm text-gray-300">24/7 emotional support</span>
                  </div>
                </div>

                <div className="mt-8 p-6 bg-[#0F1B2A] rounded-lg border border-gray-700">
                  <p className="text-gray-300 text-sm leading-relaxed">
                    Welcome to your daily mental wellness companion. Our AI-powered platform provides personalized
                    support for anxiety, stress, and emotional well-being. Start your journey with a simple check-in and
                    receive tailored guidance, meditation sessions, and mood tracking insights designed specifically for
                    your needs.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  )
}
