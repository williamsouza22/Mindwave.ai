"use client"

import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { MessageCircle, Heart, Sparkles } from "lucide-react"
import Link from "next/link"

export function CTA() {
  return (
    <section className="py-24 bg-gradient-to-br from-purple-600 via-blue-600 to-purple-700">
      <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <div className="flex justify-center mb-6">
            <div className="flex items-center space-x-2">
              <Heart className="h-8 w-8 text-red-300" />
              <Sparkles className="h-6 w-6 text-yellow-300" />
              <Heart className="h-8 w-8 text-red-300" />
            </div>
          </div>

          <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">Pronto para cuidar da sua mente?</h2>
          <p className="mt-4 text-lg text-purple-100">
            Junte-se a milhares de pessoas que já transformaram sua saúde mental com o MindWave.AI
          </p>

          <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
            <Button size="lg" className="bg-white text-purple-600 hover:bg-gray-100 font-semibold px-8">
              <MessageCircle className="mr-2 h-5 w-5" />
              Começar Agora - É Grátis
            </Button>
            <Link href="/dashboard">
              <Button
                variant="outline"
                size="lg"
                className="border-white text-white hover:bg-white hover:text-purple-600 px-8 bg-transparent"
              >
                Acessar Dashboard
              </Button>
            </Link>
          </div>

          <p className="mt-6 text-sm text-purple-200">
            ✨ Sem cartão de crédito • Privacidade garantida • Suporte 24/7
          </p>
        </motion.div>
      </div>
    </section>
  )
}
