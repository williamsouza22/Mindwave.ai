"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { motion } from "framer-motion"

const testimonials = [
  {
    name: "Web Packages",
    handle: "@webpackages",
    content:
      "MindWave.AI has completely transformed how I manage my daily anxiety. The AI conversations feel so natural and supportive.",
    avatar: "/placeholder.svg?height=40&width=40",
  },
  {
    name: "Web Packages",
    handle: "@webpackages",
    content:
      "The daily check-ins keep me accountable for my mental health. It's like having a therapist available 24/7.",
    avatar: "/placeholder.svg?height=40&width=40",
  },
  {
    name: "Web Packages",
    handle: "@webpackages",
    content:
      "I love how the platform tracks my mood patterns and gives me insights. It's helped me understand my triggers better.",
    avatar: "/placeholder.svg?height=40&width=40",
  },
  {
    name: "Web Packages",
    handle: "@webpackages",
    content: "The guided meditations are perfect for my busy schedule. I can access them anytime through WhatsApp.",
    avatar: "/placeholder.svg?height=40&width=40",
  },
  {
    name: "Web Packages",
    handle: "@webpackages",
    content:
      "As someone who struggled with burnout, MindWave.AI helped me rebuild my relationship with work and stress.",
    avatar: "/placeholder.svg?height=40&width=40",
  },
  {
    name: "Web Packages",
    handle: "@webpackages",
    content: "The privacy and security features give me confidence to be vulnerable and honest about my mental health.",
    avatar: "/placeholder.svg?height=40&width=40",
  },
]

export function DarkTestimonials() {
  return (
    <section className="bg-[#0B1426] py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl font-bold text-white sm:text-4xl mb-4">Trusted by all</h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Join thousands of satisfied users who rely on our platform for their personal and professional
              productivity needs.
            </p>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <Card className="bg-[#1A2332] border-gray-800 h-full">
                <CardContent className="p-6">
                  <div className="flex items-center space-x-3 mb-4">
                    <Avatar className="h-10 w-10">
                      <AvatarImage src={testimonial.avatar || "/placeholder.svg"} alt={testimonial.name} />
                      <AvatarFallback className="bg-gradient-to-r from-blue-500 to-purple-500 text-white">
                        {testimonial.name
                          .split(" ")
                          .map((n) => n[0])
                          .join("")}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="font-semibold text-white text-sm">{testimonial.name}</div>
                      <div className="text-gray-400 text-xs">{testimonial.handle}</div>
                    </div>
                  </div>
                  <p className="text-gray-300 text-sm leading-relaxed">{testimonial.content}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
