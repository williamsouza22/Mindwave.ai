"use client"

import { motion } from "framer-motion"

const integrations = [
  { name: "WhatsApp", logo: "💬" },
  { name: "Telegram", logo: "✈️" },
  { name: "OpenAI", logo: "🤖" },
  { name: "Supabase", logo: "⚡" },
  { name: "Stripe", logo: "💳" },
]

export function DarkIntegrations() {
  return (
    <section className="bg-[#0B1426] py-16">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="flex items-center justify-center space-x-12"
        >
          {integrations.map((integration, index) => (
            <motion.div
              key={integration.name}
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.4, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="flex flex-col items-center space-y-2 group cursor-pointer"
            >
              <div className="text-3xl group-hover:scale-110 transition-transform">{integration.logo}</div>
              <span className="text-sm text-gray-400 group-hover:text-gray-300 transition-colors">
                {integration.name}
              </span>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}
