"use client"

import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Check, Sparkles, Crown } from "lucide-react"

const plans = [
  {
    name: "Gratuito",
    price: "R$ 0",
    period: "/mês",
    description: "Perfeito para começar sua jornada de bem-estar",
    features: [
      "1 check-in por dia",
      "IA de conversação básica",
      "Acesso via WhatsApp",
      "Histórico de 7 dias",
      "Suporte por email",
    ],
    cta: "Começar Grátis",
    popular: false,
    icon: Sparkles,
  },
  {
    name: "Premium",
    price: "R$ 59",
    period: "/mês",
    description: "Para quem quer transformar sua saúde mental",
    features: [
      "Check-ins ilimitados",
      "IA personalizada e avançada",
      "Áudios guiados diários",
      "Gráficos e insights detalhados",
      "Diário inteligente",
      "Relatórios mensais",
      "Suporte prioritário",
      "Acesso a todas as plataformas",
    ],
    cta: "Testar 7 dias grátis",
    popular: true,
    icon: Crown,
  },
]

export function Pricing() {
  return (
    <section className="py-24 bg-gradient-to-br from-blue-50 via-purple-50 to-yellow-50">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">
              Planos que cabem no seu bolso
            </h2>
            <p className="mt-4 text-lg text-gray-600">Comece grátis e evolua quando estiver pronto</p>
          </motion.div>
        </div>

        <div className="mt-20 grid grid-cols-1 gap-8 lg:grid-cols-2 lg:gap-12">
          {plans.map((plan, index) => (
            <motion.div
              key={plan.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              viewport={{ once: true }}
              className={`relative rounded-3xl p-8 shadow-lg transition-all duration-300 hover:shadow-xl ${
                plan.popular
                  ? "bg-gradient-to-br from-purple-600 to-blue-600 text-white scale-105"
                  : "bg-white text-gray-900"
              }`}
            >
              {plan.popular && (
                <Badge className="absolute -top-3 left-1/2 -translate-x-1/2 bg-yellow-400 text-yellow-900">
                  Mais Popular
                </Badge>
              )}

              <div className="text-center">
                <div
                  className={`inline-flex h-12 w-12 items-center justify-center rounded-xl ${
                    plan.popular ? "bg-white/20" : "bg-gradient-to-r from-purple-500 to-blue-500"
                  }`}
                >
                  <plan.icon className={`h-6 w-6 ${plan.popular ? "text-white" : "text-white"}`} />
                </div>

                <h3 className="mt-4 text-2xl font-bold">{plan.name}</h3>
                <p className={`mt-2 text-sm ${plan.popular ? "text-purple-100" : "text-gray-600"}`}>
                  {plan.description}
                </p>

                <div className="mt-6">
                  <span className="text-4xl font-bold">{plan.price}</span>
                  <span className={`text-lg ${plan.popular ? "text-purple-100" : "text-gray-600"}`}>{plan.period}</span>
                </div>
              </div>

              <ul className="mt-8 space-y-4">
                {plan.features.map((feature) => (
                  <li key={feature} className="flex items-center">
                    <Check className={`h-5 w-5 mr-3 ${plan.popular ? "text-green-300" : "text-green-500"}`} />
                    <span className={`text-sm ${plan.popular ? "text-purple-100" : "text-gray-700"}`}>{feature}</span>
                  </li>
                ))}
              </ul>

              <Button
                className={`mt-8 w-full ${
                  plan.popular
                    ? "bg-white text-purple-600 hover:bg-gray-100"
                    : "bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                }`}
                size="lg"
              >
                {plan.cta}
              </Button>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
