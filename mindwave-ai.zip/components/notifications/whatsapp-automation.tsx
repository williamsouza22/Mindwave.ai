"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { MessageSquare, Send, Settings, Loader2 } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface AutomationRule {
  id: string
  name: string
  trigger: string
  message: string
  enabled: boolean
  target_audience: string
  schedule?: string
}

const triggers = [
  { value: "user_signup", label: "Novo cadastro", description: "Quando um usuário se cadastra" },
  { value: "subscription_active", label: "Assinatura ativa", description: "Quando uma assinatura é confirmada" },
  { value: "subscription_overdue", label: "Pagamento em atraso", description: "Quando um pagamento está atrasado" },
  { value: "low_engagement", label: "Baixo engajamento", description: "Usuário inativo por 7 dias" },
  { value: "mood_crisis", label: "Crise detectada", description: "IA detecta sinais de crise" },
  { value: "daily_reminder", label: "Lembrete diário", description: "Check-in diário agendado" },
]

const audiences = [
  { value: "all", label: "Todos os usuários" },
  { value: "free", label: "Usuários gratuitos" },
  { value: "premium", label: "Usuários premium" },
  { value: "new", label: "Novos usuários (< 30 dias)" },
  { value: "inactive", label: "Usuários inativos" },
]

export function WhatsAppAutomation() {
  const [rules, setRules] = useState<AutomationRule[]>([])
  const [loading, setLoading] = useState(true)
  const [editingRule, setEditingRule] = useState<AutomationRule | null>(null)
  const [isCreating, setIsCreating] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    loadAutomationRules()
  }, [])

  const loadAutomationRules = async () => {
    try {
      const response = await fetch("/api/admin/whatsapp-automation")
      if (response.ok) {
        const data = await response.json()
        setRules(data.rules || [])
      }
    } catch (error) {
      console.error("Error loading automation rules:", error)
    } finally {
      setLoading(false)
    }
  }

  const saveRule = async (rule: Partial<AutomationRule>) => {
    try {
      const response = await fetch("/api/admin/whatsapp-automation", {
        method: rule.id ? "PUT" : "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(rule),
      })

      if (response.ok) {
        await loadAutomationRules()
        setEditingRule(null)
        setIsCreating(false)
        toast({
          title: "Regra salva com sucesso!",
          description: "A automação foi configurada.",
        })
      }
    } catch (error) {
      console.error("Error saving rule:", error)
      toast({
        title: "Erro ao salvar regra",
        description: "Tente novamente em alguns instantes.",
        variant: "destructive",
      })
    }
  }

  const toggleRule = async (ruleId: string, enabled: boolean) => {
    try {
      const response = await fetch(`/api/admin/whatsapp-automation/${ruleId}`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ enabled }),
      })

      if (response.ok) {
        setRules((prev) => prev.map((rule) => (rule.id === ruleId ? { ...rule, enabled } : rule)))
        toast({
          title: enabled ? "Regra ativada" : "Regra desativada",
          description: `A automação foi ${enabled ? "ativada" : "desativada"}.`,
        })
      }
    } catch (error) {
      console.error("Error toggling rule:", error)
    }
  }

  const testRule = async (ruleId: string) => {
    try {
      const response = await fetch(`/api/admin/whatsapp-automation/${ruleId}/test`, {
        method: "POST",
      })

      if (response.ok) {
        toast({
          title: "Teste enviado!",
          description: "Mensagem de teste foi enviada para seu WhatsApp.",
        })
      }
    } catch (error) {
      console.error("Error testing rule:", error)
      toast({
        title: "Erro no teste",
        description: "Não foi possível enviar a mensagem de teste.",
        variant: "destructive",
      })
    }
  }

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-center">
            <Loader2 className="h-6 w-6 animate-spin" />
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <MessageSquare className="h-5 w-5 text-green-500" />
              <span>Automação WhatsApp</span>
            </div>
            <Button onClick={() => setIsCreating(true)}>Nova Regra</Button>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="text-center">
              <p className="text-2xl font-bold text-green-600">{rules.length}</p>
              <p className="text-sm text-gray-600">Total de Regras</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-blue-600">{rules.filter((r) => r.enabled).length}</p>
              <p className="text-sm text-gray-600">Ativas</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-orange-600">{rules.filter((r) => !r.enabled).length}</p>
              <p className="text-sm text-gray-600">Inativas</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-purple-600">1,234</p>
              <p className="text-sm text-gray-600">Mensagens Enviadas</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Rules List */}
      <div className="space-y-4">
        {rules.map((rule) => (
          <Card key={rule.id}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-2">
                    <h3 className="font-medium">{rule.name}</h3>
                    <Badge variant={rule.enabled ? "default" : "secondary"}>{rule.enabled ? "Ativa" : "Inativa"}</Badge>
                    <Badge variant="outline">{triggers.find((t) => t.value === rule.trigger)?.label}</Badge>
                  </div>
                  <p className="text-sm text-gray-600 mb-2">
                    {triggers.find((t) => t.value === rule.trigger)?.description}
                  </p>
                  <p className="text-sm text-gray-500">
                    Público: {audiences.find((a) => a.value === rule.target_audience)?.label}
                  </p>
                </div>

                <div className="flex items-center space-x-2">
                  <Switch checked={rule.enabled} onCheckedChange={(enabled) => toggleRule(rule.id, enabled)} />
                  <Button variant="outline" size="sm" onClick={() => testRule(rule.id)}>
                    <Send className="h-4 w-4 mr-2" />
                    Testar
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => setEditingRule(rule)}>
                    <Settings className="h-4 w-4 mr-2" />
                    Editar
                  </Button>
                </div>
              </div>

              {/* Message Preview */}
              <div className="mt-4 p-3 bg-gray-50 rounded-lg">
                <p className="text-sm font-medium mb-1">Mensagem:</p>
                <p className="text-sm text-gray-700">{rule.message}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Create/Edit Rule Modal */}
      {(isCreating || editingRule) && (
        <RuleEditor
          rule={editingRule}
          onSave={saveRule}
          onCancel={() => {
            setIsCreating(false)
            setEditingRule(null)
          }}
        />
      )}
    </div>
  )
}

function RuleEditor({
  rule,
  onSave,
  onCancel,
}: {
  rule: AutomationRule | null
  onSave: (rule: Partial<AutomationRule>) => void
  onCancel: () => void
}) {
  const [formData, setFormData] = useState({
    name: rule?.name || "",
    trigger: rule?.trigger || "",
    message: rule?.message || "",
    target_audience: rule?.target_audience || "all",
    enabled: rule?.enabled ?? true,
  })

  return (
    <Card className="fixed inset-0 z-50 m-4 overflow-auto">
      <CardHeader>
        <CardTitle>{rule ? "Editar Regra" : "Nova Regra de Automação"}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-2">
          <Label>Nome da Regra</Label>
          <input
            type="text"
            value={formData.name}
            onChange={(e) => setFormData((prev) => ({ ...prev, name: e.target.value }))}
            className="w-full p-2 border rounded-md"
            placeholder="Ex: Boas-vindas para novos usuários"
          />
        </div>

        <div className="space-y-2">
          <Label>Gatilho</Label>
          <select
            value={formData.trigger}
            onChange={(e) => setFormData((prev) => ({ ...prev, trigger: e.target.value }))}
            className="w-full p-2 border rounded-md"
          >
            <option value="">Selecione um gatilho</option>
            {triggers.map((trigger) => (
              <option key={trigger.value} value={trigger.value}>
                {trigger.label} - {trigger.description}
              </option>
            ))}
          </select>
        </div>

        <div className="space-y-2">
          <Label>Público-Alvo</Label>
          <select
            value={formData.target_audience}
            onChange={(e) => setFormData((prev) => ({ ...prev, target_audience: e.target.value }))}
            className="w-full p-2 border rounded-md"
          >
            {audiences.map((audience) => (
              <option key={audience.value} value={audience.value}>
                {audience.label}
              </option>
            ))}
          </select>
        </div>

        <div className="space-y-2">
          <Label>Mensagem</Label>
          <Textarea
            value={formData.message}
            onChange={(e) => setFormData((prev) => ({ ...prev, message: e.target.value }))}
            rows={4}
            placeholder="Olá! 👋 Bem-vindo ao MindWave.AI..."
          />
          <p className="text-xs text-gray-500">
            Use variáveis: {"{nome}"}, {"{plano}"}, {"{dias_inativo}"}
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <Switch
            checked={formData.enabled}
            onCheckedChange={(enabled) => setFormData((prev) => ({ ...prev, enabled }))}
          />
          <Label>Ativar regra imediatamente</Label>
        </div>

        <div className="flex space-x-4">
          <Button onClick={onCancel} variant="outline" className="flex-1 bg-transparent">
            Cancelar
          </Button>
          <Button onClick={() => onSave({ ...rule, ...formData })} className="flex-1">
            Salvar Regra
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
