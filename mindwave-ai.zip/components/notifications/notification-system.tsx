"use client"

import { useEffect, useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { useAuth } from "@/lib/auth/auth-context"
import { createClient } from "@/lib/supabase/client"
import { Bell, X, AlertTriangle, Info, CheckCircle } from "lucide-react"

interface Notification {
  id: string
  type: "info" | "success" | "warning" | "error" | "reminder"
  title: string
  message: string
  timestamp: Date
  read: boolean
  actionUrl?: string
  actionLabel?: string
}

const notificationIcons = {
  info: Info,
  success: CheckCircle,
  warning: AlertTriangle,
  error: AlertTriangle,
  reminder: Bell,
}

const notificationColors = {
  info: "from-blue-500 to-blue-600",
  success: "from-green-500 to-green-600",
  warning: "from-yellow-500 to-orange-500",
  error: "from-red-500 to-red-600",
  reminder: "from-purple-500 to-purple-600",
}

export function NotificationSystem() {
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [isOpen, setIsOpen] = useState(false)
  const [unreadCount, setUnreadCount] = useState(0)
  const { user } = useAuth()
  const supabase = createClient()

  useEffect(() => {
    if (user) {
      loadNotifications()
      setupRealtimeSubscription()
      setupPeriodicNotifications()
    }
  }, [user])

  const loadNotifications = async () => {
    try {
      const { data, error } = await supabase
        .from("notifications")
        .select("*")
        .eq("user_id", user?.id)
        .order("created_at", { ascending: false })
        .limit(20)

      if (error) throw error

      const formattedNotifications: Notification[] = data.map((notif) => ({
        id: notif.id,
        type: notif.type,
        title: notif.title,
        message: notif.message,
        timestamp: new Date(notif.created_at),
        read: notif.read,
        actionUrl: notif.action_url,
        actionLabel: notif.action_label,
      }))

      setNotifications(formattedNotifications)
      setUnreadCount(formattedNotifications.filter((n) => !n.read).length)
    } catch (error) {
      console.error("Error loading notifications:", error)
    }
  }

  const setupRealtimeSubscription = () => {
    const channel = supabase
      .channel("notifications")
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "notifications",
          filter: `user_id=eq.${user?.id}`,
        },
        (payload) => {
          const newNotification: Notification = {
            id: payload.new.id,
            type: payload.new.type,
            title: payload.new.title,
            message: payload.new.message,
            timestamp: new Date(payload.new.created_at),
            read: false,
            actionUrl: payload.new.action_url,
            actionLabel: payload.new.action_label,
          }

          setNotifications((prev) => [newNotification, ...prev])
          setUnreadCount((prev) => prev + 1)

          // Show browser notification if permission granted
          if (Notification.permission === "granted") {
            new Notification(newNotification.title, {
              body: newNotification.message,
              icon: "/favicon.ico",
              badge: "/favicon.ico",
            })
          }
        },
      )
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }

  const setupPeriodicNotifications = () => {
    // Check for daily check-in reminder
    const checkDailyReminder = () => {
      const now = new Date()
      const hour = now.getHours()

      // Send reminder at 9 AM if user hasn't checked in today
      if (hour === 9) {
        sendNotification({
          type: "reminder",
          title: "Hora do check-in diário! 🌅",
          message: "Como você está se sentindo hoje? Vamos começar o dia cuidando da sua mente.",
          actionUrl: "/dashboard",
          actionLabel: "Fazer check-in",
        })
      }

      // Send evening reflection at 8 PM
      if (hour === 20) {
        sendNotification({
          type: "reminder",
          title: "Momento de reflexão 🌙",
          message: "Que tal refletir sobre seu dia? Escreva no seu diário emocional.",
          actionUrl: "/journal",
          actionLabel: "Escrever",
        })
      }
    }

    // Check every hour
    const interval = setInterval(checkDailyReminder, 60 * 60 * 1000)
    return () => clearInterval(interval)
  }

  const sendNotification = async (notification: Omit<Notification, "id" | "timestamp" | "read">) => {
    try {
      const { error } = await supabase.from("notifications").insert({
        user_id: user?.id,
        type: notification.type,
        title: notification.title,
        message: notification.message,
        action_url: notification.actionUrl,
        action_label: notification.actionLabel,
        read: false,
      })

      if (error) throw error
    } catch (error) {
      console.error("Error sending notification:", error)
    }
  }

  const markAsRead = async (notificationId: string) => {
    try {
      const { error } = await supabase.from("notifications").update({ read: true }).eq("id", notificationId)

      if (error) throw error

      setNotifications((prev) => prev.map((n) => (n.id === notificationId ? { ...n, read: true } : n)))
      setUnreadCount((prev) => Math.max(0, prev - 1))
    } catch (error) {
      console.error("Error marking notification as read:", error)
    }
  }

  const markAllAsRead = async () => {
    try {
      const { error } = await supabase
        .from("notifications")
        .update({ read: true })
        .eq("user_id", user?.id)
        .eq("read", false)

      if (error) throw error

      setNotifications((prev) => prev.map((n) => ({ ...n, read: true })))
      setUnreadCount(0)
    } catch (error) {
      console.error("Error marking all notifications as read:", error)
    }
  }

  const deleteNotification = async (notificationId: string) => {
    try {
      const { error } = await supabase.from("notifications").delete().eq("id", notificationId)

      if (error) throw error

      setNotifications((prev) => prev.filter((n) => n.id !== notificationId))
      setUnreadCount((prev) => {
        const notification = notifications.find((n) => n.id === notificationId)
        return notification && !notification.read ? prev - 1 : prev
      })
    } catch (error) {
      console.error("Error deleting notification:", error)
    }
  }

  return (
    <div className="relative">
      {/* Notification Bell */}
      <Button
        variant="ghost"
        size="sm"
        onClick={() => setIsOpen(!isOpen)}
        className="relative text-gray-300 hover:bg-gray-800"
      >
        <Bell className="h-4 w-4" />
        {unreadCount > 0 && (
          <Badge
            variant="destructive"
            className="absolute -top-1 -right-1 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs"
          >
            {unreadCount > 9 ? "9+" : unreadCount}
          </Badge>
        )}
      </Button>

      {/* Notification Panel */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -10, scale: 0.95 }}
            className="absolute right-0 top-full mt-2 w-80 z-50"
          >
            <Card className="bg-[#1A2332] border-gray-700 shadow-xl">
              <CardContent className="p-0">
                {/* Header */}
                <div className="flex items-center justify-between p-4 border-b border-gray-700">
                  <h3 className="font-semibold text-white">Notificações</h3>
                  <div className="flex items-center space-x-2">
                    {unreadCount > 0 && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={markAllAsRead}
                        className="text-xs text-blue-400 hover:text-blue-300"
                      >
                        Marcar todas como lidas
                      </Button>
                    )}
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setIsOpen(false)}
                      className="text-gray-400 hover:text-white"
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                {/* Notifications List */}
                <div className="max-h-96 overflow-y-auto">
                  {notifications.length === 0 ? (
                    <div className="p-8 text-center">
                      <Bell className="h-8 w-8 text-gray-500 mx-auto mb-2" />
                      <p className="text-gray-400 text-sm">Nenhuma notificação ainda</p>
                    </div>
                  ) : (
                    <div className="space-y-1">
                      {notifications.map((notification) => {
                        const Icon = notificationIcons[notification.type]
                        return (
                          <motion.div
                            key={notification.id}
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            className={`p-4 border-l-4 hover:bg-gray-800/50 transition-colors ${
                              !notification.read ? "bg-gray-800/30" : ""
                            }`}
                            style={{
                              borderLeftColor: notification.read ? "#374151" : "#3B82F6",
                            }}
                          >
                            <div className="flex items-start space-x-3">
                              <div
                                className={`h-8 w-8 rounded-full bg-gradient-to-r ${
                                  notificationColors[notification.type]
                                } flex items-center justify-center flex-shrink-0`}
                              >
                                <Icon className="h-4 w-4 text-white" />
                              </div>

                              <div className="flex-1 min-w-0">
                                <div className="flex items-start justify-between">
                                  <h4
                                    className={`text-sm font-medium ${
                                      notification.read ? "text-gray-300" : "text-white"
                                    }`}
                                  >
                                    {notification.title}
                                  </h4>
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => deleteNotification(notification.id)}
                                    className="text-gray-500 hover:text-red-400 p-1"
                                  >
                                    <X className="h-3 w-3" />
                                  </Button>
                                </div>

                                <p className="text-xs text-gray-400 mt-1">{notification.message}</p>

                                <div className="flex items-center justify-between mt-2">
                                  <span className="text-xs text-gray-500">
                                    {notification.timestamp.toLocaleTimeString()}
                                  </span>

                                  <div className="flex items-center space-x-2">
                                    {notification.actionUrl && (
                                      <Button
                                        variant="ghost"
                                        size="sm"
                                        onClick={() => {
                                          window.location.href = notification.actionUrl!
                                          markAsRead(notification.id)
                                        }}
                                        className="text-xs text-blue-400 hover:text-blue-300"
                                      >
                                        {notification.actionLabel}
                                      </Button>
                                    )}

                                    {!notification.read && (
                                      <Button
                                        variant="ghost"
                                        size="sm"
                                        onClick={() => markAsRead(notification.id)}
                                        className="text-xs text-gray-400 hover:text-white"
                                      >
                                        Marcar como lida
                                      </Button>
                                    )}
                                  </div>
                                </div>
                              </div>
                            </div>
                          </motion.div>
                        )
                      })}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Click outside to close */}
      {isOpen && <div className="fixed inset-0 z-40" onClick={() => setIsOpen(false)} />}
    </div>
  )
}
