"use client"

import type React from "react"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Crown, Play, Users, Star, ArrowRight, X } from "lucide-react"
import { useAuth } from "@/lib/auth/auth-context"
import { useAnalytics } from "@/components/analytics/analytics-provider"
import { WhatsAppIntegration } from "@/components/whatsapp/whatsapp-integration"
import Link from "next/link"

interface ModuleModalProps {
  isOpen: boolean
  onClose: () => void
  module: {
    title: string
    description: string
    longDescription: string
    icon: React.ComponentType<{ className?: string }>
    features: string[]
    benefits: string[]
    testimonials?: {
      name: string
      text: string
      rating: number
    }[]
    isPremium?: boolean
    demoVideo?: string
    href: string
  }
}

export function ModuleModal({ isOpen, onClose, module }: ModuleModalProps) {
  const [activeTab, setActiveTab] = useState("overview")
  const { user } = useAuth()
  const { trackEvent } = useAnalytics()

  const userPlan = user?.user_metadata?.plan || "free"
  const hasAccess = !module.isPremium || userPlan === "premium" || userPlan === "family"

  const handleStartClick = () => {
    trackEvent("module_start_click", {
      module: module.title,
      has_access: hasAccess,
      user_plan: userPlan,
      source: "modal",
    })

    if (hasAccess) {
      window.location.href = module.href
    } else {
      window.location.href = "/pricing"
    }
  }

  const handleDemoClick = () => {
    trackEvent("module_demo_click", {
      module: module.title,
      source: "modal",
    })
  }

  const Icon = module.icon

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto bg-slate-900 border-purple-500/20">
        <DialogHeader className="border-b border-purple-500/20 pb-6">
          <div className="flex items-start justify-between">
            <div className="flex items-center space-x-4">
              <div className="p-4 bg-purple-600/20 rounded-xl">
                <Icon className="h-8 w-8 text-purple-400" />
              </div>
              <div>
                <DialogTitle className="text-2xl text-white flex items-center space-x-2">
                  <span>{module.title}</span>
                  {module.isPremium && <Crown className="h-5 w-5 text-yellow-400" />}
                </DialogTitle>
                <p className="text-gray-400 mt-1">{module.description}</p>
                <div className="flex items-center space-x-4 mt-2">
                  {module.isPremium && (
                    <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-black">Premium</Badge>
                  )}
                  <div className="flex items-center space-x-1">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    ))}
                    <span className="text-sm text-gray-400 ml-2">4.9 (1.2k avaliações)</span>
                  </div>
                </div>
              </div>
            </div>
            <Button variant="ghost" size="sm" onClick={onClose} className="text-gray-400 hover:text-white">
              <X className="h-5 w-5" />
            </Button>
          </div>
        </DialogHeader>

        <div className="py-6">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-4 bg-slate-800">
              <TabsTrigger value="overview">Visão Geral</TabsTrigger>
              <TabsTrigger value="features">Recursos</TabsTrigger>
              <TabsTrigger value="benefits">Benefícios</TabsTrigger>
              <TabsTrigger value="testimonials">Avaliações</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-6 mt-6">
              <div className="prose prose-invert max-w-none">
                <p className="text-gray-300 leading-relaxed text-lg">{module.longDescription}</p>
              </div>

              {module.demoVideo && (
                <div className="bg-slate-800 rounded-lg p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold text-white">Demonstração</h3>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleDemoClick}
                      className="border-purple-500/50 text-purple-400 bg-transparent"
                    >
                      <Play className="h-4 w-4 mr-2" />
                      Assistir Demo
                    </Button>
                  </div>
                  <div className="aspect-video bg-slate-700 rounded-lg flex items-center justify-center">
                    <div className="text-center">
                      <Play className="h-16 w-16 text-purple-400 mx-auto mb-4" />
                      <p className="text-gray-400">Vídeo demonstrativo do {module.title}</p>
                    </div>
                  </div>
                </div>
              )}

              <WhatsAppIntegration variant="cta" showBenefits={true} className="mt-6" />
            </TabsContent>

            <TabsContent value="features" className="mt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {module.features.map((feature, index) => (
                  <div key={index} className="flex items-start space-x-3 p-4 bg-slate-800 rounded-lg">
                    <div className="w-2 h-2 bg-purple-400 rounded-full mt-2 flex-shrink-0" />
                    <span className="text-gray-300">{feature}</span>
                  </div>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="benefits" className="mt-6">
              <div className="space-y-4">
                {module.benefits.map((benefit, index) => (
                  <div key={index} className="flex items-start space-x-3 p-4 bg-slate-800 rounded-lg">
                    <div className="p-2 bg-green-600/20 rounded-lg">
                      <Star className="h-4 w-4 text-green-400" />
                    </div>
                    <div>
                      <p className="text-white font-medium mb-1">Benefício {index + 1}</p>
                      <p className="text-gray-300">{benefit}</p>
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="testimonials" className="mt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {module.testimonials?.map((testimonial, index) => (
                  <div key={index} className="bg-slate-800 rounded-lg p-6">
                    <div className="flex items-center space-x-1 mb-3">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                      ))}
                    </div>
                    <p className="text-gray-300 mb-4 italic">"{testimonial.text}"</p>
                    <p className="text-white font-medium">— {testimonial.name}</p>
                  </div>
                )) || (
                  <div className="col-span-2 text-center py-8">
                    <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-400">Avaliações em breve</p>
                  </div>
                )}
              </div>
            </TabsContent>
          </Tabs>
        </div>

        <div className="border-t border-purple-500/20 pt-6 flex items-center justify-between">
          <div className="text-sm text-gray-400">
            {hasAccess ? (
              <span className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-400 rounded-full" />
                <span>Você tem acesso a este módulo</span>
              </span>
            ) : (
              <span className="flex items-center space-x-2">
                <Crown className="h-4 w-4 text-yellow-400" />
                <span>Requer plano Premium</span>
              </span>
            )}
          </div>

          <div className="flex items-center space-x-3">
            <Button variant="outline" onClick={onClose}>
              Fechar
            </Button>
            {hasAccess ? (
              <Button onClick={handleStartClick} className="bg-purple-600 hover:bg-purple-700">
                <span>Começar Agora</span>
                <ArrowRight className="h-4 w-4 ml-2" />
              </Button>
            ) : (
              <Button
                asChild
                className="bg-gradient-to-r from-yellow-400 to-orange-500 text-black hover:from-yellow-500 hover:to-orange-600"
              >
                <Link href="/pricing">
                  <Crown className="h-4 w-4 mr-2" />
                  Upgrade Premium
                </Link>
              </Button>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
