"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Crown, ArrowRight, Lock } from "lucide-react"
import { useAuth } from "@/lib/auth/auth-context"
import { useAnalytics } from "@/components/analytics/analytics-provider"
import { motion } from "framer-motion"

interface ModuleCardProps {
  title: string
  description: string
  icon: React.ComponentType<{ className?: string }>
  features: string[]
  isPremium?: boolean
  comingSoon?: boolean
  onClick: () => void
  className?: string
}

export function ModuleCard({
  title,
  description,
  icon: Icon,
  features,
  isPremium = false,
  comingSoon = false,
  onClick,
  className = "",
}: ModuleCardProps) {
  const [isHovered, setIsHovered] = useState(false)
  const { user } = useAuth()
  const { trackEvent } = useAnalytics()

  const userPlan = user?.user_metadata?.plan || "free"
  const hasAccess = !isPremium || userPlan === "premium" || userPlan === "family"

  const handleClick = () => {
    trackEvent("module_card_click", {
      module: title,
      has_access: hasAccess,
      user_plan: userPlan,
      is_premium: isPremium,
    })

    onClick()
  }

  return (
    <motion.div whileHover={{ y: -4, scale: 1.02 }} transition={{ duration: 0.2 }} className={className}>
      <Card
        className={`
          h-full cursor-pointer transition-all duration-300 border-2
          ${
            hasAccess && !comingSoon
              ? "hover:border-purple-500/50 hover:shadow-lg hover:shadow-purple-500/25 bg-gradient-to-br from-slate-800/50 to-slate-900/50"
              : "border-gray-600 bg-slate-800/30"
          }
          ${comingSoon ? "opacity-60" : ""}
          backdrop-blur-sm
        `}
        onClick={!comingSoon ? handleClick : undefined}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        <CardHeader className="pb-4">
          <div className="flex items-start justify-between">
            <div className="flex items-center space-x-3">
              <div
                className={`
                p-3 rounded-xl transition-colors duration-300
                ${hasAccess && !comingSoon ? "bg-purple-600/20 text-purple-400" : "bg-gray-600/20 text-gray-400"}
              `}
              >
                <Icon className="h-6 w-6" />
              </div>
              <div>
                <CardTitle className="text-lg text-white flex items-center space-x-2">
                  <span>{title}</span>
                  {isPremium && <Crown className="h-4 w-4 text-yellow-400" />}
                  {!hasAccess && <Lock className="h-4 w-4 text-gray-400" />}
                </CardTitle>
              </div>
            </div>

            <div className="flex flex-col items-end space-y-2">
              {isPremium && (
                <Badge
                  variant="secondary"
                  className="bg-gradient-to-r from-yellow-400 to-orange-500 text-black text-xs"
                >
                  Premium
                </Badge>
              )}
              {comingSoon && (
                <Badge variant="outline" className="text-xs border-gray-500 text-gray-400">
                  Em Breve
                </Badge>
              )}
            </div>
          </div>
        </CardHeader>

        <CardContent className="space-y-4">
          <p className="text-gray-300 text-sm leading-relaxed">{description}</p>

          <div className="space-y-2">
            <h4 className="text-sm font-medium text-white">Recursos inclusos:</h4>
            <ul className="space-y-1">
              {features.slice(0, 3).map((feature, index) => (
                <li key={index} className="flex items-center space-x-2 text-xs text-gray-400">
                  <div className="w-1.5 h-1.5 bg-purple-400 rounded-full flex-shrink-0" />
                  <span>{feature}</span>
                </li>
              ))}
              {features.length > 3 && (
                <li className="text-xs text-purple-400 font-medium">+{features.length - 3} recursos adicionais</li>
              )}
            </ul>
          </div>

          <div className="pt-2">
            {comingSoon ? (
              <Button disabled className="w-full bg-gray-600 text-gray-400 cursor-not-allowed">
                Em Desenvolvimento
              </Button>
            ) : hasAccess ? (
              <Button className="w-full bg-purple-600 hover:bg-purple-700 text-white transition-all duration-300">
                <span>Explorar Agora</span>
                <ArrowRight
                  className={`h-4 w-4 ml-2 transition-transform duration-300 ${isHovered ? "translate-x-1" : ""}`}
                />
              </Button>
            ) : (
              <Button
                variant="outline"
                className="w-full border-yellow-400/50 text-yellow-400 hover:bg-yellow-400/10 bg-transparent"
              >
                <Crown className="h-4 w-4 mr-2" />
                Upgrade para Acessar
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  )
}
