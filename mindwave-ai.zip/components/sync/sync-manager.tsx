"use client"

import { useEffect, useState } from "react"
import { motion } from "framer-motion"
import { Badge } from "@/components/ui/badge"
import { useAuth } from "@/lib/auth/auth-context"
import { createClient } from "@/lib/supabase/client"
import { Cloud, CloudOff, RefreshCw, AlertTriangle } from "lucide-react"

interface SyncStatus {
  status: "synced" | "syncing" | "error" | "offline"
  lastSync: Date | null
  pendingChanges: number
}

export function SyncManager() {
  const [syncStatus, setSyncStatus] = useState<SyncStatus>({
    status: "synced",
    lastSync: null,
    pendingChanges: 0,
  })
  const [isOnline, setIsOnline] = useState(navigator.onLine)
  const { user } = useAuth()
  const supabase = createClient()

  useEffect(() => {
    // Monitor online/offline status
    const handleOnline = () => {
      setIsOnline(true)
      syncData()
    }
    const handleOffline = () => {
      setIsOnline(false)
      setSyncStatus((prev) => ({ ...prev, status: "offline" }))
    }

    window.addEventListener("online", handleOnline)
    window.addEventListener("offline", handleOffline)

    // Setup real-time sync
    if (user && isOnline) {
      setupRealtimeSync()
      syncData()
    }

    return () => {
      window.removeEventListener("online", handleOnline)
      window.removeEventListener("offline", handleOffline)
    }
  }, [user, isOnline])

  const setupRealtimeSync = () => {
    const channel = supabase
      .channel("sync")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "mood_entries",
          filter: `user_id=eq.${user?.id}`,
        },
        () => {
          setSyncStatus((prev) => ({ ...prev, lastSync: new Date() }))
        },
      )
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "chat_messages",
          filter: `user_id=eq.${user?.id}`,
        },
        () => {
          setSyncStatus((prev) => ({ ...prev, lastSync: new Date() }))
        },
      )
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }

  const syncData = async () => {
    if (!user || !isOnline) return

    setSyncStatus((prev) => ({ ...prev, status: "syncing" }))

    try {
      // Sync pending local changes
      await syncPendingChanges()

      // Update sync status
      setSyncStatus({
        status: "synced",
        lastSync: new Date(),
        pendingChanges: 0,
      })
    } catch (error) {
      console.error("Sync error:", error)
      setSyncStatus((prev) => ({
        ...prev,
        status: "error",
      }))
    }
  }

  const syncPendingChanges = async () => {
    // Get pending changes from local storage
    const pendingMoods = JSON.parse(localStorage.getItem("pendingMoods") || "[]")
    const pendingMessages = JSON.parse(localStorage.getItem("pendingMessages") || "[]")

    // Sync mood entries
    for (const mood of pendingMoods) {
      try {
        await supabase.from("mood_entries").insert({
          user_id: user?.id,
          mood_score: mood.mood_score,
          note: mood.note,
          tags: mood.tags,
        })
      } catch (error) {
        console.error("Error syncing mood:", error)
      }
    }

    // Sync chat messages
    for (const message of pendingMessages) {
      try {
        await supabase.from("chat_messages").insert({
          user_id: user?.id,
          content: message.content,
          sender: message.sender,
          message_type: message.message_type,
        })
      } catch (error) {
        console.error("Error syncing message:", error)
      }
    }

    // Clear pending changes
    localStorage.removeItem("pendingMoods")
    localStorage.removeItem("pendingMessages")
  }

  const getSyncIcon = () => {
    switch (syncStatus.status) {
      case "synced":
        return <Cloud className="h-3 w-3" />
      case "syncing":
        return <RefreshCw className="h-3 w-3 animate-spin" />
      case "error":
        return <AlertTriangle className="h-3 w-3" />
      case "offline":
        return <CloudOff className="h-3 w-3" />
      default:
        return <Cloud className="h-3 w-3" />
    }
  }

  const getSyncColor = () => {
    switch (syncStatus.status) {
      case "synced":
        return "bg-green-900/50 text-green-300 border-green-800"
      case "syncing":
        return "bg-blue-900/50 text-blue-300 border-blue-800"
      case "error":
        return "bg-red-900/50 text-red-300 border-red-800"
      case "offline":
        return "bg-gray-800 text-gray-400 border-gray-600"
      default:
        return "bg-gray-800 text-gray-400 border-gray-600"
    }
  }

  const getSyncText = () => {
    switch (syncStatus.status) {
      case "synced":
        return "Sincronizado"
      case "syncing":
        return "Sincronizando..."
      case "error":
        return "Erro na sincronização"
      case "offline":
        return "Offline"
      default:
        return "Desconhecido"
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      className="flex items-center space-x-2"
    >
      <Badge variant="secondary" className={`text-xs ${getSyncColor()}`}>
        {getSyncIcon()}
        <span className="ml-1">{getSyncText()}</span>
      </Badge>

      {syncStatus.pendingChanges > 0 && (
        <Badge variant="outline" className="text-xs bg-yellow-900/30 border-yellow-700 text-yellow-300">
          {syncStatus.pendingChanges} pendente{syncStatus.pendingChanges > 1 ? "s" : ""}
        </Badge>
      )}

      {syncStatus.lastSync && (
        <span className="text-xs text-gray-500">Última sync: {syncStatus.lastSync.toLocaleTimeString()}</span>
      )}
    </motion.div>
  )
}
