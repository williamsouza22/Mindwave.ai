"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { useAuth } from "@/lib/auth/auth-context"
import { useToast } from "@/hooks/use-toast"
import {
  Heart,
  ArrowRight,
  ArrowLeft,
  Check,
  Brain,
  Smartphone,
  Leaf,
  Users,
  Bell,
  Shield,
  Sparkles,
  Target,
} from "lucide-react"

interface OnboardingStep {
  id: string
  title: string
  description: string
  component: React.ComponentType<any>
}

const painPoints = [
  { id: "anxiety", label: "Ansiedade", icon: Brain, color: "from-blue-500 to-blue-600", emoji: "😰" },
  { id: "burnout", label: "Burnout", icon: Target, color: "from-orange-500 to-red-500", emoji: "😴" },
  { id: "nomophobia", label: "Vício no celular", icon: Smartphone, color: "from-purple-500 to-pink-500", emoji: "📱" },
  { id: "eco-anxiety", label: "Ecoansiedade", icon: Leaf, color: "from-green-500 to-emerald-500", emoji: "🌍" },
  { id: "self-care", label: "Autocuidado", icon: Heart, color: "from-pink-500 to-rose-500", emoji: "💝" },
  { id: "support", label: "Apoio emocional", icon: Users, color: "from-indigo-500 to-purple-500", emoji: "🤝" },
]

const goals = [
  { id: "daily-checkin", label: "Check-ins diários", description: "Acompanhar meu humor todos os dias" },
  { id: "meditation", label: "Meditação regular", description: "Praticar mindfulness e relaxamento" },
  { id: "journal", label: "Diário emocional", description: "Registrar pensamentos e sentimentos" },
  { id: "crisis-support", label: "Apoio em crises", description: "Ter suporte imediato quando precisar" },
  { id: "progress-tracking", label: "Acompanhar progresso", description: "Ver minha evolução ao longo do tempo" },
  { id: "community", label: "Conectar com outros", description: "Participar de uma comunidade de apoio" },
]

// Step 1: Welcome
function WelcomeStep({ onNext }: { onNext: () => void }) {
  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center space-y-6">
      <div className="space-y-4">
        <motion.div
          animate={{
            scale: [1, 1.1, 1],
            opacity: [0.8, 1, 0.8],
          }}
          transition={{
            duration: 2,
            repeat: Number.POSITIVE_INFINITY,
            ease: "easeInOut",
          }}
          className="w-20 h-20 mx-auto rounded-full bg-gradient-to-r from-blue-500 to-purple-500 flex items-center justify-center"
        >
          <Heart className="h-10 w-10 text-white" />
        </motion.div>

        <h2 className="text-3xl font-bold text-white">Bem-vindo ao MindWave.AI! 🎉</h2>
        <p className="text-gray-300 text-lg max-w-md mx-auto">
          Vamos personalizar sua experiência em apenas alguns passos para que possamos te apoiar da melhor forma.
        </p>
      </div>

      <div className="space-y-4">
        <div className="grid grid-cols-2 gap-4 max-w-sm mx-auto">
          <div className="text-center p-4 bg-blue-900/20 rounded-lg border border-blue-800">
            <Sparkles className="h-6 w-6 text-blue-400 mx-auto mb-2" />
            <p className="text-sm text-blue-300">IA Empática</p>
          </div>
          <div className="text-center p-4 bg-green-900/20 rounded-lg border border-green-800">
            <Shield className="h-6 w-6 text-green-400 mx-auto mb-2" />
            <p className="text-sm text-green-300">100% Privado</p>
          </div>
        </div>

        <Button
          onClick={onNext}
          size="lg"
          className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
        >
          Vamos começar
          <ArrowRight className="h-4 w-4 ml-2" />
        </Button>
      </div>
    </motion.div>
  )
}

// Step 2: Pain Points Selection
function PainPointsStep({
  selectedPainPoints,
  setSelectedPainPoints,
  onNext,
  onBack,
}: {
  selectedPainPoints: string[]
  setSelectedPainPoints: (points: string[]) => void
  onNext: () => void
  onBack: () => void
}) {
  const togglePainPoint = (id: string) => {
    setSelectedPainPoints(
      selectedPainPoints.includes(id) ? selectedPainPoints.filter((p) => p !== id) : [...selectedPainPoints, id],
    )
  }

  return (
    <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-6">
      <div className="text-center space-y-2">
        <h2 className="text-2xl font-bold text-white">Como podemos te ajudar?</h2>
        <p className="text-gray-400">Selecione os temas que mais se identificam com você (pode escolher vários)</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {painPoints.map((point) => (
          <motion.div key={point.id} whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
            <Card
              className={`cursor-pointer transition-all duration-300 ${
                selectedPainPoints.includes(point.id)
                  ? `bg-gradient-to-r ${point.color} border-transparent`
                  : "bg-[#1A2332] border-gray-700 hover:border-gray-600"
              }`}
              onClick={() => togglePainPoint(point.id)}
            >
              <CardContent className="p-4">
                <div className="flex items-center space-x-3">
                  <span className="text-2xl">{point.emoji}</span>
                  <div className="flex-1">
                    <h3
                      className={`font-medium ${
                        selectedPainPoints.includes(point.id) ? "text-white" : "text-gray-200"
                      }`}
                    >
                      {point.label}
                    </h3>
                  </div>
                  {selectedPainPoints.includes(point.id) && <Check className="h-5 w-5 text-white" />}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      <div className="flex justify-between">
        <Button variant="outline" onClick={onBack} className="bg-transparent border-gray-700 text-gray-300">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Voltar
        </Button>
        <Button
          onClick={onNext}
          disabled={selectedPainPoints.length === 0}
          className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
        >
          Continuar
          <ArrowRight className="h-4 w-4 ml-2" />
        </Button>
      </div>
    </motion.div>
  )
}

// Step 3: Goals Selection
function GoalsStep({
  selectedGoals,
  setSelectedGoals,
  onNext,
  onBack,
}: {
  selectedGoals: string[]
  setSelectedGoals: (goals: string[]) => void
  onNext: () => void
  onBack: () => void
}) {
  const toggleGoal = (id: string) => {
    setSelectedGoals(selectedGoals.includes(id) ? selectedGoals.filter((g) => g !== id) : [...selectedGoals, id])
  }

  return (
    <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-6">
      <div className="text-center space-y-2">
        <h2 className="text-2xl font-bold text-white">Quais são seus objetivos?</h2>
        <p className="text-gray-400">Escolha o que você gostaria de alcançar com o MindWave.AI</p>
      </div>

      <div className="space-y-3">
        {goals.map((goal) => (
          <motion.div key={goal.id} whileHover={{ scale: 1.01 }} whileTap={{ scale: 0.99 }}>
            <Card
              className={`cursor-pointer transition-all duration-300 ${
                selectedGoals.includes(goal.id)
                  ? "bg-blue-900/30 border-blue-600"
                  : "bg-[#1A2332] border-gray-700 hover:border-gray-600"
              }`}
              onClick={() => toggleGoal(goal.id)}
            >
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <h3
                      className={`font-medium ${selectedGoals.includes(goal.id) ? "text-blue-300" : "text-gray-200"}`}
                    >
                      {goal.label}
                    </h3>
                    <p className="text-sm text-gray-400 mt-1">{goal.description}</p>
                  </div>
                  {selectedGoals.includes(goal.id) && <Check className="h-5 w-5 text-blue-400" />}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      <div className="flex justify-between">
        <Button variant="outline" onClick={onBack} className="bg-transparent border-gray-700 text-gray-300">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Voltar
        </Button>
        <Button
          onClick={onNext}
          disabled={selectedGoals.length === 0}
          className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
        >
          Continuar
          <ArrowRight className="h-4 w-4 ml-2" />
        </Button>
      </div>
    </motion.div>
  )
}

// Step 4: Notifications Setup
function NotificationsStep({
  notificationSettings,
  setNotificationSettings,
  onNext,
  onBack,
}: {
  notificationSettings: any
  setNotificationSettings: (settings: any) => void
  onNext: () => void
  onBack: () => void
}) {
  const [permissionStatus, setPermissionStatus] = useState<string>("default")

  useEffect(() => {
    if ("Notification" in window) {
      setPermissionStatus(Notification.permission)
    }
  }, [])

  const requestNotificationPermission = async () => {
    if ("Notification" in window) {
      const permission = await Notification.requestPermission()
      setPermissionStatus(permission)
      if (permission === "granted") {
        setNotificationSettings({ ...notificationSettings, enabled: true })
      }
    }
  }

  return (
    <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-6">
      <div className="text-center space-y-2">
        <Bell className="h-12 w-12 text-blue-400 mx-auto" />
        <h2 className="text-2xl font-bold text-white">Notificações Inteligentes</h2>
        <p className="text-gray-400">Receba lembretes gentis para cuidar da sua saúde mental</p>
      </div>

      <div className="space-y-4">
        <Card className="bg-[#1A2332] border-gray-700">
          <CardContent className="p-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium text-white">Ativar notificações</h3>
                  <p className="text-sm text-gray-400">Lembretes para check-ins e meditação</p>
                </div>
                <Button
                  onClick={requestNotificationPermission}
                  disabled={permissionStatus === "granted"}
                  className={
                    permissionStatus === "granted" ? "bg-green-600 hover:bg-green-700" : "bg-blue-600 hover:bg-blue-700"
                  }
                >
                  {permissionStatus === "granted" ? (
                    <>
                      <Check className="h-4 w-4 mr-2" />
                      Ativado
                    </>
                  ) : (
                    "Ativar"
                  )}
                </Button>
              </div>

              {permissionStatus === "granted" && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  className="space-y-3 pt-4 border-t border-gray-700"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-300">Check-in diário</span>
                    <input
                      type="checkbox"
                      checked={notificationSettings.dailyCheckin}
                      onChange={(e) =>
                        setNotificationSettings({
                          ...notificationSettings,
                          dailyCheckin: e.target.checked,
                        })
                      }
                      className="rounded border-gray-600 text-blue-600 focus:ring-blue-500"
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-300">Lembrete de meditação</span>
                    <input
                      type="checkbox"
                      checked={notificationSettings.meditation}
                      onChange={(e) =>
                        setNotificationSettings({
                          ...notificationSettings,
                          meditation: e.target.checked,
                        })
                      }
                      className="rounded border-gray-600 text-blue-600 focus:ring-blue-500"
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-300">Mensagens motivacionais</span>
                    <input
                      type="checkbox"
                      checked={notificationSettings.motivational}
                      onChange={(e) =>
                        setNotificationSettings({
                          ...notificationSettings,
                          motivational: e.target.checked,
                        })
                      }
                      className="rounded border-gray-600 text-blue-600 focus:ring-blue-500"
                    />
                  </div>
                </motion.div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="flex justify-between">
        <Button variant="outline" onClick={onBack} className="bg-transparent border-gray-700 text-gray-300">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Voltar
        </Button>
        <Button
          onClick={onNext}
          className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
        >
          Continuar
          <ArrowRight className="h-4 w-4 ml-2" />
        </Button>
      </div>
    </motion.div>
  )
}

// Step 5: Completion
function CompletionStep({ onComplete }: { onComplete: () => void }) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      className="text-center space-y-6"
    >
      <motion.div
        animate={{
          rotate: [0, 10, -10, 0],
        }}
        transition={{
          duration: 0.6,
          repeat: 2,
        }}
        className="w-20 h-20 mx-auto rounded-full bg-gradient-to-r from-green-500 to-blue-500 flex items-center justify-center"
      >
        <Check className="h-10 w-10 text-white" />
      </motion.div>

      <div className="space-y-4">
        <h2 className="text-3xl font-bold text-white">Tudo pronto! 🎉</h2>
        <p className="text-gray-300 text-lg max-w-md mx-auto">
          Sua jornada de bem-estar mental personalizada está configurada. Vamos começar a cuidar da sua mente juntos!
        </p>
      </div>

      <div className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-lg mx-auto">
          <div className="text-center p-4 bg-blue-900/20 rounded-lg border border-blue-800">
            <Heart className="h-6 w-6 text-blue-400 mx-auto mb-2" />
            <p className="text-sm text-blue-300">IA Personalizada</p>
          </div>
          <div className="text-center p-4 bg-green-900/20 rounded-lg border border-green-800">
            <Bell className="h-6 w-6 text-green-400 mx-auto mb-2" />
            <p className="text-sm text-green-300">Notificações Ativas</p>
          </div>
          <div className="text-center p-4 bg-purple-900/20 rounded-lg border border-purple-800">
            <Sparkles className="h-6 w-6 text-purple-400 mx-auto mb-2" />
            <p className="text-sm text-purple-300">Pronto para Usar</p>
          </div>
        </div>

        <Button
          onClick={onComplete}
          size="lg"
          className="bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700"
        >
          Ir para o Dashboard
          <ArrowRight className="h-4 w-4 ml-2" />
        </Button>
      </div>
    </motion.div>
  )
}

export function OnboardingFlow() {
  const [currentStep, setCurrentStep] = useState(0)
  const [selectedPainPoints, setSelectedPainPoints] = useState<string[]>([])
  const [selectedGoals, setSelectedGoals] = useState<string[]>([])
  const [notificationSettings, setNotificationSettings] = useState({
    enabled: false,
    dailyCheckin: true,
    meditation: true,
    motivational: false,
  })

  const { updateProfile } = useAuth()
  const { toast } = useToast()

  const steps = [
    { component: WelcomeStep },
    { component: PainPointsStep },
    { component: GoalsStep },
    { component: NotificationsStep },
    { component: CompletionStep },
  ]

  const progress = ((currentStep + 1) / steps.length) * 100

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1)
    }
  }

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1)
    }
  }

  const handleComplete = async () => {
    try {
      await updateProfile({
        onboarding_completed: true,
      })

      // Save onboarding data to analytics
      await fetch("/api/analytics/onboarding", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          painPoints: selectedPainPoints,
          goals: selectedGoals,
          notifications: notificationSettings,
        }),
      })

      toast({
        title: "Bem-vindo ao MindWave.AI! 🎉",
        description: "Sua jornada de bem-estar mental começa agora.",
      })

      // Redirect to dashboard
      window.location.href = "/dashboard"
    } catch (error) {
      toast({
        title: "Erro ao finalizar configuração",
        description: "Tente novamente em alguns instantes.",
        variant: "destructive",
      })
    }
  }

  const CurrentStepComponent = steps[currentStep].component

  return (
    <div className="min-h-screen bg-[#0B1426] flex items-center justify-center p-4">
      <div className="w-full max-w-2xl">
        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-gray-400">
              Passo {currentStep + 1} de {steps.length}
            </span>
            <span className="text-sm text-gray-400">{Math.round(progress)}%</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        {/* Step Content */}
        <Card className="bg-[#1A2332] border-gray-800">
          <CardContent className="p-8">
            <AnimatePresence mode="wait">
              <CurrentStepComponent
                key={currentStep}
                selectedPainPoints={selectedPainPoints}
                setSelectedPainPoints={setSelectedPainPoints}
                selectedGoals={selectedGoals}
                setSelectedGoals={setSelectedGoals}
                notificationSettings={notificationSettings}
                setNotificationSettings={setNotificationSettings}
                onNext={handleNext}
                onBack={handleBack}
                onComplete={handleComplete}
              />
            </AnimatePresence>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
