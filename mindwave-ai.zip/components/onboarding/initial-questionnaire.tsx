"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Heart, Brain, Zap, Users, ArrowRight, ArrowLeft } from "lucide-react"

interface QuestionnaireData {
  currentMood: string
  mainChallenge: string
  stressLevel: string
  sleepQuality: string
  supportSystem: string
  goals: string[]
  personalNote: string
}

const moodOptions = [
  { value: "very-good", label: "Muito bem", emoji: "😊", color: "bg-green-500" },
  { value: "good", label: "Bem", emoji: "🙂", color: "bg-blue-500" },
  { value: "neutral", label: "Neutro", emoji: "😐", color: "bg-yellow-500" },
  { value: "bad", label: "Mal", emoji: "😕", color: "bg-orange-500" },
  { value: "very-bad", label: "Muito mal", emoji: "😢", color: "bg-red-500" },
]

const challenges = [
  { value: "anxiety", label: "Ansiedade", icon: Brain },
  { value: "depression", label: "Depressão", icon: Heart },
  { value: "stress", label: "Estresse", icon: Zap },
  { value: "loneliness", label: "Solidão", icon: Users },
  { value: "burnout", label: "Burnout", icon: Brain },
  { value: "relationships", label: "Relacionamentos", icon: Users },
]

const stressLevels = [
  { value: "1", label: "Muito baixo" },
  { value: "2", label: "Baixo" },
  { value: "3", label: "Moderado" },
  { value: "4", label: "Alto" },
  { value: "5", label: "Muito alto" },
]

interface InitialQuestionnaireProps {
  onComplete: (data: QuestionnaireData) => void
  onBack: () => void
}

export function InitialQuestionnaire({ onComplete, onBack }: InitialQuestionnaireProps) {
  const [currentStep, setCurrentStep] = useState(0)
  const [data, setData] = useState<QuestionnaireData>({
    currentMood: "",
    mainChallenge: "",
    stressLevel: "",
    sleepQuality: "",
    supportSystem: "",
    goals: [],
    personalNote: "",
  })

  const steps = [
    {
      title: "Como você tem se sentido ultimamente?",
      component: MoodStep,
    },
    {
      title: "Qual seu maior desafio emocional agora?",
      component: ChallengeStep,
    },
    {
      title: "Vamos entender melhor seu contexto",
      component: ContextStep,
    },
    {
      title: "Conte-nos um pouco mais sobre você",
      component: PersonalStep,
    },
  ]

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1)
    } else {
      onComplete(data)
    }
  }

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1)
    } else {
      onBack()
    }
  }

  const updateData = (updates: Partial<QuestionnaireData>) => {
    setData((prev) => ({ ...prev, ...updates }))
  }

  const CurrentStep = steps[currentStep].component

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
      <div className="text-center space-y-2">
        <Badge variant="secondary" className="mb-2">
          Questionário Inicial
        </Badge>
        <h2 className="text-2xl font-bold text-white">{steps[currentStep].title}</h2>
        <p className="text-gray-400">
          Passo {currentStep + 1} de {steps.length}
        </p>
      </div>

      <Card className="bg-[#1A2332] border-gray-700">
        <CardContent className="p-6">
          <CurrentStep data={data} updateData={updateData} />
        </CardContent>
      </Card>

      <div className="flex justify-between">
        <Button variant="outline" onClick={handleBack} className="bg-transparent border-gray-700 text-gray-300">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Voltar
        </Button>
        <Button
          onClick={handleNext}
          className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
        >
          {currentStep === steps.length - 1 ? "Finalizar" : "Continuar"}
          <ArrowRight className="h-4 w-4 ml-2" />
        </Button>
      </div>
    </motion.div>
  )
}

function MoodStep({
  data,
  updateData,
}: { data: QuestionnaireData; updateData: (updates: Partial<QuestionnaireData>) => void }) {
  return (
    <div className="space-y-4">
      <p className="text-gray-300 text-center mb-6">
        Selecione como você tem se sentido na maior parte dos últimos dias:
      </p>
      <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
        {moodOptions.map((mood) => (
          <motion.div key={mood.value} whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
            <Card
              className={`cursor-pointer transition-all duration-300 ${
                data.currentMood === mood.value
                  ? `${mood.color} border-transparent text-white`
                  : "bg-gray-800 border-gray-600 hover:border-gray-500"
              }`}
              onClick={() => updateData({ currentMood: mood.value })}
            >
              <CardContent className="p-4 text-center">
                <div className="text-3xl mb-2">{mood.emoji}</div>
                <p className="text-sm font-medium">{mood.label}</p>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  )
}

function ChallengeStep({
  data,
  updateData,
}: { data: QuestionnaireData; updateData: (updates: Partial<QuestionnaireData>) => void }) {
  return (
    <div className="space-y-4">
      <p className="text-gray-300 text-center mb-6">Qual área você gostaria de trabalhar primeiro?</p>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {challenges.map((challenge) => {
          const Icon = challenge.icon
          return (
            <motion.div key={challenge.value} whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
              <Card
                className={`cursor-pointer transition-all duration-300 ${
                  data.mainChallenge === challenge.value
                    ? "bg-blue-900/50 border-blue-500"
                    : "bg-gray-800 border-gray-600 hover:border-gray-500"
                }`}
                onClick={() => updateData({ mainChallenge: challenge.value })}
              >
                <CardContent className="p-4">
                  <div className="flex items-center space-x-3">
                    <Icon className="h-6 w-6 text-blue-400" />
                    <span className="font-medium text-white">{challenge.label}</span>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )
        })}
      </div>
    </div>
  )
}

function ContextStep({
  data,
  updateData,
}: { data: QuestionnaireData; updateData: (updates: Partial<QuestionnaireData>) => void }) {
  return (
    <div className="space-y-6">
      <div className="space-y-4">
        <Label className="text-white">Nível de estresse atual (1-5):</Label>
        <RadioGroup
          value={data.stressLevel}
          onValueChange={(value) => updateData({ stressLevel: value })}
          className="flex justify-between"
        >
          {stressLevels.map((level) => (
            <div key={level.value} className="flex items-center space-x-2">
              <RadioGroupItem value={level.value} id={level.value} />
              <Label htmlFor={level.value} className="text-sm text-gray-300">
                {level.value}
              </Label>
            </div>
          ))}
        </RadioGroup>
        <div className="flex justify-between text-xs text-gray-400">
          <span>Muito baixo</span>
          <span>Muito alto</span>
        </div>
      </div>

      <div className="space-y-4">
        <Label className="text-white">Como tem sido seu sono?</Label>
        <RadioGroup value={data.sleepQuality} onValueChange={(value) => updateData({ sleepQuality: value })}>
          {[
            { value: "excellent", label: "Excelente - durmo bem todas as noites" },
            { value: "good", label: "Bom - algumas noites ruins" },
            { value: "fair", label: "Regular - acordo cansado frequentemente" },
            { value: "poor", label: "Ruim - tenho insônia ou sono fragmentado" },
          ].map((option) => (
            <div key={option.value} className="flex items-center space-x-2">
              <RadioGroupItem value={option.value} id={option.value} />
              <Label htmlFor={option.value} className="text-gray-300">
                {option.label}
              </Label>
            </div>
          ))}
        </RadioGroup>
      </div>

      <div className="space-y-4">
        <Label className="text-white">Você tem uma rede de apoio?</Label>
        <RadioGroup value={data.supportSystem} onValueChange={(value) => updateData({ supportSystem: value })}>
          {[
            { value: "strong", label: "Sim, tenho família/amigos próximos" },
            { value: "moderate", label: "Algumas pessoas, mas não muito próximas" },
            { value: "weak", label: "Poucas pessoas em quem posso confiar" },
            { value: "none", label: "Me sinto sozinho(a) na maior parte do tempo" },
          ].map((option) => (
            <div key={option.value} className="flex items-center space-x-2">
              <RadioGroupItem value={option.value} id={option.value} />
              <Label htmlFor={option.value} className="text-gray-300">
                {option.label}
              </Label>
            </div>
          ))}
        </RadioGroup>
      </div>
    </div>
  )
}

function PersonalStep({
  data,
  updateData,
}: { data: QuestionnaireData; updateData: (updates: Partial<QuestionnaireData>) => void }) {
  return (
    <div className="space-y-6">
      <div className="space-y-4">
        <Label className="text-white">
          Há algo específico que você gostaria que soubéssemos sobre sua situação atual?
        </Label>
        <Textarea
          placeholder="Compartilhe o que quiser... Estamos aqui para te apoiar."
          value={data.personalNote}
          onChange={(e) => updateData({ personalNote: e.target.value })}
          className="bg-gray-800 border-gray-600 text-white placeholder-gray-400"
          rows={4}
        />
      </div>

      <div className="p-4 bg-blue-900/20 rounded-lg border border-blue-800">
        <div className="flex items-start space-x-3">
          <Heart className="h-5 w-5 text-blue-400 mt-0.5" />
          <div>
            <p className="text-blue-300 font-medium text-sm">Lembre-se</p>
            <p className="text-blue-200 text-sm">
              Suas informações são completamente privadas e seguras. Usaremos esses dados apenas para personalizar sua
              experiência e oferecer o melhor suporte possível.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
