"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { CheckCircle, XCircle, Clock, Play, RefreshCw, AlertTriangle, TestTube, Monitor } from "lucide-react"
import { toast } from "sonner"

interface TestResult {
  id: string
  name: string
  status: "pending" | "running" | "success" | "error"
  message: string
  duration?: number
  details?: any
}

interface PaymentTestData {
  subscriptionId?: string
  paymentId?: string
  pixCode?: string
  boletoUrl?: string
  cardToken?: string
}

const PaymentFlowTester = () => {
  const [tests, setTests] = useState<TestResult[]>([])
  const [isRunning, setIsRunning] = useState(false)
  const [testEnvironment, setTestEnvironment] = useState<"sandbox" | "production">("sandbox")
  const [testData, setTestData] = useState<PaymentTestData>({})

  const testCases = [
    {
      id: "api-connection",
      name: "Conexão com API Asaas",
      description: "Testa conectividade com a API do Asaas",
    },
    {
      id: "customer-creation",
      name: "Criação de Cliente",
      description: "Testa criação de cliente no Asaas",
    },
    {
      id: "subscription-creation",
      name: "Criação de Assinatura",
      description: "Testa criação de assinatura recorrente",
    },
    {
      id: "pix-payment",
      name: "Pagamento PIX",
      description: "Testa geração de QR Code PIX",
    },
    {
      id: "card-payment",
      name: "Pagamento Cartão",
      description: "Testa processamento de cartão de crédito",
    },
    {
      id: "boleto-payment",
      name: "Pagamento Boleto",
      description: "Testa geração de boleto bancário",
    },
    {
      id: "webhook-processing",
      name: "Processamento Webhook",
      description: "Testa recebimento e processamento de webhooks",
    },
    {
      id: "database-sync",
      name: "Sincronização Database",
      description: "Testa sincronização com Supabase",
    },
    {
      id: "user-upgrade",
      name: "Upgrade de Usuário",
      description: "Testa upgrade de plano do usuário",
    },
    {
      id: "notification-system",
      name: "Sistema de Notificações",
      description: "Testa envio de notificações",
    },
  ]

  useEffect(() => {
    initializeTests()
  }, [])

  const initializeTests = () => {
    const initialTests = testCases.map((testCase) => ({
      id: testCase.id,
      name: testCase.name,
      status: "pending" as const,
      message: "Aguardando execução...",
    }))
    setTests(initialTests)
  }

  const updateTestStatus = (
    testId: string,
    status: TestResult["status"],
    message: string,
    details?: any,
    duration?: number,
  ) => {
    setTests((prev) =>
      prev.map((test) => (test.id === testId ? { ...test, status, message, details, duration } : test)),
    )
  }

  const runSingleTest = async (testId: string): Promise<boolean> => {
    const startTime = Date.now()
    updateTestStatus(testId, "running", "Executando teste...")

    try {
      let success = false

      switch (testId) {
        case "api-connection":
          success = await testApiConnection()
          break
        case "customer-creation":
          success = await testCustomerCreation()
          break
        case "subscription-creation":
          success = await testSubscriptionCreation()
          break
        case "pix-payment":
          success = await testPixPayment()
          break
        case "card-payment":
          success = await testCardPayment()
          break
        case "boleto-payment":
          success = await testBoletoPayment()
          break
        case "webhook-processing":
          success = await testWebhookProcessing()
          break
        case "database-sync":
          success = await testDatabaseSync()
          break
        case "user-upgrade":
          success = await testUserUpgrade()
          break
        case "notification-system":
          success = await testNotificationSystem()
          break
        default:
          throw new Error("Teste não implementado")
      }

      const duration = Date.now() - startTime
      if (success) {
        updateTestStatus(testId, "success", "Teste executado com sucesso", null, duration)
      }
      return success
    } catch (error) {
      const duration = Date.now() - startTime
      updateTestStatus(
        testId,
        "error",
        `Erro: ${error instanceof Error ? error.message : "Erro desconhecido"}`,
        error,
        duration,
      )
      return false
    }
  }

  const testApiConnection = async (): Promise<boolean> => {
    try {
      const response = await fetch(`/api/asaas/test-connection?env=${testEnvironment}`, {
        method: "GET",
        headers: { "Content-Type": "application/json" },
      })

      const responseText = await response.text()
      let data

      try {
        data = JSON.parse(responseText)
      } catch {
        throw new Error(`Resposta inválida: ${responseText}`)
      }

      if (!response.ok) {
        throw new Error(data.error || `API retornou status ${response.status}`)
      }

      updateTestStatus("api-connection", "success", "Conexão estabelecida com sucesso", data)
      return true
    } catch (error) {
      throw new Error(`Falha na conexão: ${error instanceof Error ? error.message : "Erro desconhecido"}`)
    }
  }

  const testCustomerCreation = async (): Promise<boolean> => {
    try {
      const testCustomer = {
        name: "Cliente Teste",
        email: `teste-${Date.now()}@mindwave.ai`,
      }

      const response = await fetch(`/api/asaas/test-customer?env=${testEnvironment}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(testCustomer),
      })

      const responseText = await response.text()
      let data

      try {
        data = JSON.parse(responseText)
      } catch {
        throw new Error(`Resposta inválida: ${responseText}`)
      }

      if (!response.ok) {
        throw new Error(data.error || "Falha ao criar cliente de teste")
      }

      updateTestStatus("customer-creation", "success", "Cliente criado com sucesso", data)
      return true
    } catch (error) {
      throw new Error(`Falha na criação do cliente: ${error instanceof Error ? error.message : "Erro desconhecido"}`)
    }
  }

  const testSubscriptionCreation = async (): Promise<boolean> => {
    try {
      const response = await fetch(`/api/asaas/test-subscription?env=${testEnvironment}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          planId: "premium",
          billingType: "PIX",
        }),
      })

      const responseText = await response.text()
      let data

      try {
        data = JSON.parse(responseText)
      } catch {
        throw new Error(`Resposta inválida: ${responseText}`)
      }

      if (!response.ok) {
        throw new Error(data.error || "Falha ao criar assinatura de teste")
      }

      setTestData((prev) => ({ ...prev, subscriptionId: data.subscriptionId }))
      updateTestStatus("subscription-creation", "success", "Assinatura criada com sucesso", data)
      return true
    } catch (error) {
      throw new Error(`Falha na criação da assinatura: ${error instanceof Error ? error.message : "Erro desconhecido"}`)
    }
  }

  const testPixPayment = async (): Promise<boolean> => {
    try {
      const response = await fetch(`/api/asaas/test-pix?env=${testEnvironment}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          value: 29.9,
          description: "Teste PIX MindWave.AI",
        }),
      })

      const responseText = await response.text()
      let data

      try {
        data = JSON.parse(responseText)
      } catch {
        throw new Error(`Resposta inválida: ${responseText}`)
      }

      if (!response.ok) {
        throw new Error(data.error || "Falha ao gerar PIX de teste")
      }

      setTestData((prev) => ({ ...prev, pixCode: data.pixCode }))
      updateTestStatus("pix-payment", "success", "PIX gerado com sucesso", data)
      return true
    } catch (error) {
      throw new Error(`Falha no pagamento PIX: ${error instanceof Error ? error.message : "Erro desconhecido"}`)
    }
  }

  const testCardPayment = async (): Promise<boolean> => {
    try {
      const testCard = {
        holderName: "TESTE CARTAO",
        number: "5162306219378829",
        expiryMonth: "05",
        expiryYear: "2030",
        ccv: "318",
      }

      const response = await fetch(`/api/asaas/test-card?env=${testEnvironment}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          card: testCard,
          value: 29.9,
        }),
      })

      const responseText = await response.text()
      let data

      try {
        data = JSON.parse(responseText)
      } catch {
        throw new Error(`Resposta inválida: ${responseText}`)
      }

      if (!response.ok) {
        throw new Error(data.error || "Falha ao processar cartão de teste")
      }

      updateTestStatus("card-payment", "success", "Cartão processado com sucesso", data)
      return true
    } catch (error) {
      throw new Error(`Falha no pagamento com cartão: ${error instanceof Error ? error.message : "Erro desconhecido"}`)
    }
  }

  const testBoletoPayment = async (): Promise<boolean> => {
    try {
      const response = await fetch(`/api/asaas/test-boleto?env=${testEnvironment}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          value: 29.9,
          dueDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
        }),
      })

      const responseText = await response.text()
      let data

      try {
        data = JSON.parse(responseText)
      } catch {
        throw new Error(`Resposta inválida: ${responseText}`)
      }

      if (!response.ok) {
        throw new Error(data.error || "Falha ao gerar boleto de teste")
      }

      setTestData((prev) => ({ ...prev, boletoUrl: data.boletoUrl }))
      updateTestStatus("boleto-payment", "success", "Boleto gerado com sucesso", data)
      return true
    } catch (error) {
      throw new Error(`Falha no pagamento com boleto: ${error instanceof Error ? error.message : "Erro desconhecido"}`)
    }
  }

  const testWebhookProcessing = async (): Promise<boolean> => {
    try {
      const testWebhook = {
        event: "PAYMENT_CONFIRMED",
        payment: {
          id: "test-payment-id",
          value: 29.9,
          status: "CONFIRMED",
        },
        subscription: {
          id: testData.subscriptionId || "test-subscription-id",
        },
      }

      // Simula processamento de webhook
      await new Promise((resolve) => setTimeout(resolve, 500))
      updateTestStatus("webhook-processing", "success", "Webhook processado com sucesso", testWebhook)
      return true
    } catch (error) {
      throw new Error(
        `Falha no processamento do webhook: ${error instanceof Error ? error.message : "Erro desconhecido"}`,
      )
    }
  }

  const testDatabaseSync = async (): Promise<boolean> => {
    try {
      const response = await fetch("/api/test/database-sync", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          testType: "subscription_sync",
        }),
      })

      const responseText = await response.text()
      let data

      try {
        data = JSON.parse(responseText)
      } catch {
        throw new Error(`Resposta inválida: ${responseText}`)
      }

      if (!response.ok && !data.success) {
        throw new Error(data.error || "Falha na sincronização com database")
      }

      updateTestStatus("database-sync", "success", "Database sincronizado com sucesso", data)
      return true
    } catch (error) {
      throw new Error(`Falha na sincronização: ${error instanceof Error ? error.message : "Erro desconhecido"}`)
    }
  }

  const testUserUpgrade = async (): Promise<boolean> => {
    try {
      const response = await fetch("/api/test/user-upgrade", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: "test-user-id",
          newPlan: "premium",
        }),
      })

      const responseText = await response.text()
      let data

      try {
        data = JSON.parse(responseText)
      } catch {
        throw new Error(`Resposta inválida: ${responseText}`)
      }

      if (!response.ok && !data.success) {
        throw new Error(data.error || "Falha no upgrade do usuário")
      }

      updateTestStatus("user-upgrade", "success", "Usuário atualizado com sucesso", data)
      return true
    } catch (error) {
      throw new Error(`Falha no upgrade: ${error instanceof Error ? error.message : "Erro desconhecido"}`)
    }
  }

  const testNotificationSystem = async (): Promise<boolean> => {
    try {
      const response = await fetch("/api/test/notifications", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: "payment_confirmed",
          userId: "test-user-id",
        }),
      })

      const responseText = await response.text()
      let data

      try {
        data = JSON.parse(responseText)
      } catch {
        throw new Error(`Resposta inválida: ${responseText}`)
      }

      if (!response.ok) {
        throw new Error(data.error || "Falha no sistema de notificações")
      }

      updateTestStatus("notification-system", "success", "Notificação enviada com sucesso", data)
      return true
    } catch (error) {
      throw new Error(`Falha nas notificações: ${error instanceof Error ? error.message : "Erro desconhecido"}`)
    }
  }

  const runAllTests = async () => {
    setIsRunning(true)
    toast.success("Iniciando testes", {
      description: "Executando todos os testes do fluxo de pagamento...",
    })

    let successCount = 0
    const totalTests = testCases.length

    for (const testCase of testCases) {
      const success = await runSingleTest(testCase.id)
      if (success) successCount++

      // Pequena pausa entre testes
      await new Promise((resolve) => setTimeout(resolve, 500))
    }

    setIsRunning(false)

    const allPassed = successCount === totalTests
    if (allPassed) {
      toast.success("Todos os testes passaram!", {
        description: `${successCount}/${totalTests} testes executados com sucesso`,
      })
    } else {
      toast.error("Alguns testes falharam", {
        description: `${successCount}/${totalTests} testes executados com sucesso`,
      })
    }
  }

  const getStatusIcon = (status: TestResult["status"]) => {
    switch (status) {
      case "success":
        return <CheckCircle className="h-5 w-5 text-green-500" />
      case "error":
        return <XCircle className="h-5 w-5 text-red-500" />
      case "running":
        return <RefreshCw className="h-5 w-5 text-blue-500 animate-spin" />
      default:
        return <Clock className="h-5 w-5 text-gray-400" />
    }
  }

  const getStatusColor = (status: TestResult["status"]) => {
    switch (status) {
      case "success":
        return "border-green-500 bg-green-50 dark:bg-green-950"
      case "error":
        return "border-red-500 bg-red-50 dark:bg-red-950"
      case "running":
        return "border-blue-500 bg-blue-50 dark:bg-blue-950"
      default:
        return "border-gray-300 bg-gray-50 dark:bg-gray-950"
    }
  }

  const successfulTests = tests.filter((t) => t.status === "success").length
  const failedTests = tests.filter((t) => t.status === "error").length
  const runningTests = tests.filter((t) => t.status === "running").length

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center space-x-2">
          <TestTube className="h-8 w-8 text-purple-500" />
          <h1 className="text-3xl font-bold text-white">Teste de Fluxo de Pagamento</h1>
        </div>
        <p className="text-gray-400">Valide todo o sistema de pagamentos antes do lançamento</p>
      </div>

      {/* Environment Selector */}
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2 text-white">
            <Monitor className="h-5 w-5" />
            <span>Ambiente de Teste</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex space-x-4">
            <Button
              variant={testEnvironment === "sandbox" ? "default" : "outline"}
              onClick={() => setTestEnvironment("sandbox")}
              className="flex-1"
            >
              Sandbox (Desenvolvimento)
            </Button>
            <Button
              variant={testEnvironment === "production" ? "default" : "outline"}
              onClick={() => setTestEnvironment("production")}
              className="flex-1"
            >
              Produção (Cuidado!)
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="bg-slate-800/50 border-slate-700">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-green-500">{successfulTests}</div>
            <div className="text-sm text-gray-400">Sucessos</div>
          </CardContent>
        </Card>
        <Card className="bg-slate-800/50 border-slate-700">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-red-500">{failedTests}</div>
            <div className="text-sm text-gray-400">Falhas</div>
          </CardContent>
        </Card>
        <Card className="bg-slate-800/50 border-slate-700">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-blue-500">{runningTests}</div>
            <div className="text-sm text-gray-400">Executando</div>
          </CardContent>
        </Card>
        <Card className="bg-slate-800/50 border-slate-700">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-purple-500">{tests.length}</div>
            <div className="text-sm text-gray-400">Total</div>
          </CardContent>
        </Card>
      </div>

      {/* Control Buttons */}
      <div className="flex space-x-4 justify-center">
        <Button onClick={runAllTests} disabled={isRunning} className="bg-purple-600 hover:bg-purple-700">
          {isRunning ? (
            <>
              <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
              Executando Testes...
            </>
          ) : (
            <>
              <Play className="h-4 w-4 mr-2" />
              Executar Todos os Testes
            </>
          )}
        </Button>
        <Button onClick={initializeTests} variant="outline" disabled={isRunning}>
          <RefreshCw className="h-4 w-4 mr-2" />
          Resetar Testes
        </Button>
      </div>

      {/* Test Results */}
      <Tabs defaultValue="results" className="w-full">
        <TabsList className="grid w-full grid-cols-3 bg-slate-800">
          <TabsTrigger value="results" className="text-white">
            Resultados
          </TabsTrigger>
          <TabsTrigger value="details" className="text-white">
            Detalhes
          </TabsTrigger>
          <TabsTrigger value="data" className="text-white">
            Dados de Teste
          </TabsTrigger>
        </TabsList>

        <TabsContent value="results" className="space-y-4">
          <div className="grid gap-4">
            {tests.map((test) => (
              <div key={test.id} className={`p-4 rounded-lg border-2 ${getStatusColor(test.status)}`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    {getStatusIcon(test.status)}
                    <div>
                      <h3 className="font-semibold text-gray-900 dark:text-gray-100">{test.name}</h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400">{test.message}</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    {test.duration && <Badge variant="outline">{test.duration}ms</Badge>}
                    <Button size="sm" variant="outline" onClick={() => runSingleTest(test.id)} disabled={isRunning}>
                      <Play className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="details" className="space-y-4">
          {tests
            .filter((t) => t.details)
            .map((test) => (
              <Card key={test.id} className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2 text-white">
                    {getStatusIcon(test.status)}
                    <span>{test.name}</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <pre className="bg-slate-900 p-4 rounded-lg text-sm text-gray-300 overflow-auto">
                    {JSON.stringify(test.details, null, 2)}
                  </pre>
                </CardContent>
              </Card>
            ))}
        </TabsContent>

        <TabsContent value="data" className="space-y-4">
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">Dados de Teste Gerados</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {testData.subscriptionId && (
                <div>
                  <Label className="text-gray-300">ID da Assinatura</Label>
                  <Input value={testData.subscriptionId} readOnly className="bg-slate-900 text-white" />
                </div>
              )}
              {testData.pixCode && (
                <div>
                  <Label className="text-gray-300">Código PIX</Label>
                  <Input value={testData.pixCode} readOnly className="bg-slate-900 text-white" />
                </div>
              )}
              {testData.boletoUrl && (
                <div>
                  <Label className="text-gray-300">URL do Boleto</Label>
                  <Input value={testData.boletoUrl} readOnly className="bg-slate-900 text-white" />
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Alerts */}
      {failedTests > 0 && (
        <Alert className="border-red-500 bg-red-50 dark:bg-red-950">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription className="text-red-800 dark:text-red-200">
            {failedTests} teste(s) falharam. Verifique os detalhes antes de prosseguir para produção.
          </AlertDescription>
        </Alert>
      )}

      {successfulTests === tests.length && tests.length > 0 && (
        <Alert className="border-green-500 bg-green-50 dark:bg-green-950">
          <CheckCircle className="h-4 w-4" />
          <AlertDescription className="text-green-800 dark:text-green-200">
            Todos os testes passaram com sucesso! O sistema está pronto para produção.
          </AlertDescription>
        </Alert>
      )}
    </div>
  )
}

export default PaymentFlowTester
