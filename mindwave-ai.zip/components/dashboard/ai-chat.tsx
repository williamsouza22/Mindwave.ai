"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Heart, Send, Mic, Smile, Brain } from "lucide-react"
import { useAuth } from "@/lib/auth/auth-context"
import { createClient } from "@/lib/supabase/client"
import { useToast } from "@/hooks/use-toast"

interface Message {
  id: string
  content: string
  sender: "user" | "ai"
  timestamp: Date
  type: "text" | "audio"
}

export function AIChat() {
  const [messages, setMessages] = useState<Message[]>([])
  const [newMessage, setNewMessage] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const { user, profile } = useAuth()
  const { toast } = useToast()
  const supabase = createClient()

  // Load chat history on component mount
  useEffect(() => {
    if (user) {
      loadChatHistory()
    }
  }, [user])

  const loadChatHistory = async () => {
    try {
      const { data, error } = await supabase
        .from("chat_messages")
        .select("*")
        .eq("user_id", user?.id)
        .order("created_at", { ascending: true })
        .limit(20)

      if (error) throw error

      const formattedMessages: Message[] = data.map((msg) => ({
        id: msg.id,
        content: msg.content,
        sender: msg.sender as "user" | "ai",
        timestamp: new Date(msg.created_at),
        type: msg.message_type as "text" | "audio",
      }))

      setMessages(formattedMessages)

      // Add welcome message if no history
      if (formattedMessages.length === 0) {
        const welcomeMessage: Message = {
          id: "welcome",
          content: `Olá, ${profile?.name?.split(" ")[0] || ""}! Como você está se sentindo hoje? Estou aqui para te apoiar em sua jornada de bem-estar. 💙`,
          sender: "ai",
          timestamp: new Date(),
          type: "text",
        }
        setMessages([welcomeMessage])
      }
    } catch (error) {
      console.error("Error loading chat history:", error)
    }
  }

  const saveMessage = async (content: string, sender: "user" | "ai") => {
    if (!user) return

    try {
      const { error } = await supabase.from("chat_messages").insert({
        user_id: user.id,
        content,
        sender,
        message_type: "text",
      })

      if (error) throw error
    } catch (error) {
      console.error("Error saving message:", error)
    }
  }

  const generateAIResponse = async (userMessage: string) => {
    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          message: userMessage,
          userId: user?.id,
          userName: profile?.name,
        }),
      })

      if (!response.ok) throw new Error("Failed to get AI response")

      const data = await response.json()
      return data.response
    } catch (error) {
      console.error("Error generating AI response:", error)
      return "Desculpe, estou com dificuldades técnicas no momento. Tente novamente em alguns instantes. 🤖"
    }
  }

  const handleSendMessage = async () => {
    if (!newMessage.trim() || isLoading) return

    const userMessage: Message = {
      id: Date.now().toString(),
      content: newMessage,
      sender: "user",
      timestamp: new Date(),
      type: "text",
    }

    setMessages((prev) => [...prev, userMessage])
    setNewMessage("")
    setIsLoading(true)

    // Save user message
    await saveMessage(userMessage.content, "user")

    try {
      // Generate AI response
      const aiResponseContent = await generateAIResponse(userMessage.content)

      const aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        content: aiResponseContent,
        sender: "ai",
        timestamp: new Date(),
        type: "text",
      }

      setMessages((prev) => [...prev, aiResponse])

      // Save AI response
      await saveMessage(aiResponse.content, "ai")
    } catch (error) {
      toast({
        title: "Erro na conversa",
        description: "Não foi possível processar sua mensagem. Tente novamente.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const getInitials = (name: string | null) => {
    if (!name) return "U"
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2)
  }

  return (
    <Card className="bg-[#1A2332] border-gray-800 h-[500px] flex flex-col">
      <CardHeader className="flex-shrink-0">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center space-x-2">
            <Brain className="h-5 w-5 text-blue-400" />
            <span className="text-white">IA Empática</span>
          </CardTitle>
          <Badge variant="secondary" className="bg-green-900/50 text-green-300 border-green-800">
            <div className="h-2 w-2 rounded-full bg-green-500 mr-1"></div>
            Online 24/7
          </Badge>
        </div>
      </CardHeader>

      <CardContent className="flex-1 flex flex-col p-0">
        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex items-start space-x-3 ${
                message.sender === "user" ? "flex-row-reverse space-x-reverse" : ""
              }`}
            >
              <Avatar className="h-8 w-8">
                {message.sender === "ai" ? (
                  <div className="h-8 w-8 rounded-full bg-gradient-to-r from-blue-500 to-purple-500 flex items-center justify-center">
                    <Heart className="h-4 w-4 text-white" />
                  </div>
                ) : (
                  <>
                    <AvatarImage src={profile?.avatar_url || "/placeholder.svg?height=32&width=32"} />
                    <AvatarFallback className="bg-gradient-to-r from-gray-600 to-gray-700 text-white text-xs">
                      {getInitials(profile?.name)}
                    </AvatarFallback>
                  </>
                )}
              </Avatar>

              <div className={`max-w-[70%] ${message.sender === "user" ? "text-right" : ""}`}>
                <div
                  className={`rounded-2xl px-4 py-3 ${
                    message.sender === "user"
                      ? "bg-gradient-to-r from-blue-600 to-purple-600 text-white"
                      : "bg-gray-800 text-gray-100"
                  }`}
                >
                  <p className="text-sm leading-relaxed">{message.content}</p>
                </div>
                <p className="text-xs text-gray-500 mt-1">{message.timestamp.toLocaleTimeString()}</p>
              </div>
            </div>
          ))}

          {/* Loading indicator */}
          {isLoading && (
            <div className="flex items-start space-x-3">
              <div className="h-8 w-8 rounded-full bg-gradient-to-r from-blue-500 to-purple-500 flex items-center justify-center">
                <Heart className="h-4 w-4 text-white" />
              </div>
              <div className="bg-gray-800 rounded-2xl px-4 py-3">
                <div className="flex space-x-1">
                  {[0, 1, 2].map((i) => (
                    <div
                      key={i}
                      className="w-2 h-2 bg-gray-400 rounded-full animate-pulse"
                      style={{ animationDelay: `${i * 0.2}s` }}
                    />
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Input */}
        <div className="border-t border-gray-700 p-4">
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              size="sm"
              className="bg-transparent border-gray-700 text-gray-300 hover:bg-gray-800"
            >
              <Smile className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="bg-transparent border-gray-700 text-gray-300 hover:bg-gray-800"
            >
              <Mic className="h-4 w-4" />
            </Button>
            <Input
              placeholder="Digite sua mensagem..."
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
              className="flex-1 bg-gray-800 border-gray-700 text-white placeholder-gray-400 focus:border-blue-500"
              disabled={isLoading}
            />
            <Button
              onClick={handleSendMessage}
              size="sm"
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
              disabled={isLoading || !newMessage.trim()}
            >
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
