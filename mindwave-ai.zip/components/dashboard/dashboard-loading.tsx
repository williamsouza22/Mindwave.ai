"use client"

import { motion } from "framer-motion"
import { Heart } from "lucide-react"

export function DashboardLoading() {
  return (
    <div className="min-h-screen bg-[#0B1426] flex items-center justify-center">
      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.6 }}
        className="text-center space-y-6"
      >
        {/* Logo animado */}
        <motion.div
          animate={{
            scale: [1, 1.1, 1],
            opacity: [0.8, 1, 0.8],
          }}
          transition={{
            duration: 2,
            repeat: Number.POSITIVE_INFINITY,
            ease: "easeInOut",
          }}
          className="flex items-center justify-center space-x-3"
        >
          <div className="h-12 w-12 rounded-xl bg-gradient-to-r from-blue-600 to-purple-600 flex items-center justify-center">
            <Heart className="h-7 w-7 text-white" />
          </div>
          <span className="font-bold text-2xl text-white">MindWave.AI</span>
        </motion.div>

        {/* Loading text */}
        <div className="space-y-2">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-xl font-semibold text-white"
          >
            Preparando seu espaço de bem-estar...
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="text-gray-400"
          >
            Carregando suas informações pessoais
          </motion.p>
        </div>

        {/* Loading animation */}
        <div className="flex items-center justify-center space-x-2">
          {[0, 1, 2].map((i) => (
            <motion.div
              key={i}
              animate={{
                scale: [1, 1.2, 1],
                opacity: [0.5, 1, 0.5],
              }}
              transition={{
                duration: 1,
                repeat: Number.POSITIVE_INFINITY,
                delay: i * 0.2,
                ease: "easeInOut",
              }}
              className="w-3 h-3 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full"
            />
          ))}
        </div>

        {/* Progress indicators */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="space-y-2"
        >
          <div className="flex items-center justify-center space-x-4 text-xs text-gray-500">
            <span>✓ Autenticação</span>
            <span>✓ Perfil</span>
            <span className="text-blue-400">⟳ Dashboard</span>
          </div>
        </motion.div>
      </motion.div>
    </div>
  )
}
