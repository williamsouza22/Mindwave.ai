"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { BookOpen, Sparkles, Save } from "lucide-react"

export function JournalEntry() {
  const [entry, setEntry] = useState("")
  const [aiSuggestion, setAiSuggestion] = useState("")
  const [isGenerating, setIsGenerating] = useState(false)

  const generateAISuggestion = async () => {
    setIsGenerating(true)
    // Simulate AI processing
    setTimeout(() => {
      setAiSuggestion(
        "Baseado no que você escreveu, percebo que você está passando por um momento de reflexão. Que tal explorar mais sobre o que te fez sentir assim hoje?",
      )
      setIsGenerating(false)
    }, 2000)
  }

  const saveEntry = () => {
    // Save logic here
    console.log("Saving entry:", entry)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <BookOpen className="h-5 w-5 text-green-500" />
          <span>Diário Inteligente</span>
        </CardTitle>
      </CardHeader>

      <CardContent className="space-y-4">
        <div>
          <label className="text-sm font-medium text-gray-700 mb-2 block">Como foi seu dia hoje?</label>
          <Textarea
            placeholder="Escreva sobre seus sentimentos, pensamentos ou experiências do dia..."
            value={entry}
            onChange={(e) => setEntry(e.target.value)}
            className="min-h-[120px] resize-none"
          />
        </div>

        <div className="flex space-x-2">
          <Button
            onClick={generateAISuggestion}
            disabled={!entry.trim() || isGenerating}
            variant="outline"
            size="sm"
            className="flex-1 bg-transparent"
          >
            <Sparkles className="h-4 w-4 mr-2" />
            {isGenerating ? "Analisando..." : "Sugestão IA"}
          </Button>
          <Button
            onClick={saveEntry}
            disabled={!entry.trim()}
            size="sm"
            className="bg-gradient-to-r from-green-500 to-blue-500"
          >
            <Save className="h-4 w-4 mr-2" />
            Salvar
          </Button>
        </div>

        {aiSuggestion && (
          <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg p-4">
            <div className="flex items-center space-x-2 mb-2">
              <Sparkles className="h-4 w-4 text-purple-500" />
              <Badge variant="secondary" className="bg-purple-100 text-purple-700">
                Sugestão IA
              </Badge>
            </div>
            <p className="text-sm text-gray-700">{aiSuggestion}</p>
          </div>
        )}

        {/* Recent entries */}
        <div className="space-y-2">
          <h4 className="font-semibold text-sm text-gray-700">Entradas recentes:</h4>
          <div className="space-y-2">
            <div className="p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs text-gray-500">Ontem</span>
                <Badge variant="outline" className="text-xs">
                  Reflexivo
                </Badge>
              </div>
              <p className="text-sm text-gray-700">Hoje foi um dia de muitas descobertas sobre mim mesmo...</p>
            </div>
            <div className="p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs text-gray-500">2 dias atrás</span>
                <Badge variant="outline" className="text-xs">
                  Gratidão
                </Badge>
              </div>
              <p className="text-sm text-gray-700">Sinto-me grato pelas pequenas coisas da vida...</p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
