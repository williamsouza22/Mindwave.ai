"use client"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Crown, User, LogOut } from "lucide-react"
import Link from "next/link"
import { useAuth } from "@/lib/auth/auth-context"
import { useRouter } from "next/navigation"
import { useToast } from "@/hooks/use-toast"
import { NotificationSystem } from "@/components/notifications/notification-system"
import { SyncManager } from "@/components/sync/sync-manager"

export function ModernDashboardHeader() {
  const { user, profile, signOut } = useAuth()
  const router = useRouter()
  const { toast } = useToast()

  const handleSignOut = async () => {
    const { error } = await signOut()

    if (error) {
      toast({
        title: "Erro ao sair",
        description: "Não foi possível fazer logout. Tente novamente.",
        variant: "destructive",
      })
    } else {
      toast({
        title: "Até logo! 👋",
        description: "Logout realizado com sucesso.",
      })
      router.push("/")
    }
  }

  const getInitials = (name: string | null) => {
    if (!name) return "U"
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2)
  }

  const isPremium = profile?.plan === "premium"

  return (
    <div className="flex items-center space-x-4">
      <SyncManager />

      {!isPremium && (
        <Button
          variant="outline"
          size="sm"
          className="hidden sm:flex bg-transparent border-yellow-600 text-yellow-400 hover:bg-yellow-900/20"
          asChild
        >
          <Link href="/pricing">
            <Crown className="h-4 w-4 mr-2" />
            Upgrade Premium
          </Link>
        </Button>
      )}

      {isPremium && (
        <Badge variant="secondary" className="bg-yellow-900/50 text-yellow-300 border-yellow-800">
          <Crown className="h-3 w-3 mr-1" />
          Premium
        </Badge>
      )}

      <NotificationSystem />

      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" className="relative h-10 w-10 rounded-full">
            <Avatar className="h-10 w-10">
              <AvatarImage src={profile?.avatar_url || "/placeholder.svg?height=40&width=40"} alt="User" />
              <AvatarFallback className="bg-gradient-to-r from-blue-500 to-purple-500 text-white">
                {getInitials(profile?.name)}
              </AvatarFallback>
            </Avatar>
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent className="w-56 bg-[#1A2332] border-gray-700" align="end" forceMount>
          <DropdownMenuLabel className="font-normal">
            <div className="flex flex-col space-y-1">
              <p className="text-sm font-medium leading-none text-white">{profile?.name || "Usuário"}</p>
              <p className="text-xs leading-none text-gray-400">{user?.email}</p>
              <Badge
                variant="outline"
                className={`w-fit text-xs mt-1 ${
                  isPremium
                    ? "bg-yellow-900/30 border-yellow-700 text-yellow-300"
                    : "bg-gray-800 border-gray-600 text-gray-400"
                }`}
              >
                {isPremium ? "Premium" : "Gratuito"}
              </Badge>
            </div>
          </DropdownMenuLabel>
          <DropdownMenuSeparator className="bg-gray-700" />
          <DropdownMenuItem className="text-gray-300 hover:bg-gray-800" asChild>
            <Link href="/profile">
              <User className="mr-2 h-4 w-4" />
              <span>Perfil</span>
            </Link>
          </DropdownMenuItem>
          {!isPremium && (
            <DropdownMenuItem className="text-gray-300 hover:bg-gray-800" asChild>
              <Link href="/pricing">
                <Crown className="mr-2 h-4 w-4" />
                <span>Upgrade Premium</span>
              </Link>
            </DropdownMenuItem>
          )}
          <DropdownMenuSeparator className="bg-gray-700" />
          <DropdownMenuItem className="text-red-400 hover:bg-red-900/20 cursor-pointer" onClick={handleSignOut}>
            <LogOut className="mr-2 h-4 w-4" />
            <span>Sair</span>
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  )
}
