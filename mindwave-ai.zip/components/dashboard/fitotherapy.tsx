"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Leaf, Clock, AlertTriangle, CheckCircle } from "lucide-react"

const herbs = [
  {
    name: "Camomila",
    benefits: "Ansiedade, insônia",
    preparation: "Chá: 1 colher/xícara",
    safety: "Seguro para uso diário",
    contraindications: "Alergia a margaridas",
    color: "from-yellow-500 to-orange-500",
    emoji: "🌼",
  },
  {
    name: "Valeriana",
    benefits: "Insônia, nervosismo",
    preparation: "Chá: 1-2g antes de dormir",
    safety: "Uso moderado",
    contraindications: "Gravidez, medicamentos",
    color: "from-purple-500 to-pink-500",
    emoji: "🌿",
  },
  {
    name: "Melissa",
    benefits: "Estresse, digestão",
    preparation: "Chá: 2-3 folhas/xícara",
    safety: "Muito seguro",
    contraindications: "Hipotireoidismo",
    color: "from-green-500 to-emerald-500",
    emoji: "🍃",
  },
  {
    name: "Lavanda",
    benefits: "Relaxamento, sono",
    preparation: "Chá: 1 colher/xícara",
    safety: "Seguro para aromaterapia",
    contraindications: "Uso interno limitado",
    color: "from-indigo-500 to-purple-500",
    emoji: "💜",
  },
]

export function Fitotherapy() {
  return (
    <Card className="bg-[#1A2332] border-gray-800">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Leaf className="h-5 w-5 text-green-400" />
          <span className="text-white">Fitoterapia Assistida</span>
          <Badge variant="secondary" className="bg-green-900/50 text-green-300 border-green-800 ml-auto">
            Natural
          </Badge>
        </CardTitle>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Today's Recommendation */}
        <div className="p-4 bg-gradient-to-r from-green-900/20 to-blue-900/20 rounded-lg border border-green-800">
          <div className="flex items-center space-x-3 mb-3">
            <span className="text-2xl">🌼</span>
            <div>
              <h3 className="font-semibold text-white">Recomendação do Dia</h3>
              <p className="text-sm text-gray-300">Baseado no seu estado emocional</p>
            </div>
          </div>
          <p className="text-sm text-gray-300 mb-3">
            Para sua ansiedade de hoje, recomendamos um chá de <strong>camomila</strong> 30 minutos antes de dormir.
          </p>
          <Button
            size="sm"
            className="bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700"
          >
            <Clock className="h-4 w-4 mr-2" />
            Definir Lembrete
          </Button>
        </div>

        {/* Herb Library */}
        <div className="space-y-3">
          <h4 className="font-semibold text-white text-sm">Biblioteca de Ervas:</h4>
          {herbs.map((herb, index) => (
            <div
              key={herb.name}
              className="p-3 bg-[#0F1B2A] rounded-lg border border-gray-700 hover:border-gray-600 transition-colors"
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center space-x-2">
                  <span className="text-lg">{herb.emoji}</span>
                  <span className="font-medium text-white text-sm">{herb.name}</span>
                </div>
                <Badge variant="outline" className="text-xs bg-green-900/30 border-green-700 text-green-300">
                  {herb.safety}
                </Badge>
              </div>

              <p className="text-xs text-gray-400 mb-2">{herb.benefits}</p>

              <div className="space-y-1">
                <div className="flex items-center space-x-2">
                  <CheckCircle className="h-3 w-3 text-green-400" />
                  <span className="text-xs text-gray-300">{herb.preparation}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <AlertTriangle className="h-3 w-3 text-yellow-400" />
                  <span className="text-xs text-gray-400">{herb.contraindications}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Weekly Plan */}
        <div className="space-y-3">
          <h4 className="font-semibold text-white text-sm">Plano Semanal Premium:</h4>
          <div className="space-y-2">
            {["Segunda", "Terça", "Quarta"].map((day, index) => {
              const dayHerbs = ["Camomila", "Melissa", "Lavanda"][index]
              return (
                <div key={day} className="flex items-center justify-between p-2 bg-gray-800/50 rounded">
                  <div className="flex items-center space-x-2">
                    <span className="text-xs text-gray-400 w-16">{day}</span>
                    <span className="text-sm text-gray-300">{dayHerbs}</span>
                  </div>
                  <Badge variant="outline" className="text-xs">
                    {index === 0 ? "Hoje" : "Agendado"}
                  </Badge>
                </div>
              )
            })}
          </div>

          <Button
            variant="outline"
            size="sm"
            className="w-full bg-transparent border-gray-700 text-gray-300 hover:bg-gray-800"
          >
            <Leaf className="h-4 w-4 mr-2" />
            Upgrade para Plano Completo
          </Button>
        </div>

        {/* Safety Notice */}
        <div className="p-3 bg-yellow-900/20 rounded-lg border border-yellow-800">
          <div className="flex items-start space-x-2">
            <AlertTriangle className="h-4 w-4 text-yellow-400 mt-0.5" />
            <div>
              <p className="text-xs text-yellow-300 font-medium mb-1">Aviso Importante</p>
              <p className="text-xs text-yellow-200">
                Consulte um profissional antes de usar ervas medicinais, especialmente se estiver tomando medicamentos.
              </p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
