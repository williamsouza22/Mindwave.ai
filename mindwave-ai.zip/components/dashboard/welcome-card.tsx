"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Heart, Sparkles, Calendar, TrendingUp, Crown } from "lucide-react"
import { motion } from "framer-motion"
import { useAuth } from "@/lib/auth/auth-context"
import Link from "next/link"

export function WelcomeCard() {
  const { profile } = useAuth()

  const getGreeting = () => {
    const hour = new Date().getHours()
    if (hour < 12) return "Bom dia"
    if (hour < 18) return "Boa tarde"
    return "Boa noite"
  }

  const getMotivationalMessage = () => {
    const messages = [
      "Cada pequeno passo conta na sua jornada de bem-estar! 🌱",
      "Você está no caminho certo para uma mente mais saudável! ✨",
      "Lembre-se: cuidar de si mesmo não é egoísmo, é necessário! 💙",
      "Sua saúde mental é prioridade. Estamos aqui para apoiar você! 🤗",
      "Hoje é uma nova oportunidade para cuidar da sua mente! 🌟",
    ]
    return messages[Math.floor(Math.random() * messages.length)]
  }

  const isPremium = profile?.plan === "premium"
  const firstName = profile?.name?.split(" ")[0] || "Usuário"

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
      <Card className="bg-gradient-to-r from-[#1A2332] via-[#1E2A3A] to-[#1A2332] border-gray-700 overflow-hidden">
        <CardContent className="p-8">
          <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between space-y-6 lg:space-y-0">
            {/* Welcome Content */}
            <div className="flex-1">
              <div className="flex items-center space-x-3 mb-4">
                <div className="h-12 w-12 rounded-full bg-gradient-to-r from-blue-500 to-purple-500 flex items-center justify-center">
                  <Heart className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-white">
                    {getGreeting()}, {firstName}! 👋
                  </h1>
                  <div className="flex items-center space-x-2 mt-1">
                    <Badge variant="secondary" className="bg-green-900/50 text-green-300 border-green-800">
                      <div className="h-2 w-2 rounded-full bg-green-500 mr-1"></div>
                      Online
                    </Badge>
                    {isPremium && (
                      <Badge variant="secondary" className="bg-yellow-900/50 text-yellow-300 border-yellow-800">
                        <Crown className="h-3 w-3 mr-1" />
                        Premium
                      </Badge>
                    )}
                  </div>
                </div>
              </div>

              <p className="text-gray-300 text-lg mb-4 leading-relaxed">{getMotivationalMessage()}</p>

              <div className="flex flex-wrap items-center gap-4">
                <div className="flex items-center space-x-2 text-sm text-gray-400">
                  <Calendar className="h-4 w-4" />
                  <span>Último check-in: Hoje às 14:30</span>
                </div>
                <div className="flex items-center space-x-2 text-sm text-gray-400">
                  <TrendingUp className="h-4 w-4" />
                  <span>Sequência: 7 dias</span>
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="flex flex-col space-y-3 lg:ml-8">
              <Button
                className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                size="lg"
              >
                <Heart className="h-4 w-4 mr-2" />
                Check-in Rápido
              </Button>

              {!isPremium && (
                <Button
                  variant="outline"
                  className="border-yellow-600 text-yellow-400 hover:bg-yellow-900/20 bg-transparent"
                  asChild
                >
                  <Link href="/pricing">
                    <Sparkles className="h-4 w-4 mr-2" />
                    Upgrade Premium
                  </Link>
                </Button>
              )}
            </div>
          </div>

          {/* Progress Bar */}
          <div className="mt-6 pt-6 border-t border-gray-700">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-gray-300">Progresso do bem-estar hoje</span>
              <span className="text-sm text-gray-400">75%</span>
            </div>
            <div className="w-full bg-gray-700 rounded-full h-2">
              <motion.div
                className="h-2 rounded-full bg-gradient-to-r from-blue-500 to-purple-500"
                initial={{ width: 0 }}
                animate={{ width: "75%" }}
                transition={{ duration: 1, delay: 0.5 }}
              />
            </div>
            <div className="flex justify-between text-xs text-gray-500 mt-1">
              <span>Check-in ✓</span>
              <span>Meditação ✓</span>
              <span>Diário ✓</span>
              <span>Exercício</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  )
}
