"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Timer, Play, Pause, RotateCcw, Flame, Waves } from "lucide-react"
import { motion } from "framer-motion"

const cozyTechniques = [
  {
    id: "floor-time",
    name: "Floor Time",
    description: "Deite no chão e sinta a conexão com a terra",
    duration: 10,
    icon: "🧘‍♀️",
    color: "from-green-500 to-emerald-500",
  },
  {
    id: "candle-watch",
    name: "Candle Watch",
    description: "Observe a chama da vela e acalme sua mente",
    duration: 15,
    icon: "🕯️",
    color: "from-orange-500 to-yellow-500",
  },
  {
    id: "body-scan",
    name: "Body Scan",
    description: "Escaneie seu corpo da cabeça aos pés",
    duration: 20,
    icon: "✨",
    color: "from-purple-500 to-pink-500",
  },
  {
    id: "cozy-breathing",
    name: "Cozy Breathing",
    description: "Respiração aconchegante e reconfortante",
    duration: 5,
    icon: "🌸",
    color: "from-blue-500 to-cyan-500",
  },
]

export function CozyMindfulness() {
  const [selectedTechnique, setSelectedTechnique] = useState(cozyTechniques[0])
  const [isActive, setIsActive] = useState(false)
  const [timeLeft, setTimeLeft] = useState(selectedTechnique.duration * 60)

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  return (
    <Card className="bg-[#1A2332] border-gray-800">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Timer className="h-5 w-5 text-purple-400" />
          <span className="text-white">Cozy Mindfulness</span>
          <Badge variant="secondary" className="bg-purple-900/50 text-purple-300 border-purple-800 ml-auto">
            Trending
          </Badge>
        </CardTitle>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Technique Selector */}
        <div className="grid grid-cols-2 gap-3">
          {cozyTechniques.map((technique) => (
            <Button
              key={technique.id}
              variant={selectedTechnique.id === technique.id ? "default" : "outline"}
              size="sm"
              onClick={() => {
                setSelectedTechnique(technique)
                setTimeLeft(technique.duration * 60)
                setIsActive(false)
              }}
              className={`h-auto p-3 flex flex-col items-center space-y-1 ${
                selectedTechnique.id === technique.id
                  ? `bg-gradient-to-r ${technique.color}`
                  : "bg-transparent border-gray-700 text-gray-300 hover:bg-gray-800"
              }`}
            >
              <span className="text-lg">{technique.icon}</span>
              <span className="text-xs font-medium">{technique.name}</span>
            </Button>
          ))}
        </div>

        {/* Current Session */}
        <div className="text-center space-y-4">
          <div
            className={`inline-flex h-24 w-24 items-center justify-center rounded-full bg-gradient-to-r ${selectedTechnique.color} shadow-lg`}
          >
            <span className="text-3xl">{selectedTechnique.icon}</span>
          </div>

          <div>
            <h3 className="text-xl font-semibold text-white mb-1">{selectedTechnique.name}</h3>
            <p className="text-sm text-gray-400">{selectedTechnique.description}</p>
          </div>

          {/* Timer Display */}
          <motion.div
            animate={{ scale: isActive ? [1, 1.05, 1] : 1 }}
            transition={{ duration: 2, repeat: isActive ? Number.POSITIVE_INFINITY : 0 }}
            className="text-4xl font-bold text-white"
          >
            {formatTime(timeLeft)}
          </motion.div>

          {/* Controls */}
          <div className="flex items-center justify-center space-x-4">
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setTimeLeft(selectedTechnique.duration * 60)
                setIsActive(false)
              }}
              className="bg-transparent border-gray-700 text-gray-300 hover:bg-gray-800"
            >
              <RotateCcw className="h-4 w-4" />
            </Button>

            <Button
              onClick={() => setIsActive(!isActive)}
              className={`bg-gradient-to-r ${selectedTechnique.color} hover:opacity-90`}
            >
              {isActive ? <Pause className="h-4 w-4 mr-2" /> : <Play className="h-4 w-4 mr-2" />}
              {isActive ? "Pausar" : "Iniciar"}
            </Button>
          </div>
        </div>

        {/* Ambient Sounds */}
        <div className="space-y-3">
          <h4 className="font-semibold text-white text-sm">Sons Ambiente:</h4>
          <div className="grid grid-cols-2 gap-2">
            <Button
              variant="outline"
              size="sm"
              className="bg-transparent border-gray-700 text-gray-300 hover:bg-gray-800 justify-start"
            >
              <Waves className="h-4 w-4 mr-2" />
              Chuva
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="bg-transparent border-gray-700 text-gray-300 hover:bg-gray-800 justify-start"
            >
              <Flame className="h-4 w-4 mr-2" />
              Lareira
            </Button>
          </div>
        </div>

        {/* Progress */}
        <div className="space-y-2">
          <div className="flex justify-between text-xs text-gray-400">
            <span>Progresso da sessão</span>
            <span>
              {Math.round(((selectedTechnique.duration * 60 - timeLeft) / (selectedTechnique.duration * 60)) * 100)}%
            </span>
          </div>
          <div className="w-full bg-gray-700 rounded-full h-2">
            <div
              className={`h-2 rounded-full bg-gradient-to-r ${selectedTechnique.color} transition-all duration-300`}
              style={{
                width: `${((selectedTechnique.duration * 60 - timeLeft) / (selectedTechnique.duration * 60)) * 100}%`,
              }}
            ></div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
