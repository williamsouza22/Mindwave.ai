"use client"
import { usePathname } from "next/navigation"
import { motion } from "framer-motion"
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSub,
  SidebarMenuSubButton,
  SidebarMenuSubItem,
  SidebarRail,
} from "@/components/ui/sidebar"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { useAuth } from "@/lib/auth/auth-context"
import { NotificationSystem } from "@/components/notifications/notification-system"
import {
  LayoutDashboard,
  MessageCircle,
  Brain,
  Heart,
  BookOpen,
  Calendar,
  Smartphone,
  Leaf,
  Activity,
  Headphones,
  BarChart3,
  Target,
  TrendingUp,
  User,
  Settings,
  Shield,
  LogOut,
  Crown,
  Sparkles,
  Map,
  AlertTriangle,
  FileText,
  Waves,
  Wind,
  Music,
  ChevronRight,
} from "lucide-react"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"

// Menu data structure
const menuData = {
  main: [
    {
      title: "Dashboard",
      url: "/dashboard",
      icon: LayoutDashboard,
    },
    {
      title: "Chat IA",
      url: "/chat",
      icon: MessageCircle,
      badge: "Novo",
    },
    {
      title: "Análise Mental",
      icon: Brain,
      items: [
        {
          title: "Mapa Emocional",
          url: "/emotional-map",
          icon: Map,
        },
        {
          title: "Detecção de Crise",
          url: "/crisis-detection",
          icon: AlertTriangle,
        },
        {
          title: "Relatórios",
          url: "/reports",
          icon: FileText,
        },
      ],
    },
    {
      title: "Mindfulness",
      icon: Heart,
      items: [
        {
          title: "Meditação Guiada",
          url: "/meditation",
          icon: Waves,
        },
        {
          title: "Exercícios de Respiração",
          url: "/breathing",
          icon: Wind,
        },
        {
          title: "Sons da Natureza",
          url: "/nature-sounds",
          icon: Music,
        },
      ],
    },
    {
      title: "Diário Digital",
      url: "/journal",
      icon: BookOpen,
    },
    {
      title: "Agenda",
      url: "/calendar",
      icon: Calendar,
    },
  ],
  wellness: [
    {
      title: "Detox Digital",
      url: "/digital-detox",
      icon: Smartphone,
    },
    {
      title: "Fitoterapia",
      url: "/fitotherapy",
      icon: Leaf,
    },
    {
      title: "Exercícios",
      url: "/exercises",
      icon: Activity,
    },
    {
      title: "Áudio Terapia",
      url: "/audio-therapy",
      icon: Headphones,
    },
  ],
  insights: [
    {
      title: "Estatísticas",
      url: "/statistics",
      icon: BarChart3,
    },
    {
      title: "Objetivos",
      url: "/goals",
      icon: Target,
    },
    {
      title: "Progresso",
      url: "/progress",
      icon: TrendingUp,
    },
  ],
  settings: [
    {
      title: "Perfil",
      url: "/profile",
      icon: User,
    },
    {
      title: "Configurações",
      url: "/settings",
      icon: Settings,
    },
    {
      title: "Privacidade",
      url: "/privacy",
      icon: Shield,
    },
  ],
}

export function UserSidebar() {
  const pathname = usePathname()
  const { user, profile, logout } = useAuth()

  const isActive = (url: string) => pathname === url

  return (
    <Sidebar variant="inset" className="border-r border-gray-800">
      <SidebarHeader className="border-b border-gray-800 bg-[#1A2332]">
        <div className="flex items-center space-x-3 p-4">
          <motion.div
            animate={{
              scale: [1, 1.1, 1],
              opacity: [0.8, 1, 0.8],
            }}
            transition={{
              duration: 2,
              repeat: Number.POSITIVE_INFINITY,
              ease: "easeInOut",
            }}
            className="w-8 h-8 rounded-full bg-gradient-to-r from-blue-500 to-purple-500 flex items-center justify-center"
          >
            <Sparkles className="h-4 w-4 text-white" />
          </motion.div>
          <div>
            <h2 className="text-lg font-bold text-white">MindWave.AI</h2>
            <p className="text-xs text-gray-400">Seu agente de bem-estar</p>
          </div>
        </div>
      </SidebarHeader>

      <SidebarContent className="bg-[#1A2332]">
        {/* Main Menu */}
        <SidebarGroup>
          <SidebarGroupLabel className="text-gray-400 text-xs uppercase tracking-wider">
            Menu Principal
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuData.main.map((item) => (
                <SidebarMenuItem key={item.title}>
                  {item.items ? (
                    <Collapsible defaultOpen={false} className="group/collapsible">
                      <CollapsibleTrigger asChild>
                        <SidebarMenuButton className="text-gray-300 hover:text-white hover:bg-gray-800">
                          <item.icon className="h-4 w-4" />
                          <span>{item.title}</span>
                          <ChevronRight className="ml-auto h-4 w-4 transition-transform group-data-[state=open]/collapsible:rotate-90" />
                        </SidebarMenuButton>
                      </CollapsibleTrigger>
                      <CollapsibleContent>
                        <SidebarMenuSub>
                          {item.items.map((subItem) => (
                            <SidebarMenuSubItem key={subItem.title}>
                              <SidebarMenuSubButton
                                asChild
                                isActive={isActive(subItem.url)}
                                className="text-gray-400 hover:text-white hover:bg-gray-800"
                              >
                                <a href={subItem.url}>
                                  <subItem.icon className="h-3 w-3" />
                                  <span>{subItem.title}</span>
                                </a>
                              </SidebarMenuSubButton>
                            </SidebarMenuSubItem>
                          ))}
                        </SidebarMenuSub>
                      </CollapsibleContent>
                    </Collapsible>
                  ) : (
                    <SidebarMenuButton
                      asChild
                      isActive={isActive(item.url!)}
                      className="text-gray-300 hover:text-white hover:bg-gray-800"
                    >
                      <a href={item.url!}>
                        <item.icon className="h-4 w-4" />
                        <span>{item.title}</span>
                        {item.badge && (
                          <Badge variant="secondary" className="ml-auto bg-blue-600 text-white text-xs">
                            {item.badge}
                          </Badge>
                        )}
                      </a>
                    </SidebarMenuButton>
                  )}
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {/* Wellness Section */}
        <SidebarGroup>
          <SidebarGroupLabel className="text-gray-400 text-xs uppercase tracking-wider">Bem-estar</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuData.wellness.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton
                    asChild
                    isActive={isActive(item.url)}
                    className="text-gray-300 hover:text-white hover:bg-gray-800"
                  >
                    <a href={item.url}>
                      <item.icon className="h-4 w-4" />
                      <span>{item.title}</span>
                    </a>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {/* Insights Section */}
        <SidebarGroup>
          <SidebarGroupLabel className="text-gray-400 text-xs uppercase tracking-wider">Insights</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuData.insights.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton
                    asChild
                    isActive={isActive(item.url)}
                    className="text-gray-300 hover:text-white hover:bg-gray-800"
                  >
                    <a href={item.url}>
                      <item.icon className="h-4 w-4" />
                      <span>{item.title}</span>
                    </a>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {/* Settings Section */}
        <SidebarGroup>
          <SidebarGroupLabel className="text-gray-400 text-xs uppercase tracking-wider">
            Configurações
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuData.settings.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton
                    asChild
                    isActive={isActive(item.url)}
                    className="text-gray-300 hover:text-white hover:bg-gray-800"
                  >
                    <a href={item.url}>
                      <item.icon className="h-4 w-4" />
                      <span>{item.title}</span>
                    </a>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="border-t border-gray-800 bg-[#1A2332]">
        <div className="p-4 space-y-4">
          {/* User Profile */}
          <div className="flex items-center space-x-3">
            <Avatar className="h-10 w-10">
              <AvatarImage src={profile?.avatar_url || "/placeholder.svg"} alt={profile?.name} />
              <AvatarFallback className="bg-gradient-to-r from-blue-500 to-purple-500 text-white">
                {profile?.name
                  ?.split(" ")
                  .map((n) => n[0])
                  .join("")
                  .toUpperCase() || "U"}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-white truncate">{profile?.name || "Usuário"}</p>
              <div className="flex items-center space-x-2">
                {profile?.plan === "premium" ? (
                  <Badge className="bg-gradient-to-r from-yellow-500 to-orange-500 text-xs">
                    <Crown className="h-3 w-3 mr-1" />
                    Premium
                  </Badge>
                ) : (
                  <Badge variant="secondary" className="bg-gray-700 text-gray-300 text-xs">
                    Gratuito
                  </Badge>
                )}
              </div>
            </div>
            <div className="flex items-center space-x-1">
              <NotificationSystem />
              <Button
                variant="ghost"
                size="sm"
                onClick={logout}
                className="text-gray-400 hover:text-red-400 hover:bg-gray-800"
              >
                <LogOut className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-3 gap-2 text-center">
            <div className="p-2 bg-blue-900/20 rounded border border-blue-800">
              <div className="text-sm font-bold text-blue-400">7</div>
              <div className="text-xs text-blue-300">Dias</div>
            </div>
            <div className="p-2 bg-green-900/20 rounded border border-green-800">
              <div className="text-sm font-bold text-green-400">8.2</div>
              <div className="text-xs text-green-300">Humor</div>
            </div>
            <div className="p-2 bg-purple-900/20 rounded border border-purple-800">
              <div className="text-sm font-bold text-purple-400">23</div>
              <div className="text-xs text-purple-300">Sessões</div>
            </div>
          </div>
        </div>
      </SidebarFooter>

      <SidebarRail />
    </Sidebar>
  )
}
