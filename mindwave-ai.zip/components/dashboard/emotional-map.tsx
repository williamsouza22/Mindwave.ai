"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Calendar, TrendingUp } from "lucide-react"

const moodData = [
  { date: "2024-01-01", mood: 7, emoji: "😊", note: "Dia produtivo", color: "bg-green-500" },
  { date: "2024-01-02", mood: 4, emoji: "😕", note: "Ansioso", color: "bg-orange-500" },
  { date: "2024-01-03", mood: 8, emoji: "😄", note: "Excelente!", color: "bg-green-600" },
  { date: "2024-01-04", mood: 6, emoji: "😐", note: "Normal", color: "bg-yellow-500" },
  { date: "2024-01-05", mood: 9, emoji: "🥰", note: "Muito feliz", color: "bg-green-700" },
  { date: "2024-01-06", mood: 3, emoji: "😢", note: "Ecoansiedade", color: "bg-red-500" },
  { date: "2024-01-07", mood: 7, emoji: "😊", note: "Melhorando", color: "bg-green-500" },
]

export function EmotionalMap() {
  const averageMood = moodData.reduce((sum, day) => sum + day.mood, 0) / moodData.length

  return (
    <Card className="bg-[#1A2332] border-gray-800">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Calendar className="h-5 w-5 text-green-400" />
            <span className="text-white">Mapa Emocional</span>
          </div>
          <Badge
            variant="secondary"
            className="flex items-center space-x-1 bg-green-900/50 text-green-300 border-green-800"
          >
            <TrendingUp className="h-3 w-3" />
            <span>Média: {averageMood.toFixed(1)}/10</span>
          </Badge>
        </CardTitle>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Calendar Grid */}
        <div className="grid grid-cols-7 gap-2">
          {["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"].map((day) => (
            <div key={day} className="text-center text-xs text-gray-400 font-medium p-2">
              {day}
            </div>
          ))}

          {/* Empty cells for calendar alignment */}
          {Array.from({ length: 6 }, (_, i) => (
            <div key={`empty-${i}`} className="aspect-square"></div>
          ))}

          {/* Mood data */}
          {moodData.map((day, index) => (
            <div
              key={day.date}
              className={`aspect-square rounded-lg ${day.color} flex flex-col items-center justify-center cursor-pointer hover:scale-110 transition-transform group relative`}
            >
              <span className="text-lg">{day.emoji}</span>
              <span className="text-xs text-white font-medium">{new Date(day.date).getDate()}</span>

              {/* Tooltip */}
              <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-2 py-1 bg-gray-900 text-white text-xs rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-10">
                {day.note} ({day.mood}/10)
              </div>
            </div>
          ))}
        </div>

        {/* Recent Entries */}
        <div className="space-y-3">
          <h4 className="font-semibold text-white text-sm">Últimos registros:</h4>
          {moodData
            .slice(-3)
            .reverse()
            .map((day) => (
              <div key={day.date} className="flex items-center justify-between p-3 bg-[#0F1B2A] rounded-lg">
                <div className="flex items-center space-x-3">
                  <span className="text-2xl">{day.emoji}</span>
                  <div>
                    <p className="text-sm font-medium text-white">{day.note}</p>
                    <p className="text-xs text-gray-400">{new Date(day.date).toLocaleDateString("pt-BR")}</p>
                  </div>
                </div>
                <Badge variant="outline" className="text-xs">
                  {day.mood}/10
                </Badge>
              </div>
            ))}
        </div>

        {/* Mood Patterns */}
        <div className="space-y-3">
          <h4 className="font-semibold text-white text-sm">Padrões identificados:</h4>
          <div className="space-y-2">
            <div className="flex items-center justify-between p-2 bg-blue-900/20 rounded border border-blue-800">
              <span className="text-sm text-blue-300">🌅 Manhãs são melhores</span>
              <Badge variant="outline" className="text-xs bg-blue-900/30 border-blue-700 text-blue-300">
                IA Insight
              </Badge>
            </div>
            <div className="flex items-center justify-between p-2 bg-orange-900/20 rounded border border-orange-800">
              <span className="text-sm text-orange-300">📱 Uso excessivo afeta humor</span>
              <Badge variant="outline" className="text-xs bg-orange-900/30 border-orange-700 text-orange-300">
                Correlação
              </Badge>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
