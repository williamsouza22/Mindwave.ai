"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Smartphone, TrendingDown, Target, Award } from "lucide-react"

export function DigitalDetox() {
  const screenTimeData = {
    today: 4.2,
    goal: 3.0,
    yesterday: 5.8,
    weekAverage: 4.5,
    improvement: -1.6,
  }

  const apps = [
    { name: "Instagram", time: 1.5, color: "bg-pink-500" },
    { name: "TikTok", time: 1.2, color: "bg-purple-500" },
    { name: "WhatsApp", time: 0.8, color: "bg-green-500" },
    { name: "YouTube", time: 0.7, color: "bg-red-500" },
  ]

  return (
    <Card className="bg-[#1A2332] border-gray-800">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Smartphone className="h-5 w-5 text-blue-400" />
          <span className="text-white">Detox Digital</span>
          <Badge variant="secondary" className="bg-blue-900/50 text-blue-300 border-blue-800 ml-auto">
            Nomofobia
          </Badge>
        </CardTitle>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Today's Progress */}
        <div className="text-center space-y-3">
          <div className="relative">
            <div className="w-24 h-24 mx-auto">
              <svg className="w-24 h-24 transform -rotate-90" viewBox="0 0 36 36">
                <path
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                  fill="none"
                  stroke="#374151"
                  strokeWidth="2"
                />
                <path
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                  fill="none"
                  stroke="#3B82F6"
                  strokeWidth="2"
                  strokeDasharray={`${(screenTimeData.today / screenTimeData.goal) * 100}, 100`}
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <div className="text-lg font-bold text-white">{screenTimeData.today}h</div>
                  <div className="text-xs text-gray-400">hoje</div>
                </div>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-center space-x-2">
            <Target className="h-4 w-4 text-gray-400" />
            <span className="text-sm text-gray-400">Meta: {screenTimeData.goal}h</span>
            {screenTimeData.today > screenTimeData.goal ? (
              <Badge variant="secondary" className="bg-red-900/50 text-red-300 border-red-800 text-xs">
                +{(screenTimeData.today - screenTimeData.goal).toFixed(1)}h
              </Badge>
            ) : (
              <Badge variant="secondary" className="bg-green-900/50 text-green-300 border-green-800 text-xs">
                <Award className="h-3 w-3 mr-1" />
                Meta atingida!
              </Badge>
            )}
          </div>
        </div>

        {/* App Usage */}
        <div className="space-y-3">
          <h4 className="font-semibold text-white text-sm">Apps mais usados hoje:</h4>
          {apps.map((app, index) => (
            <div key={app.name} className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className={`w-3 h-3 rounded ${app.color}`}></div>
                <span className="text-sm text-gray-300">{app.name}</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-16 bg-gray-700 rounded-full h-1">
                  <div
                    className={`h-1 rounded-full ${app.color}`}
                    style={{ width: `${(app.time / screenTimeData.today) * 100}%` }}
                  ></div>
                </div>
                <span className="text-xs text-gray-400 w-8 text-right">{app.time}h</span>
              </div>
            </div>
          ))}
        </div>

        {/* Weekly Progress */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="font-semibold text-white text-sm">Progresso semanal:</h4>
            <div className="flex items-center space-x-1">
              <TrendingDown className="h-4 w-4 text-green-400" />
              <span className="text-xs text-green-400">-1.6h</span>
            </div>
          </div>

          <div className="grid grid-cols-7 gap-1">
            {["D", "S", "T", "Q", "Q", "S", "S"].map((day, index) => {
              const hours = [3.2, 4.1, 5.8, 4.5, 3.9, 4.2, 4.2][index]
              const isToday = index === 6
              return (
                <div key={day} className="text-center">
                  <div className="text-xs text-gray-400 mb-1">{day}</div>
                  <div
                    className={`h-8 rounded ${isToday ? "bg-blue-500" : hours > screenTimeData.goal ? "bg-red-500" : "bg-green-500"} flex items-end justify-center`}
                    style={{ opacity: hours / 6 }}
                  >
                    <span className="text-xs text-white mb-1">{hours}</span>
                  </div>
                </div>
              )
            })}
          </div>
        </div>

        {/* Actions */}
        <div className="space-y-2">
          <Button
            variant="outline"
            size="sm"
            className="w-full bg-transparent border-gray-700 text-gray-300 hover:bg-gray-800"
          >
            📱 Ativar Modo Foco
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="w-full bg-transparent border-gray-700 text-gray-300 hover:bg-gray-800"
          >
            ⏰ Definir Lembrete
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
