"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { TrendingUp, Calendar } from "lucide-react"

// Mock data for mood tracking
const moodData = [
  { date: "2024-01-01", mood: 7, note: "Dia produtivo" },
  { date: "2024-01-02", mood: 5, note: "Um pouco ansioso" },
  { date: "2024-01-03", mood: 8, note: "Excelente!" },
  { date: "2024-01-04", mood: 6, note: "Normal" },
  { date: "2024-01-05", mood: 9, note: "Muito feliz" },
  { date: "2024-01-06", mood: 4, note: "Estressado" },
  { date: "2024-01-07", mood: 7, note: "Melhorando" },
]

const getMoodColor = (mood: number) => {
  if (mood >= 8) return "bg-green-500"
  if (mood >= 6) return "bg-yellow-500"
  if (mood >= 4) return "bg-orange-500"
  return "bg-red-500"
}

const getMoodEmoji = (mood: number) => {
  if (mood >= 8) return "😊"
  if (mood >= 6) return "😐"
  if (mood >= 4) return "😕"
  return "😢"
}

export function MoodChart() {
  const averageMood = moodData.reduce((sum, day) => sum + day.mood, 0) / moodData.length
  const trend = moodData[moodData.length - 1].mood > moodData[0].mood ? "up" : "down"

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center space-x-2">
            <Calendar className="h-5 w-5 text-blue-500" />
            <span>Histórico de Humor</span>
          </CardTitle>
          <Badge variant="secondary" className="flex items-center space-x-1">
            <TrendingUp className="h-3 w-3" />
            <span>Média: {averageMood.toFixed(1)}/10</span>
          </Badge>
        </div>
      </CardHeader>

      <CardContent>
        <div className="space-y-4">
          {/* Chart visualization */}
          <div className="flex items-end justify-between h-32 bg-gray-50 rounded-lg p-4">
            {moodData.map((day, index) => (
              <div key={day.date} className="flex flex-col items-center space-y-2">
                <div
                  className={`w-6 rounded-t ${getMoodColor(day.mood)}`}
                  style={{ height: `${(day.mood / 10) * 80}px` }}
                ></div>
                <span className="text-xs text-gray-500">{new Date(day.date).getDate()}</span>
              </div>
            ))}
          </div>

          {/* Recent entries */}
          <div className="space-y-2">
            <h4 className="font-semibold text-sm text-gray-700">Últimos registros:</h4>
            {moodData
              .slice(-3)
              .reverse()
              .map((day) => (
                <div key={day.date} className="flex items-center justify-between p-2 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <span className="text-lg">{getMoodEmoji(day.mood)}</span>
                    <div>
                      <p className="text-sm font-medium">{day.note}</p>
                      <p className="text-xs text-gray-500">{new Date(day.date).toLocaleDateString("pt-BR")}</p>
                    </div>
                  </div>
                  <Badge variant="outline">{day.mood}/10</Badge>
                </div>
              ))}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
