"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Heart, MessageCircle, Headphones, BookOpen, Calendar, Zap, Crown } from "lucide-react"
import { motion } from "framer-motion"
import { useAuth } from "@/lib/auth/auth-context"
import Link from "next/link"

const quickActions = [
  {
    id: "checkin",
    title: "Check-in Diário",
    description: "Como você está se sentindo?",
    icon: Heart,
    color: "from-red-500 to-pink-500",
    action: "Começar",
    premium: false,
  },
  {
    id: "chat",
    title: "Conversar com IA",
    description: "Apoio emocional 24/7",
    icon: MessageCircle,
    color: "from-blue-500 to-cyan-500",
    action: "Conversar",
    premium: false,
  },
  {
    id: "meditation",
    title: "Meditação Guiada",
    description: "Sessões personalizadas",
    icon: Headphones,
    color: "from-purple-500 to-indigo-500",
    action: "Meditar",
    premium: true,
  },
  {
    id: "journal",
    title: "Diário Inteligente",
    description: "Reflexões com IA",
    icon: BookOpen,
    color: "from-green-500 to-emerald-500",
    action: "Escrever",
    premium: true,
  },
  {
    id: "schedule",
    title: "Agendar Sessão",
    description: "Terapia online",
    icon: Calendar,
    color: "from-yellow-500 to-orange-500",
    action: "Agendar",
    premium: true,
  },
]

export function QuickActions() {
  const { profile } = useAuth()
  const isPremium = profile?.plan === "premium"

  return (
    <Card className="bg-[#1A2332] border-gray-800">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Zap className="h-5 w-5 text-yellow-400" />
          <span className="text-white">Ações Rápidas</span>
        </CardTitle>
      </CardHeader>

      <CardContent className="space-y-3">
        {quickActions.map((action, index) => (
          <motion.div
            key={action.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.4, delay: index * 0.1 }}
          >
            <div
              className={`p-4 rounded-lg border transition-all duration-300 hover:scale-105 ${
                action.premium && !isPremium
                  ? "bg-gray-800/50 border-gray-700 opacity-75"
                  : "bg-[#0F1B2A] border-gray-700 hover:border-gray-600"
              }`}
            >
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-3">
                  <div
                    className={`h-10 w-10 rounded-lg bg-gradient-to-r ${action.color} flex items-center justify-center`}
                  >
                    <action.icon className="h-5 w-5 text-white" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center space-x-2">
                      <h3 className="font-medium text-white text-sm">{action.title}</h3>
                      {action.premium && <Crown className="h-3 w-3 text-yellow-400" />}
                    </div>
                    <p className="text-xs text-gray-400">{action.description}</p>
                  </div>
                </div>
              </div>

              {action.premium && !isPremium ? (
                <div className="space-y-2">
                  <Badge variant="outline" className="text-xs bg-yellow-900/30 border-yellow-700 text-yellow-300">
                    Premium
                  </Badge>
                  <Button
                    variant="outline"
                    size="sm"
                    className="w-full bg-transparent border-gray-700 text-gray-400"
                    asChild
                  >
                    <Link href="/pricing">Upgrade</Link>
                  </Button>
                </div>
              ) : (
                <Button size="sm" className={`w-full bg-gradient-to-r ${action.color} hover:opacity-90`}>
                  {action.action}
                </Button>
              )}
            </div>
          </motion.div>
        ))}

        {/* Premium Upgrade Card */}
        {!isPremium && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.5 }}
            className="mt-6 p-4 bg-gradient-to-r from-yellow-900/20 to-orange-900/20 rounded-lg border border-yellow-800"
          >
            <div className="text-center space-y-3">
              <Crown className="h-8 w-8 text-yellow-400 mx-auto" />
              <div>
                <h3 className="font-semibold text-white text-sm">Desbloqueie o Premium</h3>
                <p className="text-xs text-gray-400">Acesso completo a todas as funcionalidades</p>
              </div>
              <Button
                className="w-full bg-gradient-to-r from-yellow-600 to-orange-600 hover:from-yellow-700 hover:to-orange-700"
                size="sm"
                asChild
              >
                <Link href="/pricing">
                  <Crown className="h-4 w-4 mr-2" />
                  Upgrade Agora
                </Link>
              </Button>
            </div>
          </motion.div>
        )}
      </CardContent>
    </Card>
  )
}
