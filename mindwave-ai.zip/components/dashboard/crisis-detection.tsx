"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { AlertTriangle, Heart, Phone, Play, Pause } from "lucide-react"
import { motion } from "framer-motion"

export function CrisisDetection() {
  const [crisisLevel, setCrisisLevel] = useState<"low" | "medium" | "high">("low")
  const [isBreathingActive, setIsBreathingActive] = useState(false)

  const crisisConfig = {
    low: {
      color: "text-green-400",
      bgColor: "bg-green-900/20",
      borderColor: "border-green-800",
      message: "Você está bem! Continue cuidando de si mesmo.",
      actions: [],
    },
    medium: {
      color: "text-yellow-400",
      bgColor: "bg-yellow-900/20",
      borderColor: "border-yellow-800",
      message: "Detectamos alguns sinais de ansiedade. Que tal uma pausa?",
      actions: ["Respiração guiada", "Música relaxante"],
    },
    high: {
      color: "text-red-400",
      bgColor: "bg-red-900/20",
      borderColor: "border-red-800",
      message: "Crise detectada! Ativando protocolo de emergência.",
      actions: ["Respiração de emergência", "Contato de apoio", "Conteúdo calmante"],
    },
  }

  const currentConfig = crisisConfig[crisisLevel]

  return (
    <Card className={`bg-[#1A2332] border-gray-800 ${currentConfig.borderColor}`}>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <AlertTriangle className={`h-5 w-5 ${currentConfig.color}`} />
            <span className="text-white">Monitor de Crise</span>
          </div>
          <Badge variant="secondary" className={`${currentConfig.bgColor} ${currentConfig.color} border-current`}>
            {crisisLevel === "low" && "Estável"}
            {crisisLevel === "medium" && "Atenção"}
            {crisisLevel === "high" && "Emergência"}
          </Badge>
        </CardTitle>
      </CardHeader>

      <CardContent className="space-y-6">
        <div className={`p-4 rounded-lg ${currentConfig.bgColor} ${currentConfig.borderColor} border`}>
          <p className="text-white text-sm">{currentConfig.message}</p>
        </div>

        {/* Vital Signs Simulation */}
        <div className="grid grid-cols-3 gap-4">
          <div className="text-center">
            <div className="text-2xl font-bold text-white">72</div>
            <div className="text-xs text-gray-400">BPM</div>
            <div className="h-1 bg-green-500 rounded mt-1"></div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-white">Normal</div>
            <div className="text-xs text-gray-400">Respiração</div>
            <div className="h-1 bg-blue-500 rounded mt-1"></div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-white">Baixo</div>
            <div className="text-xs text-gray-400">Estresse</div>
            <div className="h-1 bg-yellow-500 rounded mt-1"></div>
          </div>
        </div>

        {/* Crisis Actions */}
        {currentConfig.actions.length > 0 && (
          <div className="space-y-3">
            <h4 className="font-semibold text-white text-sm">Ações Recomendadas:</h4>
            <div className="grid grid-cols-1 gap-2">
              {currentConfig.actions.map((action, index) => (
                <Button
                  key={index}
                  variant="outline"
                  size="sm"
                  className="bg-transparent border-gray-700 text-gray-300 hover:bg-gray-800 justify-start"
                  onClick={() => {
                    if (action.includes("Respiração")) {
                      setIsBreathingActive(!isBreathingActive)
                    }
                  }}
                >
                  {action.includes("Respiração") && (
                    <>{isBreathingActive ? <Pause className="h-4 w-4 mr-2" /> : <Play className="h-4 w-4 mr-2" />}</>
                  )}
                  {action.includes("Contato") && <Phone className="h-4 w-4 mr-2" />}
                  {action.includes("Conteúdo") && <Heart className="h-4 w-4 mr-2" />}
                  {action}
                </Button>
              ))}
            </div>
          </div>
        )}

        {/* Breathing Exercise */}
        {isBreathingActive && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center p-6 bg-blue-900/20 rounded-lg border border-blue-800"
          >
            <motion.div
              animate={{
                scale: [1, 1.2, 1],
                opacity: [0.5, 1, 0.5],
              }}
              transition={{
                duration: 4,
                repeat: Number.POSITIVE_INFINITY,
                ease: "easeInOut",
              }}
              className="w-20 h-20 mx-auto mb-4 rounded-full bg-gradient-to-r from-blue-500 to-purple-500 flex items-center justify-center"
            >
              <Heart className="h-8 w-8 text-white" />
            </motion.div>
            <p className="text-white text-sm">Inspire por 4 segundos... Segure por 7... Expire por 8...</p>
          </motion.div>
        )}

        {/* Test Crisis Levels */}
        <div className="flex space-x-2">
          <Button
            size="sm"
            variant="outline"
            onClick={() => setCrisisLevel("low")}
            className="bg-transparent border-green-700 text-green-300 hover:bg-green-800/20"
          >
            Simular Normal
          </Button>
          <Button
            size="sm"
            variant="outline"
            onClick={() => setCrisisLevel("medium")}
            className="bg-transparent border-yellow-700 text-yellow-300 hover:bg-yellow-800/20"
          >
            Simular Ansiedade
          </Button>
          <Button
            size="sm"
            variant="outline"
            onClick={() => setCrisisLevel("high")}
            className="bg-transparent border-red-700 text-red-300 hover:bg-red-800/20"
          >
            Simular Crise
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
