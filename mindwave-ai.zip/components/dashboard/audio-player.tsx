"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Play, Pause, SkipBack, SkipForward, Headphones } from "lucide-react"

const audioSessions = [
  {
    id: "1",
    title: "Respiração para Ansiedade",
    duration: "5:30",
    category: "Ansiedade",
    description: "Técnica de respiração 4-7-8 para reduzir ansiedade",
  },
  {
    id: "2",
    title: "Meditação Matinal",
    duration: "10:00",
    category: "Meditação",
    description: "Comece o dia com clareza mental",
  },
  {
    id: "3",
    title: "Relaxamento Noturno",
    duration: "8:15",
    category: "Sono",
    description: "Prepare-se para uma noite tranquila",
  },
]

export function AudioPlayer() {
  const [currentAudio, setCurrentAudio] = useState(audioSessions[0])
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentTime, setCurrentTime] = useState(0)

  const togglePlay = () => {
    setIsPlaying(!isPlaying)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Headphones className="h-5 w-5 text-purple-500" />
          <span>Áudios Guiados</span>
        </CardTitle>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Current Audio */}
        <div className="bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg p-4">
          <div className="flex items-center justify-between mb-2">
            <Badge variant="secondary">{currentAudio.category}</Badge>
            <span className="text-sm text-gray-500">{currentAudio.duration}</span>
          </div>

          <h4 className="font-semibold text-gray-900 mb-1">{currentAudio.title}</h4>
          <p className="text-sm text-gray-600 mb-4">{currentAudio.description}</p>

          {/* Progress bar */}
          <div className="w-full bg-gray-200 rounded-full h-2 mb-4">
            <div
              className="bg-gradient-to-r from-purple-500 to-blue-500 h-2 rounded-full transition-all duration-300"
              style={{ width: `${(currentTime / 330) * 100}%` }}
            ></div>
          </div>

          {/* Controls */}
          <div className="flex items-center justify-center space-x-4">
            <Button variant="outline" size="sm">
              <SkipBack className="h-4 w-4" />
            </Button>
            <Button onClick={togglePlay} size="sm" className="bg-gradient-to-r from-purple-500 to-blue-500">
              {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
            </Button>
            <Button variant="outline" size="sm">
              <SkipForward className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Audio List */}
        <div className="space-y-2">
          <h4 className="font-semibold text-sm text-gray-700">Outras sessões:</h4>
          {audioSessions
            .filter((audio) => audio.id !== currentAudio.id)
            .map((audio) => (
              <div
                key={audio.id}
                className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 cursor-pointer transition-colors"
                onClick={() => setCurrentAudio(audio)}
              >
                <div className="flex-1">
                  <p className="font-medium text-sm">{audio.title}</p>
                  <p className="text-xs text-gray-500">{audio.category}</p>
                </div>
                <span className="text-xs text-gray-500">{audio.duration}</span>
              </div>
            ))}
        </div>
      </CardContent>
    </Card>
  )
}
