"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { TrendingUp, Calendar, Target, Award } from "lucide-react"

const stats = [
  {
    title: "Sequência Atual",
    value: "7 dias",
    change: "+2 dias",
    trend: "up",
    icon: Target,
    color: "text-green-600",
  },
  {
    title: "Check-ins Este Mês",
    value: "23",
    change: "+15%",
    trend: "up",
    icon: Calendar,
    color: "text-blue-600",
  },
  {
    title: "Humor Médio",
    value: "7.2/10",
    change: "+0.8",
    trend: "up",
    icon: TrendingUp,
    color: "text-purple-600",
  },
  {
    title: "Conquistas",
    value: "12",
    change: "+3 novas",
    trend: "up",
    icon: Award,
    color: "text-yellow-600",
  },
]

export function StatsCards() {
  return (
    <div className="space-y-4">
      {stats.map((stat) => (
        <Card key={stat.title}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">{stat.title}</CardTitle>
            <stat.icon className={`h-4 w-4 ${stat.color}`} />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stat.value}</div>
            <div className="flex items-center space-x-2 mt-1">
              <Badge
                variant="secondary"
                className={`text-xs ${stat.trend === "up" ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}`}
              >
                {stat.change}
              </Badge>
              <span className="text-xs text-gray-500">vs. mês anterior</span>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
