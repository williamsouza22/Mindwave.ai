"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Badge } from "@/components/ui/badge"
import { useAuth } from "@/lib/auth/auth-context"
import { useToast } from "@/hooks/use-toast"
import { Bell, Clock, Heart, Brain, Smartphone, Volume2 } from "lucide-react"
import { motion } from "framer-motion"

interface NotificationSettings {
  dailyCheckin: boolean
  checkinTime: string
  meditation: boolean
  meditationTime: string
  crisis: boolean
  motivational: boolean
  motivationalFrequency: string
  weeklyReport: boolean
  reportDay: string
  soundEnabled: boolean
  vibrationEnabled: boolean
  quietHours: boolean
  quietStart: string
  quietEnd: string
  frequency: number[]
}

export function NotificationSettings() {
  const [settings, setSettings] = useState<NotificationSettings>({
    dailyCheckin: true,
    checkinTime: "09:00",
    meditation: true,
    meditationTime: "20:00",
    crisis: true,
    motivational: false,
    motivationalFrequency: "daily",
    weeklyReport: true,
    reportDay: "sunday",
    soundEnabled: true,
    vibrationEnabled: true,
    quietHours: true,
    quietStart: "22:00",
    quietEnd: "07:00",
    frequency: [3],
  })

  const [loading, setLoading] = useState(false)
  const [permissionStatus, setPermissionStatus] = useState<string>("default")
  const { user } = useAuth()
  const { toast } = useToast()

  useEffect(() => {
    if ("Notification" in window) {
      setPermissionStatus(Notification.permission)
    }
    loadSettings()
  }, [])

  const loadSettings = async () => {
    try {
      const response = await fetch("/api/settings/notifications")
      if (response.ok) {
        const data = await response.json()
        setSettings({ ...settings, ...data })
      }
    } catch (error) {
      console.error("Error loading notification settings:", error)
    }
  }

  const requestNotificationPermission = async () => {
    if ("Notification" in window) {
      const permission = await Notification.requestPermission()
      setPermissionStatus(permission)

      if (permission === "granted") {
        toast({
          title: "Notificações ativadas! 🔔",
          description: "Você receberá lembretes gentis para cuidar da sua saúde mental.",
        })
      }
    }
  }

  const saveSettings = async () => {
    setLoading(true)
    try {
      const response = await fetch("/api/settings/notifications", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(settings),
      })

      if (response.ok) {
        toast({
          title: "Configurações salvas! ✅",
          description: "Suas preferências de notificação foram atualizadas.",
        })
      }
    } catch (error) {
      toast({
        title: "Erro ao salvar",
        description: "Tente novamente em alguns instantes.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const testNotification = () => {
    if (Notification.permission === "granted") {
      new Notification("MindWave.AI 🌊", {
        body: "Esta é uma notificação de teste! Como você está se sentindo hoje?",
        icon: "/favicon.ico",
        badge: "/favicon.ico",
      })
    }
  }

  return (
    <div className="space-y-6">
      {/* Permission Status */}
      <Card className="bg-[#1A2332] border-gray-800">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Bell className="h-5 w-5 text-blue-400" />
            <span className="text-white">Status das Notificações</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-medium text-white">Permissão do Navegador</h3>
              <p className="text-sm text-gray-400">
                {permissionStatus === "granted"
                  ? "Notificações ativadas e funcionando"
                  : "Clique para ativar notificações no navegador"}
              </p>
            </div>
            <div className="flex items-center space-x-2">
              <Badge
                variant={permissionStatus === "granted" ? "default" : "secondary"}
                className={
                  permissionStatus === "granted"
                    ? "bg-green-600 hover:bg-green-700"
                    : "bg-yellow-600 hover:bg-yellow-700"
                }
              >
                {permissionStatus === "granted" ? "Ativo" : "Inativo"}
              </Badge>
              {permissionStatus !== "granted" && (
                <Button onClick={requestNotificationPermission} size="sm">
                  Ativar
                </Button>
              )}
              {permissionStatus === "granted" && (
                <Button onClick={testNotification} variant="outline" size="sm">
                  Testar
                </Button>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Daily Check-in */}
      <Card className="bg-[#1A2332] border-gray-800">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Heart className="h-5 w-5 text-pink-400" />
            <span className="text-white">Check-in Diário</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="daily-checkin" className="text-white">
                Lembrete diário
              </Label>
              <p className="text-sm text-gray-400">Receba um lembrete gentil para registrar seu humor</p>
            </div>
            <Switch
              id="daily-checkin"
              checked={settings.dailyCheckin}
              onCheckedChange={(checked) => setSettings({ ...settings, dailyCheckin: checked })}
            />
          </div>

          {settings.dailyCheckin && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              className="space-y-3 pt-4 border-t border-gray-700"
            >
              <div className="flex items-center space-x-4">
                <Clock className="h-4 w-4 text-gray-400" />
                <Label className="text-white">Horário:</Label>
                <Select
                  value={settings.checkinTime}
                  onValueChange={(value) => setSettings({ ...settings, checkinTime: value })}
                >
                  <SelectTrigger className="w-32 bg-gray-800 border-gray-700">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="07:00">07:00</SelectItem>
                    <SelectItem value="08:00">08:00</SelectItem>
                    <SelectItem value="09:00">09:00</SelectItem>
                    <SelectItem value="10:00">10:00</SelectItem>
                    <SelectItem value="11:00">11:00</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </motion.div>
          )}
        </CardContent>
      </Card>

      {/* Meditation Reminders */}
      <Card className="bg-[#1A2332] border-gray-800">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Brain className="h-5 w-5 text-purple-400" />
            <span className="text-white">Mindfulness & Meditação</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="meditation" className="text-white">
                Lembrete de meditação
              </Label>
              <p className="text-sm text-gray-400">Momento para relaxar e praticar mindfulness</p>
            </div>
            <Switch
              id="meditation"
              checked={settings.meditation}
              onCheckedChange={(checked) => setSettings({ ...settings, meditation: checked })}
            />
          </div>

          {settings.meditation && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              className="space-y-3 pt-4 border-t border-gray-700"
            >
              <div className="flex items-center space-x-4">
                <Clock className="h-4 w-4 text-gray-400" />
                <Label className="text-white">Horário:</Label>
                <Select
                  value={settings.meditationTime}
                  onValueChange={(value) => setSettings({ ...settings, meditationTime: value })}
                >
                  <SelectTrigger className="w-32 bg-gray-800 border-gray-700">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="18:00">18:00</SelectItem>
                    <SelectItem value="19:00">19:00</SelectItem>
                    <SelectItem value="20:00">20:00</SelectItem>
                    <SelectItem value="21:00">21:00</SelectItem>
                    <SelectItem value="22:00">22:00</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </motion.div>
          )}
        </CardContent>
      </Card>

      {/* Crisis & Emergency */}
      <Card className="bg-[#1A2332] border-gray-800">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Bell className="h-5 w-5 text-red-400" />
            <span className="text-white">Alertas de Crise</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="crisis" className="text-white">
                Detecção de crise
              </Label>
              <p className="text-sm text-gray-400">Receba suporte imediato quando detectarmos sinais de crise</p>
            </div>
            <Switch
              id="crisis"
              checked={settings.crisis}
              onCheckedChange={(checked) => setSettings({ ...settings, crisis: checked })}
            />
          </div>
        </CardContent>
      </Card>

      {/* Weekly Reports */}
      <Card className="bg-[#1A2332] border-gray-800">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Heart className="h-5 w-5 text-green-400" />
            <span className="text-white">Relatórios Semanais</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="weekly-report" className="text-white">
                Resumo semanal
              </Label>
              <p className="text-sm text-gray-400">Receba insights sobre seu progresso emocional</p>
            </div>
            <Switch
              id="weekly-report"
              checked={settings.weeklyReport}
              onCheckedChange={(checked) => setSettings({ ...settings, weeklyReport: checked })}
            />
          </div>

          {settings.weeklyReport && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              className="space-y-3 pt-4 border-t border-gray-700"
            >
              <div className="flex items-center space-x-4">
                <Label className="text-white">Dia da semana:</Label>
                <Select
                  value={settings.reportDay}
                  onValueChange={(value) => setSettings({ ...settings, reportDay: value })}
                >
                  <SelectTrigger className="w-40 bg-gray-800 border-gray-700">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="sunday">Domingo</SelectItem>
                    <SelectItem value="monday">Segunda-feira</SelectItem>
                    <SelectItem value="friday">Sexta-feira</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </motion.div>
          )}
        </CardContent>
      </Card>

      {/* Sound & Vibration */}
      <Card className="bg-[#1A2332] border-gray-800">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Volume2 className="h-5 w-5 text-blue-400" />
            <span className="text-white">Som & Vibração</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="sound" className="text-white">
                Som das notificações
              </Label>
              <p className="text-sm text-gray-400">Reproduzir som quando receber notificações</p>
            </div>
            <Switch
              id="sound"
              checked={settings.soundEnabled}
              onCheckedChange={(checked) => setSettings({ ...settings, soundEnabled: checked })}
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="vibration" className="text-white">
                Vibração
              </Label>
              <p className="text-sm text-gray-400">Vibrar dispositivo móvel</p>
            </div>
            <Switch
              id="vibration"
              checked={settings.vibrationEnabled}
              onCheckedChange={(checked) => setSettings({ ...settings, vibrationEnabled: checked })}
            />
          </div>
        </CardContent>
      </Card>

      {/* Quiet Hours */}
      <Card className="bg-[#1A2332] border-gray-800">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Smartphone className="h-5 w-5 text-yellow-400" />
            <span className="text-white">Horário Silencioso</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="quiet-hours" className="text-white">
                Ativar modo silencioso
              </Label>
              <p className="text-sm text-gray-400">Não receber notificações durante o período de descanso</p>
            </div>
            <Switch
              id="quiet-hours"
              checked={settings.quietHours}
              onCheckedChange={(checked) => setSettings({ ...settings, quietHours: checked })}
            />
          </div>

          {settings.quietHours && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              className="space-y-3 pt-4 border-t border-gray-700"
            >
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-white">Início:</Label>
                  <Select
                    value={settings.quietStart}
                    onValueChange={(value) => setSettings({ ...settings, quietStart: value })}
                  >
                    <SelectTrigger className="bg-gray-800 border-gray-700">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="21:00">21:00</SelectItem>
                      <SelectItem value="22:00">22:00</SelectItem>
                      <SelectItem value="23:00">23:00</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-white">Fim:</Label>
                  <Select
                    value={settings.quietEnd}
                    onValueChange={(value) => setSettings({ ...settings, quietEnd: value })}
                  >
                    <SelectTrigger className="bg-gray-800 border-gray-700">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="06:00">06:00</SelectItem>
                      <SelectItem value="07:00">07:00</SelectItem>
                      <SelectItem value="08:00">08:00</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </motion.div>
          )}
        </CardContent>
      </Card>

      {/* Frequency Control */}
      <Card className="bg-[#1A2332] border-gray-800">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Clock className="h-5 w-5 text-indigo-400" />
            <span className="text-white">Frequência de Notificações</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label className="text-white">Notificações por dia: {settings.frequency[0]}</Label>
            <p className="text-sm text-gray-400 mb-4">Controle quantas notificações você quer receber</p>
            <Slider
              value={settings.frequency}
              onValueChange={(value) => setSettings({ ...settings, frequency: value })}
              max={10}
              min={1}
              step={1}
              className="w-full"
            />
            <div className="flex justify-between text-xs text-gray-500 mt-2">
              <span>Mínimo (1)</span>
              <span>Moderado (5)</span>
              <span>Máximo (10)</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Save Button */}
      <div className="flex justify-end">
        <Button
          onClick={saveSettings}
          disabled={loading}
          className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
        >
          {loading ? "Salvando..." : "Salvar Configurações"}
        </Button>
      </div>
    </div>
  )
}
