"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { useAuth } from "@/lib/auth/auth-context"
import { useToast } from "@/hooks/use-toast"
import { Shield, Eye, Database, Download, Trash2, AlertTriangle, Lock, Key } from "lucide-react"
import { motion } from "framer-motion"

interface PrivacySettings {
  dataCollection: boolean
  analyticsSharing: boolean
  personalizedAds: boolean
  thirdPartySharing: boolean
  locationTracking: boolean
  crashReporting: boolean
  usageAnalytics: boolean
  dataRetention: string
  encryptionLevel: string
  twoFactorAuth: boolean
  sessionTimeout: string
  ipLogging: boolean
  deviceTracking: boolean
}

export function PrivacySettings() {
  const [settings, setSettings] = useState<PrivacySettings>({
    dataCollection: true,
    analyticsSharing: false,
    personalizedAds: false,
    thirdPartySharing: false,
    locationTracking: false,
    crashReporting: true,
    usageAnalytics: true,
    dataRetention: "2years",
    encryptionLevel: "aes256",
    twoFactorAuth: false,
    sessionTimeout: "30days",
    ipLogging: false,
    deviceTracking: false,
  })

  const [loading, setLoading] = useState(false)
  const [showDangerZone, setShowDangerZone] = useState(false)
  const { user } = useAuth()
  const { toast } = useToast()

  useEffect(() => {
    loadSettings()
  }, [])

  const loadSettings = async () => {
    try {
      const response = await fetch("/api/settings/privacy")
      if (response.ok) {
        const data = await response.json()
        setSettings({ ...settings, ...data })
      }
    } catch (error) {
      console.error("Error loading privacy settings:", error)
    }
  }

  const saveSettings = async () => {
    setLoading(true)
    try {
      const response = await fetch("/api/settings/privacy", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(settings),
      })

      if (response.ok) {
        toast({
          title: "Configurações de privacidade salvas! 🔒",
          description: "Suas preferências foram atualizadas com segurança.",
        })
      }
    } catch (error) {
      toast({
        title: "Erro ao salvar",
        description: "Tente novamente em alguns instantes.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const exportData = async () => {
    try {
      const response = await fetch("/api/user/export-data", {
        method: "POST",
      })

      if (response.ok) {
        const blob = await response.blob()
        const url = window.URL.createObjectURL(blob)
        const a = document.createElement("a")
        a.href = url
        a.download = `mindwave-data-${new Date().toISOString().split("T")[0]}.json`
        document.body.appendChild(a)
        a.click()
        window.URL.revokeObjectURL(url)
        document.body.removeChild(a)

        toast({
          title: "Dados exportados! 📥",
          description: "Seus dados foram baixados com segurança.",
        })
      }
    } catch (error) {
      toast({
        title: "Erro na exportação",
        description: "Não foi possível exportar seus dados.",
        variant: "destructive",
      })
    }
  }

  const deleteAllData = async () => {
    if (
      window.confirm(
        "⚠️ ATENÇÃO: Esta ação é irreversível! Todos os seus dados serão permanentemente excluídos. Tem certeza?",
      )
    ) {
      try {
        const response = await fetch("/api/user/delete-data", {
          method: "DELETE",
        })

        if (response.ok) {
          toast({
            title: "Dados excluídos",
            description: "Todos os seus dados foram removidos permanentemente.",
          })
          // Redirect to home after data deletion
          setTimeout(() => {
            window.location.href = "/"
          }, 2000)
        }
      } catch (error) {
        toast({
          title: "Erro na exclusão",
          description: "Não foi possível excluir seus dados.",
          variant: "destructive",
        })
      }
    }
  }

  return (
    <div className="space-y-6">
      {/* Privacy Overview */}
      <Card className="bg-[#1A2332] border-gray-800">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Shield className="h-5 w-5 text-green-400" />
            <span className="text-white">Visão Geral da Privacidade</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center p-4 bg-green-900/20 rounded-lg border border-green-800">
              <Lock className="h-6 w-6 text-green-400 mx-auto mb-2" />
              <p className="text-sm text-green-300">Criptografia AES-256</p>
            </div>
            <div className="text-center p-4 bg-blue-900/20 rounded-lg border border-blue-800">
              <Eye className="h-6 w-6 text-blue-400 mx-auto mb-2" />
              <p className="text-sm text-blue-300">Dados Privados</p>
            </div>
            <div className="text-center p-4 bg-purple-900/20 rounded-lg border border-purple-800">
              <Database className="h-6 w-6 text-purple-400 mx-auto mb-2" />
              <p className="text-sm text-purple-300">LGPD Compliant</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Data Collection */}
      <Card className="bg-[#1A2332] border-gray-800">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Database className="h-5 w-5 text-blue-400" />
            <span className="text-white">Coleta de Dados</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="data-collection" className="text-white">
                Coleta básica de dados
              </Label>
              <p className="text-sm text-gray-400">Necessário para funcionamento do app (humor, sessões)</p>
            </div>
            <Switch
              id="data-collection"
              checked={settings.dataCollection}
              onCheckedChange={(checked) => setSettings({ ...settings, dataCollection: checked })}
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="usage-analytics" className="text-white">
                Análise de uso
              </Label>
              <p className="text-sm text-gray-400">Ajuda a melhorar a experiência do app</p>
            </div>
            <Switch
              id="usage-analytics"
              checked={settings.usageAnalytics}
              onCheckedChange={(checked) => setSettings({ ...settings, usageAnalytics: checked })}
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="crash-reporting" className="text-white">
                Relatórios de erro
              </Label>
              <p className="text-sm text-gray-400">Ajuda a identificar e corrigir problemas</p>
            </div>
            <Switch
              id="crash-reporting"
              checked={settings.crashReporting}
              onCheckedChange={(checked) => setSettings({ ...settings, crashReporting: checked })}
            />
          </div>
        </CardContent>
      </Card>

      {/* Sharing & Third Parties */}
      <Card className="bg-[#1A2332] border-gray-800">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Eye className="h-5 w-5 text-yellow-400" />
            <span className="text-white">Compartilhamento</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="analytics-sharing" className="text-white">
                Compartilhar analytics
              </Label>
              <p className="text-sm text-gray-400">Dados anonimizados para pesquisa em saúde mental</p>
            </div>
            <Switch
              id="analytics-sharing"
              checked={settings.analyticsSharing}
              onCheckedChange={(checked) => setSettings({ ...settings, analyticsSharing: checked })}
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="third-party-sharing" className="text-white">
                Terceiros
              </Label>
              <p className="text-sm text-gray-400">Compartilhar com parceiros (sempre anonimizado)</p>
            </div>
            <Switch
              id="third-party-sharing"
              checked={settings.thirdPartySharing}
              onCheckedChange={(checked) => setSettings({ ...settings, thirdPartySharing: checked })}
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="personalized-ads" className="text-white">
                Anúncios personalizados
              </Label>
              <p className="text-sm text-gray-400">Mostrar conteúdo relevante baseado no seu perfil</p>
            </div>
            <Switch
              id="personalized-ads"
              checked={settings.personalizedAds}
              onCheckedChange={(checked) => setSettings({ ...settings, personalizedAds: checked })}
            />
          </div>
        </CardContent>
      </Card>

      {/* Location & Tracking */}
      <Card className="bg-[#1A2332] border-gray-800">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Eye className="h-5 w-5 text-red-400" />
            <span className="text-white">Rastreamento</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="location-tracking" className="text-white">
                Localização
              </Label>
              <p className="text-sm text-gray-400">Para sugestões baseadas no clima e ambiente</p>
            </div>
            <Switch
              id="location-tracking"
              checked={settings.locationTracking}
              onCheckedChange={(checked) => setSettings({ ...settings, locationTracking: checked })}
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="device-tracking" className="text-white">
                Dispositivos
              </Label>
              <p className="text-sm text-gray-400">Sincronizar entre seus dispositivos</p>
            </div>
            <Switch
              id="device-tracking"
              checked={settings.deviceTracking}
              onCheckedChange={(checked) => setSettings({ ...settings, deviceTracking: checked })}
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="ip-logging" className="text-white">
                Log de IP
              </Label>
              <p className="text-sm text-gray-400">Registrar endereço IP para segurança</p>
            </div>
            <Switch
              id="ip-logging"
              checked={settings.ipLogging}
              onCheckedChange={(checked) => setSettings({ ...settings, ipLogging: checked })}
            />
          </div>
        </CardContent>
      </Card>

      {/* Security Settings */}
      <Card className="bg-[#1A2332] border-gray-800">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Key className="h-5 w-5 text-green-400" />
            <span className="text-white">Segurança</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="two-factor" className="text-white">
                Autenticação de dois fatores
              </Label>
              <p className="text-sm text-gray-400">Camada extra de segurança para sua conta</p>
            </div>
            <div className="flex items-center space-x-2">
              <Badge variant={settings.twoFactorAuth ? "default" : "secondary"}>
                {settings.twoFactorAuth ? "Ativo" : "Inativo"}
              </Badge>
              <Switch
                id="two-factor"
                checked={settings.twoFactorAuth}
                onCheckedChange={(checked) => setSettings({ ...settings, twoFactorAuth: checked })}
              />
            </div>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <Label className="text-white">Nível de criptografia</Label>
              <p className="text-sm text-gray-400">Força da criptografia dos seus dados</p>
            </div>
            <Select
              value={settings.encryptionLevel}
              onValueChange={(value) => setSettings({ ...settings, encryptionLevel: value })}
            >
              <SelectTrigger className="w-32 bg-gray-800 border-gray-700">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="aes128">AES-128</SelectItem>
                <SelectItem value="aes256">AES-256</SelectItem>
                <SelectItem value="rsa2048">RSA-2048</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <Label className="text-white">Timeout de sessão</Label>
              <p className="text-sm text-gray-400">Tempo para logout automático</p>
            </div>
            <Select
              value={settings.sessionTimeout}
              onValueChange={(value) => setSettings({ ...settings, sessionTimeout: value })}
            >
              <SelectTrigger className="w-32 bg-gray-800 border-gray-700">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1hour">1 hora</SelectItem>
                <SelectItem value="1day">1 dia</SelectItem>
                <SelectItem value="7days">7 dias</SelectItem>
                <SelectItem value="30days">30 dias</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Data Retention */}
      <Card className="bg-[#1A2332] border-gray-800">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Database className="h-5 w-5 text-purple-400" />
            <span className="text-white">Retenção de Dados</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label className="text-white">Período de armazenamento</Label>
              <p className="text-sm text-gray-400">Por quanto tempo manter seus dados</p>
            </div>
            <Select
              value={settings.dataRetention}
              onValueChange={(value) => setSettings({ ...settings, dataRetention: value })}
            >
              <SelectTrigger className="w-40 bg-gray-800 border-gray-700">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="6months">6 meses</SelectItem>
                <SelectItem value="1year">1 ano</SelectItem>
                <SelectItem value="2years">2 anos</SelectItem>
                <SelectItem value="5years">5 anos</SelectItem>
                <SelectItem value="forever">Permanente</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Alert className="bg-blue-900/20 border-blue-800">
            <AlertTriangle className="h-4 w-4 text-blue-400" />
            <AlertDescription className="text-blue-300">
              Dados de saúde mental são mantidos com criptografia extra e podem ser excluídos a qualquer momento.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>

      {/* Data Export & Management */}
      <Card className="bg-[#1A2332] border-gray-800">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Download className="h-5 w-5 text-blue-400" />
            <span className="text-white">Gerenciar Dados</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-medium text-white">Exportar dados</h3>
              <p className="text-sm text-gray-400">Baixe uma cópia de todos os seus dados</p>
            </div>
            <Button onClick={exportData} variant="outline" className="bg-transparent border-gray-700">
              <Download className="h-4 w-4 mr-2" />
              Exportar
            </Button>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-medium text-white">Solicitar correção</h3>
              <p className="text-sm text-gray-400">Corrigir informações incorretas</p>
            </div>
            <Button variant="outline" className="bg-transparent border-gray-700">
              Solicitar
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Danger Zone */}
      <Card className="bg-red-900/10 border-red-800">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Trash2 className="h-5 w-5 text-red-400" />
            <span className="text-white">Zona de Perigo</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Alert className="bg-red-900/20 border-red-800">
            <AlertTriangle className="h-4 w-4 text-red-400" />
            <AlertDescription className="text-red-300">
              As ações abaixo são irreversíveis. Proceda com extrema cautela.
            </AlertDescription>
          </Alert>

          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-medium text-white">Excluir todos os dados</h3>
              <p className="text-sm text-gray-400">Remove permanentemente todos os seus dados</p>
            </div>
            <Button
              onClick={() => setShowDangerZone(!showDangerZone)}
              variant="outline"
              className="border-red-700 text-red-400 hover:bg-red-900/20"
            >
              {showDangerZone ? "Cancelar" : "Mostrar"}
            </Button>
          </div>

          {showDangerZone && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              className="pt-4 border-t border-red-800"
            >
              <Button onClick={deleteAllData} variant="destructive" className="w-full bg-red-600 hover:bg-red-700">
                <Trash2 className="h-4 w-4 mr-2" />
                EXCLUIR TODOS OS DADOS PERMANENTEMENTE
              </Button>
            </motion.div>
          )}
        </CardContent>
      </Card>

      {/* Save Button */}
      <div className="flex justify-end">
        <Button
          onClick={saveSettings}
          disabled={loading}
          className="bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700"
        >
          {loading ? "Salvando..." : "Salvar Configurações de Privacidade"}
        </Button>
      </div>
    </div>
  )
}
