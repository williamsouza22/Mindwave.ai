"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { useAuth } from "@/lib/auth/auth-context"
import { useToast } from "@/hooks/use-toast"
import { User, Calendar, MapPin, Globe, Camera, Crown, Shield } from "lucide-react"

interface AccountData {
  name: string
  email: string
  phone: string
  bio: string
  location: string
  timezone: string
  language: string
  dateOfBirth: string
  gender: string
  profession: string
  avatar_url: string
}

export function AccountSettings() {
  const [accountData, setAccountData] = useState<AccountData>({
    name: "",
    email: "",
    phone: "",
    bio: "",
    location: "",
    timezone: "America/Sao_Paulo",
    language: "pt-BR",
    dateOfBirth: "",
    gender: "",
    profession: "",
    avatar_url: "",
  })

  const [loading, setLoading] = useState(false)
  const [uploadingAvatar, setUploadingAvatar] = useState(false)
  const { user, profile, updateProfile } = useAuth()
  const { toast } = useToast()

  useEffect(() => {
    if (user && profile) {
      setAccountData({
        name: profile.name || "",
        email: user.email || "",
        phone: profile.phone || "",
        bio: profile.bio || "",
        location: profile.location || "",
        timezone: profile.timezone || "America/Sao_Paulo",
        language: profile.language || "pt-BR",
        dateOfBirth: profile.date_of_birth || "",
        gender: profile.gender || "",
        profession: profile.profession || "",
        avatar_url: profile.avatar_url || "",
      })
    }
  }, [user, profile])

  const handleInputChange = (field: keyof AccountData, value: string) => {
    setAccountData((prev) => ({ ...prev, [field]: value }))
  }

  const handleAvatarUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    setUploadingAvatar(true)
    try {
      const formData = new FormData()
      formData.append("avatar", file)

      const response = await fetch("/api/user/upload-avatar", {
        method: "POST",
        body: formData,
      })

      if (response.ok) {
        const { avatar_url } = await response.json()
        setAccountData((prev) => ({ ...prev, avatar_url }))
        toast({
          title: "Avatar atualizado! 📸",
          description: "Sua foto de perfil foi alterada com sucesso.",
        })
      }
    } catch (error) {
      toast({
        title: "Erro no upload",
        description: "Não foi possível atualizar sua foto.",
        variant: "destructive",
      })
    } finally {
      setUploadingAvatar(false)
    }
  }

  const saveAccount = async () => {
    setLoading(true)
    try {
      await updateProfile({
        name: accountData.name,
        phone: accountData.phone,
        bio: accountData.bio,
        location: accountData.location,
        timezone: accountData.timezone,
        language: accountData.language,
        date_of_birth: accountData.dateOfBirth,
        gender: accountData.gender,
        profession: accountData.profession,
        avatar_url: accountData.avatar_url,
      })

      toast({
        title: "Perfil atualizado! ✅",
        description: "Suas informações foram salvas com sucesso.",
      })
    } catch (error) {
      toast({
        title: "Erro ao salvar",
        description: "Tente novamente em alguns instantes.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const calculateAge = (dateOfBirth: string) => {
    if (!dateOfBirth) return null
    const today = new Date()
    const birth = new Date(dateOfBirth)
    let age = today.getFullYear() - birth.getFullYear()
    const monthDiff = today.getMonth() - birth.getMonth()
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
      age--
    }
    return age
  }

  return (
    <div className="space-y-6">
      {/* Profile Overview */}
      <Card className="bg-[#1A2332] border-gray-800">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <User className="h-5 w-5 text-blue-400" />
            <span className="text-white">Perfil</span>
            <div className="ml-auto flex items-center space-x-2">
              {profile?.plan === "premium" && (
                <Badge className="bg-gradient-to-r from-yellow-500 to-orange-500">
                  <Crown className="h-3 w-3 mr-1" />
                  Premium
                </Badge>
              )}
              <Badge variant="secondary" className="bg-green-900/50 text-green-300 border-green-800">
                <Shield className="h-3 w-3 mr-1" />
                Verificado
              </Badge>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Avatar Section */}
          <div className="flex items-center space-x-6">
            <div className="relative">
              <Avatar className="h-20 w-20">
                <AvatarImage src={accountData.avatar_url || "/placeholder.svg"} alt={accountData.name} />
                <AvatarFallback className="bg-gradient-to-r from-blue-500 to-purple-500 text-white text-xl">
                  {accountData.name
                    .split(" ")
                    .map((n) => n[0])
                    .join("")
                    .toUpperCase() || "U"}
                </AvatarFallback>
              </Avatar>
              <label
                htmlFor="avatar-upload"
                className="absolute -bottom-1 -right-1 bg-blue-600 hover:bg-blue-700 rounded-full p-2 cursor-pointer transition-colors"
              >
                <Camera className="h-3 w-3 text-white" />
                <input
                  id="avatar-upload"
                  type="file"
                  accept="image/*"
                  onChange={handleAvatarUpload}
                  className="hidden"
                />
              </label>
            </div>

            <div className="flex-1">
              <h3 className="text-xl font-semibold text-white">{accountData.name || "Usuário"}</h3>
              <p className="text-gray-400">{accountData.email}</p>
              {accountData.profession && <p className="text-sm text-gray-500">{accountData.profession}</p>}
              {accountData.location && (
                <div className="flex items-center space-x-1 mt-1">
                  <MapPin className="h-3 w-3 text-gray-500" />
                  <span className="text-sm text-gray-500">{accountData.location}</span>
                </div>
              )}
            </div>
          </div>

          {uploadingAvatar && (
            <Alert className="bg-blue-900/20 border-blue-800">
              <Camera className="h-4 w-4 text-blue-400" />
              <AlertDescription className="text-blue-300">Fazendo upload da sua nova foto...</AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      {/* Basic Information */}
      <Card className="bg-[#1A2332] border-gray-800">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <User className="h-5 w-5 text-green-400" />
            <span className="text-white">Informações Básicas</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="name" className="text-white">
                Nome completo
              </Label>
              <Input
                id="name"
                value={accountData.name}
                onChange={(e) => handleInputChange("name", e.target.value)}
                className="bg-gray-800 border-gray-700 text-white"
                placeholder="Seu nome completo"
              />
            </div>

            <div>
              <Label htmlFor="email" className="text-white">
                Email
              </Label>
              <Input
                id="email"
                value={accountData.email}
                disabled
                className="bg-gray-900 border-gray-700 text-gray-400"
              />
              <p className="text-xs text-gray-500 mt-1">Email não pode ser alterado</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="phone" className="text-white">
                Telefone
              </Label>
              <Input
                id="phone"
                value={accountData.phone}
                onChange={(e) => handleInputChange("phone", e.target.value)}
                className="bg-gray-800 border-gray-700 text-white"
                placeholder="+55 (11) 99999-9999"
              />
            </div>

            <div>
              <Label htmlFor="profession" className="text-white">
                Profissão
              </Label>
              <Input
                id="profession"
                value={accountData.profession}
                onChange={(e) => handleInputChange("profession", e.target.value)}
                className="bg-gray-800 border-gray-700 text-white"
                placeholder="Sua profissão"
              />
            </div>
          </div>

          <div>
            <Label htmlFor="bio" className="text-white">
              Bio
            </Label>
            <Textarea
              id="bio"
              value={accountData.bio}
              onChange={(e) => handleInputChange("bio", e.target.value)}
              className="bg-gray-800 border-gray-700 text-white"
              placeholder="Conte um pouco sobre você..."
              rows={3}
            />
          </div>
        </CardContent>
      </Card>

      {/* Personal Details */}
      <Card className="bg-[#1A2332] border-gray-800">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Calendar className="h-5 w-5 text-purple-400" />
            <span className="text-white">Detalhes Pessoais</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="dateOfBirth" className="text-white">
                Data de nascimento
              </Label>
              <Input
                id="dateOfBirth"
                type="date"
                value={accountData.dateOfBirth}
                onChange={(e) => handleInputChange("dateOfBirth", e.target.value)}
                className="bg-gray-800 border-gray-700 text-white"
              />
              {accountData.dateOfBirth && (
                <p className="text-xs text-gray-500 mt-1">Idade: {calculateAge(accountData.dateOfBirth)} anos</p>
              )}
            </div>

            <div>
              <Label htmlFor="gender" className="text-white">
                Gênero
              </Label>
              <Select value={accountData.gender} onValueChange={(value) => handleInputChange("gender", value)}>
                <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
                  <SelectValue placeholder="Selecione seu gênero" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="male">Masculino</SelectItem>
                  <SelectItem value="female">Feminino</SelectItem>
                  <SelectItem value="non-binary">Não-binário</SelectItem>
                  <SelectItem value="other">Outro</SelectItem>
                  <SelectItem value="prefer-not-to-say">Prefiro não dizer</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label htmlFor="location" className="text-white">
              Localização
            </Label>
            <Input
              id="location"
              value={accountData.location}
              onChange={(e) => handleInputChange("location", e.target.value)}
              className="bg-gray-800 border-gray-700 text-white"
              placeholder="Cidade, Estado, País"
            />
          </div>
        </CardContent>
      </Card>

      {/* Preferences */}
      <Card className="bg-[#1A2332] border-gray-800">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Globe className="h-5 w-5 text-orange-400" />
            <span className="text-white">Preferências</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="language" className="text-white">
                Idioma
              </Label>
              <Select value={accountData.language} onValueChange={(value) => handleInputChange("language", value)}>
                <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pt-BR">Português (Brasil)</SelectItem>
                  <SelectItem value="en-US">English (US)</SelectItem>
                  <SelectItem value="es-ES">Español</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="timezone" className="text-white">
                Fuso horário
              </Label>
              <Select value={accountData.timezone} onValueChange={(value) => handleInputChange("timezone", value)}>
                <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="America/Sao_Paulo">São Paulo (GMT-3)</SelectItem>
                  <SelectItem value="America/New_York">New York (GMT-5)</SelectItem>
                  <SelectItem value="Europe/London">London (GMT+0)</SelectItem>
                  <SelectItem value="Asia/Tokyo">Tokyo (GMT+9)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Account Statistics */}
      <Card className="bg-[#1A2332] border-gray-800">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Shield className="h-5 w-5 text-cyan-400" />
            <span className="text-white">Estatísticas da Conta</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-4 bg-blue-900/20 rounded-lg border border-blue-800">
              <div className="text-2xl font-bold text-blue-400">127</div>
              <p className="text-sm text-blue-300">Check-ins</p>
            </div>
            <div className="text-center p-4 bg-green-900/20 rounded-lg border border-green-800">
              <div className="text-2xl font-bold text-green-400">45</div>
              <p className="text-sm text-green-300">Dias ativos</p>
            </div>
            <div className="text-center p-4 bg-purple-900/20 rounded-lg border border-purple-800">
              <div className="text-2xl font-bold text-purple-400">23h</div>
              <p className="text-sm text-purple-300">Meditação</p>
            </div>
            <div className="text-center p-4 bg-yellow-900/20 rounded-lg border border-yellow-800">
              <div className="text-2xl font-bold text-yellow-400">8.2</div>
              <p className="text-sm text-yellow-300">Humor médio</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Save Button */}
      <div className="flex justify-end">
        <Button
          onClick={saveAccount}
          disabled={loading}
          className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
        >
          {loading ? "Salvando..." : "Salvar Alterações"}
        </Button>
      </div>
    </div>
  )
}
